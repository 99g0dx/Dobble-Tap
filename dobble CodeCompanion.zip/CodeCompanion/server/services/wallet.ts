import { eq } from "drizzle-orm";
import { db } from "../db";
import { wallets, walletTransactions, type Wallet, type InsertWallet, type WalletTransaction, type InsertWalletTransaction } from "@shared/schema";

export class WalletService {
  // Create wallet for user
  async createWallet(userId: string, currency: string = "NGN"): Promise<Wallet> {
    const [wallet] = await db
      .insert(wallets)
      .values({
        userId,
        currency,
        balance: "0.00",
      })
      .returning();
    
    return wallet;
  }

  // Get or create wallet for user
  async getOrCreateWallet(userId: string, currency: string = "NGN"): Promise<Wallet> {
    const [existingWallet] = await db
      .select()
      .from(wallets)
      .where(eq(wallets.userId, userId));

    if (existingWallet) {
      return existingWallet;
    }

    return this.createWallet(userId, currency);
  }

  // Get wallet balance
  async getWalletBalance(userId: string): Promise<{ balance: string; currency: string }> {
    const wallet = await this.getOrCreateWallet(userId);
    return {
      balance: wallet.balance,
      currency: wallet.currency,
    };
  }

  // Add funds to wallet
  async addFunds(userId: string, amount: string, reference: string, description: string = "Wallet funding"): Promise<WalletTransaction> {
    const wallet = await this.getOrCreateWallet(userId);
    
    // Add transaction record
    const [transaction] = await db
      .insert(walletTransactions)
      .values({
        walletId: wallet.id,
        type: "deposit",
        amount,
        description,
        reference,
        status: "completed",
        metadata: {
          paymentGateway: "paystack",
          userId,
        },
      })
      .returning();

    // Update wallet balance
    const newBalance = (parseFloat(wallet.balance) + parseFloat(amount)).toFixed(2);
    await db
      .update(wallets)
      .set({
        balance: newBalance,
        updatedAt: new Date(),
      })
      .where(eq(wallets.id, wallet.id));

    return transaction;
  }

  // Deduct funds from wallet
  async deductFunds(userId: string, amount: string, description: string, reference?: string): Promise<WalletTransaction> {
    const wallet = await this.getOrCreateWallet(userId);
    
    // Check if sufficient balance
    const currentBalance = parseFloat(wallet.balance);
    const deductAmount = parseFloat(amount);
    
    if (currentBalance < deductAmount) {
      throw new Error("Insufficient wallet balance");
    }

    // Add transaction record
    const [transaction] = await db
      .insert(walletTransactions)
      .values({
        walletId: wallet.id,
        type: "payment",
        amount: `-${amount}`,
        description,
        reference,
        status: "completed",
        metadata: {
          userId,
        },
      })
      .returning();

    // Update wallet balance
    const newBalance = (currentBalance - deductAmount).toFixed(2);
    await db
      .update(wallets)
      .set({
        balance: newBalance,
        updatedAt: new Date(),
      })
      .where(eq(wallets.id, wallet.id));

    return transaction;
  }

  // Get wallet transactions
  async getWalletTransactions(userId: string, limit: number = 50): Promise<WalletTransaction[]> {
    const wallet = await this.getOrCreateWallet(userId);
    
    return await db
      .select()
      .from(walletTransactions)
      .where(eq(walletTransactions.walletId, wallet.id))
      .orderBy(walletTransactions.createdAt)
      .limit(limit);
  }

  // Check if user has sufficient funds
  async hasSufficientFunds(userId: string, amount: string): Promise<boolean> {
    const { balance } = await this.getWalletBalance(userId);
    return parseFloat(balance) >= parseFloat(amount);
  }

  // Process campaign payment from wallet
  async processCampaignPayment(userId: string, campaignId: string, amount: string): Promise<WalletTransaction> {
    const hasEnoughFunds = await this.hasSufficientFunds(userId, amount);
    
    if (!hasEnoughFunds) {
      throw new Error("Insufficient funds. Please top up your wallet.");
    }

    return this.deductFunds(
      userId,
      amount,
      `Campaign payment for campaign ${campaignId}`,
      `campaign_${campaignId}_${Date.now()}`
    );
  }
}

export const walletService = new WalletService();