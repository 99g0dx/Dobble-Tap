import { storage } from "../storage";

export class AnalyticsService {
  // Track user activity
  async trackUserActivity(userId: string, activity: string, metadata?: any) {
    try {
      console.log('User activity tracked', {
        userId,
        activity,
        metadata,
        timestamp: new Date().toISOString()
      });
      
      // In production, you might want to store this in a dedicated analytics table
      // or send to external analytics service
    } catch (error) {
      console.error('Error tracking user activity:', error);
    }
  }
  
  // Track campaign performance
  async trackCampaignEvent(campaignId: string, event: string, metadata?: any) {
    try {
      console.log('Campaign event tracked', {
        campaignId,
        event,
        metadata,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error tracking campaign event:', error);
    }
  }
  
  // Get user statistics
  async getUserStats(userId: string) {
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error('User not found');
      }
      
      const payments = await storage.getPaymentsByUser(userId);
      const campaigns = await storage.getCampaignsByUser(userId);
      const taskSubmissions = await storage.getTaskSubmissionsByUser(userId);
      
      const totalEarnings = payments
        .filter(p => p.status === 'completed')
        .reduce((sum, p) => sum + parseFloat(p.amount), 0);
      
      const completedTasks = taskSubmissions.filter(t => t.status === 'approved').length;
      const totalTasks = taskSubmissions.length;
      const successRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
      
      return {
        totalEarnings,
        tasksCompleted: completedTasks,
        activeCampaigns: campaigns.filter(c => c.status === 'active').length,
        successRate: Math.round(successRate),
        totalSubmissions: totalTasks,
        pendingPayments: payments.filter(p => p.status === 'pending').length
      };
    } catch (error) {
      console.error('Error getting user stats:', error);
      return {
        totalEarnings: 0,
        tasksCompleted: 0,
        activeCampaigns: 0,
        successRate: 0,
        totalSubmissions: 0,
        pendingPayments: 0
      };
    }
  }
  
  // Get campaign statistics
  async getCampaignStats(campaignId: string) {
    try {
      const campaign = await storage.getCampaign(campaignId);
      if (!campaign) {
        throw new Error('Campaign not found');
      }
      
      const tasks = await storage.getTasksByCampaign(campaignId);
      const applications = await storage.getCampaignApplicationsByCampaign(campaignId);
      
      let totalSubmissions = 0;
      let completedTasks = 0;
      
      for (const task of tasks) {
        const submissions = await storage.getTaskSubmissionsByTask(task.id);
        totalSubmissions += submissions.length;
        completedTasks += submissions.filter(s => s.status === 'approved').length;
      }
      
      const totalSpent = parseFloat(campaign.budget) || 0;
      const averageEngagement = completedTasks > 0 ? (totalSubmissions / completedTasks) * 100 : 0;
      
      return {
        totalApplications: applications.length,
        approvedCreators: applications.filter(a => a.status === 'approved').length,
        totalSubmissions,
        completedTasks,
        totalSpent,
        averageEngagement: Math.round(averageEngagement),
        conversionRate: applications.length > 0 ? Math.round((completedTasks / applications.length) * 100) : 0
      };
    } catch (error) {
      console.error('Error getting campaign stats:', error);
      return {
        totalApplications: 0,
        approvedCreators: 0,
        totalSubmissions: 0,
        completedTasks: 0,
        totalSpent: 0,
        averageEngagement: 0,
        conversionRate: 0
      };
    }
  }
  
  // Get platform overview stats
  async getPlatformStats() {
    try {
      // This would typically be cached or computed periodically
      const stats = {
        totalUsers: 0,
        totalCampaigns: 0,
        totalPayments: 0,
        totalEarnings: 0,
        activeUsers: 0,
        activeCampaigns: 0
      };
      
      // Implementation would depend on your storage system
      // For now, return mock data for demonstration
      return {
        totalUsers: 1250,
        totalCampaigns: 89,
        totalPayments: 2340,
        totalEarnings: 4500000, // in kobo
        activeUsers: 340,
        activeCampaigns: 23
      };
    } catch (error) {
      console.error('Error getting platform stats:', error);
      return {
        totalUsers: 0,
        totalCampaigns: 0,
        totalPayments: 0,
        totalEarnings: 0,
        activeUsers: 0,
        activeCampaigns: 0
      };
    }
  }
}

export const analyticsService = new AnalyticsService();