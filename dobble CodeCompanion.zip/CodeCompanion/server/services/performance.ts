import { performance } from 'perf_hooks';

export class PerformanceService {
  private metrics: Map<string, number[]> = new Map();
  
  // Track operation performance
  trackOperation<T>(name: string, operation: () => Promise<T> | T): Promise<T> {
    const start = performance.now();
    
    const finish = (result: T) => {
      const duration = performance.now() - start;
      this.recordMetric(name, duration);
      return result;
    };
    
    try {
      const result = operation();
      if (result instanceof Promise) {
        return result.then(finish);
      }
      return Promise.resolve(finish(result));
    } catch (error) {
      const duration = performance.now() - start;
      this.recordMetric(name, duration);
      throw error;
    }
  }
  
  // Record metric
  private recordMetric(name: string, duration: number) {
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    
    const metrics = this.metrics.get(name)!;
    metrics.push(duration);
    
    // Keep only last 100 measurements
    if (metrics.length > 100) {
      metrics.shift();
    }
    
    // Log slow operations
    if (duration > 1000) {
      console.warn(`Slow operation: ${name} took ${duration.toFixed(2)}ms`);
    }
  }
  
  // Get performance metrics
  getMetrics(name?: string) {
    if (name) {
      const metrics = this.metrics.get(name) || [];
      return this.calculateStats(metrics);
    }
    
    const allMetrics: { [key: string]: any } = {};
    for (const [metricName, values] of this.metrics) {
      allMetrics[metricName] = this.calculateStats(values);
    }
    
    return allMetrics;
  }
  
  private calculateStats(values: number[]) {
    if (values.length === 0) {
      return { count: 0, avg: 0, min: 0, max: 0, p95: 0 };
    }
    
    const sorted = [...values].sort((a, b) => a - b);
    const sum = values.reduce((a, b) => a + b, 0);
    
    return {
      count: values.length,
      avg: sum / values.length,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      p95: sorted[Math.floor(sorted.length * 0.95)] || sorted[sorted.length - 1]
    };
  }
  
  // Database query performance wrapper
  async trackDatabaseQuery<T>(query: string, operation: () => Promise<T>): Promise<T> {
    return this.trackOperation(`db:${query}`, operation);
  }
  
  // API endpoint performance wrapper
  async trackApiCall<T>(endpoint: string, operation: () => Promise<T>): Promise<T> {
    return this.trackOperation(`api:${endpoint}`, operation);
  }
  
  // Reset metrics
  clearMetrics(name?: string) {
    if (name) {
      this.metrics.delete(name);
    } else {
      this.metrics.clear();
    }
  }
}

export const performanceService = new PerformanceService();