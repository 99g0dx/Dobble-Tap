# Analytics System - Dobble Tap Platform

## Overview
The Dobble Tap analytics system tracks engagement metrics for campaigns and task submissions to provide real-time insights to brands and creators.

## Data Collection Methods

### 1. **Social Media Platform Integration**
- **Instagram**: Uses Instagram Basic Display API to track:
  - Post likes, comments, shares, saves
  - Story views, story taps, story exits
  - Reel plays, reel likes, reel comments
  - Profile visits from posts

- **TikTok**: Uses TikTok Business API to track:
  - Video views, likes, shares, comments
  - Profile visits from videos
  - Hashtag performance
  - Video completion rates

- **Twitter/X**: Uses Twitter API v2 to track:
  - Tweet impressions, retweets, likes, replies
  - Profile visits from tweets
  - Hashtag performance
  - Tweet engagement rate

- **YouTube**: Uses YouTube Analytics API to track:
  - Video views, likes, dislikes, comments
  - Watch time, average view duration
  - Subscriber growth from videos
  - Click-through rates

### 2. **Link Tracking System**
- **UTM Parameters**: Each campaign link contains unique tracking parameters:
  - `utm_source=dobble_tap`
  - `utm_medium=creator_post`
  - `utm_campaign=campaign_id`
  - `utm_content=task_id`
  - `utm_term=creator_id`

- **Shortened Links**: Generated using custom URL shortener that tracks:
  - Click counts
  - Geographic location of clicks
  - Device type (mobile/desktop)
  - Referrer information
  - Time-based click patterns

### 3. **Database Schema for Analytics**

```sql
-- Analytics tables (would be added to shared/schema.ts)

CREATE TABLE campaign_analytics (
  id UUID PRIMARY KEY,
  campaign_id UUID REFERENCES campaigns(id),
  total_reach INTEGER DEFAULT 0,
  total_engagement INTEGER DEFAULT 0,
  total_clicks INTEGER DEFAULT 0,
  total_conversions INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE task_analytics (
  id UUID PRIMARY KEY,
  task_id UUID REFERENCES tasks(id),
  submission_id UUID REFERENCES task_submissions(id),
  platform VARCHAR(50) NOT NULL,
  post_url TEXT,
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  shares_count INTEGER DEFAULT 0,
  views_count INTEGER DEFAULT 0,
  clicks_count INTEGER DEFAULT 0,
  reach INTEGER DEFAULT 0,
  engagement_rate DECIMAL(5,2) DEFAULT 0,
  tracked_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE link_tracking (
  id UUID PRIMARY KEY,
  task_id UUID REFERENCES tasks(id),
  short_url VARCHAR(255) UNIQUE,
  original_url TEXT,
  click_count INTEGER DEFAULT 0,
  unique_clicks INTEGER DEFAULT 0,
  geographic_data JSONB,
  device_data JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Engagement Calculation Logic

### 1. **Per Post Engagement Rate**
```
Engagement Rate = (Likes + Comments + Shares + Saves) / Reach × 100
```

### 2. **Campaign-Level Metrics**
- **Total Reach**: Sum of all individual post reach across all tasks
- **Total Engagement**: Sum of all interactions across all tasks
- **Average Engagement Rate**: Weighted average based on reach
- **Conversion Rate**: Clicks to actual conversions (tracked via UTM parameters)

### 3. **Real-Time Tracking Process**

#### Step 1: Initial Data Collection
When a creator submits a task:
1. Creator provides social media post URL
2. System extracts post ID and platform
3. Initial analytics snapshot is taken
4. Tracking links are generated if required

#### Step 2: Periodic Updates
- **Every 15 minutes**: API calls to social platforms for updated metrics
- **Every hour**: Comprehensive analytics refresh
- **Daily**: Full analytics reconciliation and reporting

#### Step 3: Data Processing
```javascript
// Example analytics processing function
async function updateTaskAnalytics(taskId) {
  const submission = await getTaskSubmission(taskId);
  const platform = submission.platform;
  
  switch(platform) {
    case 'instagram':
      const igData = await fetchInstagramMetrics(submission.postUrl);
      await updateAnalytics(taskId, igData);
      break;
    case 'tiktok':
      const ttData = await fetchTikTokMetrics(submission.postUrl);
      await updateAnalytics(taskId, ttData);
      break;
    // Additional platforms...
  }
}
```

## Live Tracking Implementation

### 1. **WebSocket Integration**
- Real-time dashboard updates using WebSockets
- Automatic refresh of analytics without page reload
- Live notifications for significant engagement spikes

### 2. **API Rate Limiting Compliance**
- Instagram: 200 requests/hour per user
- TikTok: 1,000 requests/day per app
- Twitter: 300 requests/15-minute window
- YouTube: 10,000 quota units/day

### 3. **Data Validation & Quality**
- Cross-platform verification of metrics
- Anomaly detection for unusual engagement patterns
- Manual verification for high-value campaigns

## Dashboard Analytics Features

### 1. **Brand Dashboard**
- Campaign performance overview
- Individual task performance
- ROI calculation
- Audience demographics
- Engagement trends over time

### 2. **Creator Dashboard**
- Personal performance metrics
- Earnings per engagement
- Audience growth tracking
- Best performing content types

### 3. **Real-Time Updates**
- Live engagement counters
- Notification system for milestones
- Trend analysis and predictions
- Comparative performance metrics

## Privacy & Compliance

### 1. **Data Protection**
- All analytics data encrypted at rest
- GDPR compliance for EU users
- Data retention policies (90 days for detailed metrics)
- User consent management

### 2. **Platform Compliance**
- Adherence to each platform's API terms
- Proper attribution and disclosure
- Respect for platform rate limits
- Regular API compliance audits

## Technical Implementation Notes

### 1. **Background Jobs**
- Scheduled analytics updates using cron jobs
- Queue system for processing large campaigns
- Error handling and retry mechanisms
- Performance monitoring and optimization

### 2. **Caching Strategy**
- Redis caching for frequently accessed metrics
- Database indexing for fast queries
- CDN for static analytics assets
- Query optimization for large datasets

### 3. **Monitoring & Alerts**
- System health monitoring
- API failure alerts
- Performance degradation warnings
- Data quality assurance checks

This analytics system provides comprehensive tracking while maintaining platform compliance and user privacy, enabling both creators and brands to make data-driven decisions about their campaigns.