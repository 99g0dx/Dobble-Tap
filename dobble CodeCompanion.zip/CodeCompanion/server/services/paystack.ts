import crypto from "crypto";

export interface PaystackConfig {
  publicKey: string;
  secretKey: string;
  baseUrl: string;
}

export class PaystackService {
  private config: PaystackConfig;

  constructor() {
    this.config = {
      publicKey: process.env.PAYSTACK_PUBLIC_KEY || process.env.REACT_APP_PAYSTACK_PUBLIC_KEY || "",
      secretKey: process.env.PAYSTACK_SECRET_KEY || process.env.REACT_APP_PAYSTACK_SECRET_KEY || "",
      baseUrl: "https://api.paystack.co"
    };
  }

  async initializePayment(data: {
    email: string;
    amount: number;
    currency?: string;
    reference?: string;
    callback_url?: string;
    metadata?: any;
  }) {
    const url = `${this.config.baseUrl}/transaction/initialize`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.config.secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...data,
        amount: data.amount * 100, // Convert to kobo
        currency: data.currency || "NGN",
      }),
    });

    if (!response.ok) {
      throw new Error(`Paystack API error: ${response.statusText}`);
    }

    return await response.json();
  }

  async verifyPayment(reference: string) {
    const url = `${this.config.baseUrl}/transaction/verify/${reference}`;
    
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${this.config.secretKey}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Paystack API error: ${response.statusText}`);
    }

    return await response.json();
  }

  async createTransferRecipient(data: {
    type: string;
    name: string;
    account_number: string;
    bank_code: string;
    currency?: string;
  }) {
    const url = `${this.config.baseUrl}/transferrecipient`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.config.secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...data,
        currency: data.currency || "NGN",
      }),
    });

    if (!response.ok) {
      throw new Error(`Paystack API error: ${response.statusText}`);
    }

    return await response.json();
  }

  async initiateTransfer(data: {
    source: string;
    amount: number;
    recipient: string;
    reason?: string;
    currency?: string;
  }) {
    const url = `${this.config.baseUrl}/transfer`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.config.secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        ...data,
        amount: data.amount * 100, // Convert to kobo
        currency: data.currency || "NGN",
      }),
    });

    if (!response.ok) {
      throw new Error(`Paystack API error: ${response.statusText}`);
    }

    return await response.json();
  }

  verifyWebhook(payload: string, signature: string): boolean {
    const hash = crypto
      .createHmac("sha512", this.config.secretKey)
      .update(payload)
      .digest("hex");
    
    return hash === signature;
  }
}

export const paystackService = new PaystackService();
