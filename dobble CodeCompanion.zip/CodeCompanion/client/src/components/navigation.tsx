import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Zap } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import WalletButton from "./wallet-button";


export default function Navigation() {
  const [location] = useLocation();
  const { user } = useAuth();

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-14 sm:h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <div className="flex items-center cursor-pointer">
                  <div className="w-6 h-6 sm:w-8 sm:h-8 bg-blue-600 rounded-lg flex items-center justify-center mr-2 sm:mr-3">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                  </div>
                  <span className="font-poppins font-bold text-lg sm:text-xl text-black">Dobble Tap</span>
                </div>
              </Link>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <Link href="/creators" className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium">
                For Creators
              </Link>
              <Link href="/brands" className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium">
                For Brands
              </Link>
              <Link href="/smm-panel" className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium">
                SMM Panel
              </Link>
              <a href="#how-it-works" className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium">
                How It Works
              </a>
              <a href="#pricing" className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium">
                Pricing
              </a>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 sm:space-x-4">
            {user ? (
              <WalletButton />
            ) : (
              <>
                <Link href="/auth/login">
                  <Button variant="ghost" className="text-gray-600 hover:text-black text-sm sm:text-base px-2 sm:px-4">
                    Sign In
                  </Button>
                </Link>
                <Link href="/auth/register">
                  <Button className="bg-blue-600 text-white hover:bg-blue-700 text-sm sm:text-base px-2 sm:px-4">
                    Get Started
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
