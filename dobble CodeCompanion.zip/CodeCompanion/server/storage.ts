import { eq } from "drizzle-orm";
import { db } from "./db";
import { 
  users, 
  campaigns, 
  tasks, 
  taskSubmissions, 
  payments, 
  notifications,
  campaignApplications,
  type User, 
  type InsertUser,
  type Campaign,
  type InsertCampaign,
  type Task,
  type InsertTask,
  type TaskSubmission,
  type InsertTaskSubmission,
  type Payment,
  type InsertPayment,
  type Notification,
  type InsertNotification,
  type CampaignApplication,
  type InsertCampaignApplication
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User>;
  
  // Campaigns
  getCampaign(id: string): Promise<Campaign | undefined>;
  getCampaignsByUser(userId: string): Promise<Campaign[]>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign>;
  deleteCampaign(id: string): Promise<void>;
  
  // Tasks
  getTask(id: string): Promise<Task | undefined>;
  getTasksByCampaign(campaignId: string): Promise<Task[]>;
  getAvailableTasks(): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task>;
  
  // Task Submissions
  getTaskSubmission(id: string): Promise<TaskSubmission | undefined>;
  getTaskSubmissionsByUser(userId: string): Promise<TaskSubmission[]>;
  getTaskSubmissionsByTask(taskId: string): Promise<TaskSubmission[]>;
  createTaskSubmission(submission: InsertTaskSubmission): Promise<TaskSubmission>;
  updateTaskSubmission(id: string, submission: Partial<InsertTaskSubmission>): Promise<TaskSubmission>;
  
  // Payments
  getPayment(id: string): Promise<Payment | undefined>;
  getPaymentsByUser(userId: string): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePayment(id: string, payment: Partial<InsertPayment>): Promise<Payment>;
  
  // Notifications
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<void>;
  
  // Campaign Applications
  getCampaignApplicationsByUser(userId: string): Promise<CampaignApplication[]>;
  getCampaignApplicationsByCampaign(campaignId: string): Promise<CampaignApplication[]>;
  createCampaignApplication(application: InsertCampaignApplication): Promise<CampaignApplication>;
  updateCampaignApplication(id: string, application: Partial<InsertCampaignApplication>): Promise<CampaignApplication>;
  getAvailableCampaignsForCreator(userId: string): Promise<Campaign[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private campaigns: Map<string, Campaign> = new Map();
  private tasks: Map<string, Task> = new Map();
  private taskSubmissions: Map<string, TaskSubmission> = new Map();
  private payments: Map<string, Payment> = new Map();
  private notifications: Map<string, Notification> = new Map();
  private campaignApplications: Map<string, CampaignApplication> = new Map();
  
  private generateId(): string {
    return crypto.randomUUID();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.generateId();
    const user: User = {
      ...insertUser,
      id,
      role: insertUser.role || "creator",
      phone: insertUser.phone || null,
      avatarUrl: insertUser.avatarUrl || null,
      bio: insertUser.bio || null,
      location: insertUser.location || null,
      state: insertUser.state || null,
      country: insertUser.country || null,
      school: insertUser.school || null,
      age: insertUser.age || null,
      gender: insertUser.gender || null,
      instagramHandle: insertUser.instagramHandle || null,
      twitterHandle: insertUser.twitterHandle || null,
      youtubeHandle: insertUser.youtubeHandle || null,
      facebookHandle: insertUser.facebookHandle || null,
      tiktokHandle: insertUser.tiktokHandle || null,
      snapchatHandle: insertUser.snapchatHandle || null,
      linkedinHandle: insertUser.linkedinHandle || null,
      preferredCurrency: insertUser.preferredCurrency || null,
      verificationStatus: "pending",
      profileCompleted: false,
      emailVerified: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser: User = {
      ...user,
      ...updates,
      updatedAt: new Date(),
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Campaigns
  async getCampaign(id: string): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async getCampaignsByUser(userId: string): Promise<Campaign[]> {
    return Array.from(this.campaigns.values()).filter(campaign => campaign.userId === userId);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = this.generateId();
    const campaign: Campaign = {
      ...insertCampaign,
      id,
      status: insertCampaign.status || "draft",
      type: insertCampaign.type || "regular",
      currency: insertCampaign.currency || "USD",
      startDate: insertCampaign.startDate || null,
      endDate: insertCampaign.endDate || null,
      targetAudience: insertCampaign.targetAudience || null,
      requirements: insertCampaign.requirements || null,
      // Creator selection fields
      targetCountries: insertCampaign.targetCountries as string[] || null,
      minFollowers: insertCampaign.minFollowers || 0,
      maxCreators: insertCampaign.maxCreators || 50,
      preferredPlatforms: insertCampaign.preferredPlatforms as string[] || null,
      autoApprove: insertCampaign.autoApprove || false,
      // Sound URLs
      tiktokSoundUrl: insertCampaign.tiktokSoundUrl || null,
      instagramSoundUrl: insertCampaign.instagramSoundUrl || null,
      youtubeSoundUrl: insertCampaign.youtubeSoundUrl || null,
      snapchatSoundUrl: insertCampaign.snapchatSoundUrl || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async updateCampaign(id: string, updates: Partial<InsertCampaign>): Promise<Campaign> {
    const campaign = this.campaigns.get(id);
    if (!campaign) throw new Error("Campaign not found");
    
    const updatedCampaign: Campaign = {
      ...campaign,
      ...updates,
      targetCountries: updates.targetCountries as string[] || campaign.targetCountries,
      preferredPlatforms: updates.preferredPlatforms as string[] || campaign.preferredPlatforms,
      updatedAt: new Date(),
    };
    this.campaigns.set(id, updatedCampaign);
    return updatedCampaign;
  }

  async deleteCampaign(id: string): Promise<void> {
    const campaign = this.campaigns.get(id);
    if (!campaign) throw new Error("Campaign not found");
    
    this.campaigns.delete(id);
  }

  // Tasks
  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTasksByCampaign(campaignId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.campaignId === campaignId);
  }

  async getAvailableTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => 
      task.status === "active" && 
      (task.currentCompletions || 0) < (task.maxCompletions || 1)
    );
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.generateId();
    const task: Task = {
      ...insertTask,
      id,
      status: insertTask.status || "active",
      targetUrl: insertTask.targetUrl || null,
      maxCompletions: insertTask.maxCompletions || null,
      currentCompletions: insertTask.currentCompletions || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) throw new Error("Task not found");
    
    const updatedTask: Task = {
      ...task,
      ...updates,
      updatedAt: new Date(),
    };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  // Task Submissions
  async getTaskSubmission(id: string): Promise<TaskSubmission | undefined> {
    return this.taskSubmissions.get(id);
  }

  async getTaskSubmissionsByUser(userId: string): Promise<TaskSubmission[]> {
    return Array.from(this.taskSubmissions.values()).filter(submission => submission.userId === userId);
  }

  async getTaskSubmissionsByTask(taskId: string): Promise<TaskSubmission[]> {
    return Array.from(this.taskSubmissions.values()).filter(submission => submission.taskId === taskId);
  }

  async createTaskSubmission(insertSubmission: InsertTaskSubmission): Promise<TaskSubmission> {
    const id = this.generateId();
    const submission: TaskSubmission = {
      ...insertSubmission,
      id,
      status: insertSubmission.status || "pending",
      screenshotUrl: insertSubmission.screenshotUrl || null,
      notes: insertSubmission.notes || null,
      adminNotes: insertSubmission.adminNotes || null,
      submittedAt: new Date(),
      verifiedAt: null,
    };
    this.taskSubmissions.set(id, submission);
    return submission;
  }

  async updateTaskSubmission(id: string, updates: Partial<InsertTaskSubmission>): Promise<TaskSubmission> {
    const submission = this.taskSubmissions.get(id);
    if (!submission) throw new Error("Task submission not found");
    
    const updatedSubmission: TaskSubmission = {
      ...submission,
      ...updates,
      verifiedAt: updates.status === "approved" ? new Date() : submission.verifiedAt,
    };
    this.taskSubmissions.set(id, updatedSubmission);
    return updatedSubmission;
  }

  // Payments
  async getPayment(id: string): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(payment => payment.userId === userId);
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.generateId();
    const payment: Payment = {
      ...insertPayment,
      id,
      status: insertPayment.status || "pending",
      taskId: insertPayment.taskId || null,
      campaignId: insertPayment.campaignId || null,
      reference: insertPayment.reference || null,
      currency: insertPayment.currency || "NGN",
      gatewayResponse: insertPayment.gatewayResponse || null,
      metadata: insertPayment.metadata || {},
      createdAt: new Date(),
      verifiedAt: null,
    };
    this.payments.set(id, payment);
    return payment;
  }

  async updatePayment(id: string, updates: Partial<InsertPayment>): Promise<Payment> {
    const payment = this.payments.get(id);
    if (!payment) throw new Error("Payment not found");
    
    const updatedPayment: Payment = {
      ...payment,
      ...updates,
      verifiedAt: updates.status === "completed" ? new Date() : payment.verifiedAt,
    };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }

  // Notifications
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.generateId();
    const notification: Notification = {
      ...insertNotification,
      id,
      read: insertNotification.read || false,
      data: insertNotification.data || {},
      createdAt: new Date(),
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationAsRead(id: string): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.read = true;
      this.notifications.set(id, notification);
    }
  }

  // Campaign Applications
  async getCampaignApplicationsByUser(userId: string): Promise<CampaignApplication[]> {
    return Array.from(this.campaignApplications.values()).filter(app => app.userId === userId);
  }

  async getCampaignApplicationsByCampaign(campaignId: string): Promise<CampaignApplication[]> {
    return Array.from(this.campaignApplications.values()).filter(app => app.campaignId === campaignId);
  }

  async createCampaignApplication(insertApplication: InsertCampaignApplication): Promise<CampaignApplication> {
    const id = this.generateId();
    const application: CampaignApplication = {
      ...insertApplication,
      id,
      status: insertApplication.status || "pending",
      applicationMessage: insertApplication.applicationMessage || null,
      brandNotes: insertApplication.brandNotes || null,
      appliedAt: new Date(),
      reviewedAt: null,
    };
    this.campaignApplications.set(id, application);
    return application;
  }

  async updateCampaignApplication(id: string, updates: Partial<InsertCampaignApplication>): Promise<CampaignApplication> {
    const application = this.campaignApplications.get(id);
    if (!application) throw new Error("Campaign application not found");
    
    const updatedApplication: CampaignApplication = {
      ...application,
      ...updates,
      reviewedAt: updates.status ? new Date() : application.reviewedAt,
    };
    this.campaignApplications.set(id, updatedApplication);
    return updatedApplication;
  }

  async getAvailableCampaignsForCreator(userId: string): Promise<Campaign[]> {
    const user = this.users.get(userId);
    if (!user) return [];
    
    const userApplications = await this.getCampaignApplicationsByUser(userId);
    const appliedCampaignIds = new Set(userApplications.map(app => app.campaignId));
    
    return Array.from(this.campaigns.values()).filter(campaign => {
      // Exclude campaigns user has already applied to
      if (appliedCampaignIds.has(campaign.id)) return false;
      
      // Only show active campaigns
      if (campaign.status !== "active") return false;
      
      // Check country targeting
      if (campaign.targetCountries && campaign.targetCountries.length > 0) {
        if (!user.country || !campaign.targetCountries.includes(user.country)) {
          return false;
        }
      }
      
      return true;
    });
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user as any).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User> {
    const result = await db.update(users).set(updates as any).where(eq(users.id, id)).returning();
    return result[0];
  }

  // Campaigns
  async getCampaign(id: string): Promise<Campaign | undefined> {
    const result = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return result[0];
  }

  async getCampaignsByUser(userId: string): Promise<Campaign[]> {
    return await db.select().from(campaigns).where(eq(campaigns.userId, userId));
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const result = await db.insert(campaigns).values(campaign as any).returning();
    return result[0];
  }

  async updateCampaign(id: string, updates: Partial<InsertCampaign>): Promise<Campaign> {
    const result = await db.update(campaigns).set(updates as any).where(eq(campaigns.id, id)).returning();
    return result[0];
  }

  async deleteCampaign(id: string): Promise<void> {
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  // Tasks
  async getTask(id: string): Promise<Task | undefined> {
    const result = await db.select().from(tasks).where(eq(tasks.id, id));
    return result[0];
  }

  async getTasksByCampaign(campaignId: string): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.campaignId, campaignId));
  }

  async getAvailableTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async createTask(task: InsertTask): Promise<Task> {
    const result = await db.insert(tasks).values(task).returning();
    return result[0];
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task> {
    const result = await db.update(tasks).set(updates as any).where(eq(tasks.id, id)).returning();
    return result[0];
  }

  // Task Submissions
  async getTaskSubmission(id: string): Promise<TaskSubmission | undefined> {
    const result = await db.select().from(taskSubmissions).where(eq(taskSubmissions.id, id));
    return result[0];
  }

  async getTaskSubmissionsByUser(userId: string): Promise<TaskSubmission[]> {
    return await db.select().from(taskSubmissions).where(eq(taskSubmissions.userId, userId));
  }

  async getTaskSubmissionsByTask(taskId: string): Promise<TaskSubmission[]> {
    return await db.select().from(taskSubmissions).where(eq(taskSubmissions.taskId, taskId));
  }

  async createTaskSubmission(submission: InsertTaskSubmission): Promise<TaskSubmission> {
    const result = await db.insert(taskSubmissions).values(submission).returning();
    return result[0];
  }

  async updateTaskSubmission(id: string, updates: Partial<InsertTaskSubmission>): Promise<TaskSubmission> {
    const result = await db.update(taskSubmissions).set(updates as any).where(eq(taskSubmissions.id, id)).returning();
    return result[0];
  }

  // Payments
  async getPayment(id: string): Promise<Payment | undefined> {
    const result = await db.select().from(payments).where(eq(payments.id, id));
    return result[0];
  }

  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.userId, userId));
  }

  async createPayment(payment: InsertPayment): Promise<Payment> {
    const result = await db.insert(payments).values(payment).returning();
    return result[0];
  }

  async updatePayment(id: string, updates: Partial<InsertPayment>): Promise<Payment> {
    const result = await db.update(payments).set(updates as any).where(eq(payments.id, id)).returning();
    return result[0];
  }

  // Notifications
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return await db.select().from(notifications).where(eq(notifications.userId, userId));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const result = await db.insert(notifications).values(notification).returning();
    return result[0];
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
  }

  // Campaign Applications
  async getCampaignApplicationsByUser(userId: string): Promise<CampaignApplication[]> {
    return await db.select().from(campaignApplications).where(eq(campaignApplications.userId, userId));
  }

  async getCampaignApplicationsByCampaign(campaignId: string): Promise<CampaignApplication[]> {
    return await db.select().from(campaignApplications).where(eq(campaignApplications.campaignId, campaignId));
  }

  async createCampaignApplication(application: InsertCampaignApplication): Promise<CampaignApplication> {
    const result = await db.insert(campaignApplications).values(application).returning();
    return result[0];
  }

  async updateCampaignApplication(id: string, updates: Partial<InsertCampaignApplication>): Promise<CampaignApplication> {
    const result = await db.update(campaignApplications).set(updates as any).where(eq(campaignApplications.id, id)).returning();
    return result[0];
  }

  async getAvailableCampaignsForCreator(userId: string): Promise<Campaign[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    const userApplications = await this.getCampaignApplicationsByUser(userId);
    const appliedCampaignIds = new Set(userApplications.map(app => app.campaignId));
    
    const allCampaigns = await db.select().from(campaigns);
    
    return allCampaigns.filter(campaign => {
      // Exclude campaigns user has already applied to
      if (appliedCampaignIds.has(campaign.id)) return false;
      
      // Only show active campaigns
      if (campaign.status !== "active") return false;
      
      // Check country targeting
      if (campaign.targetCountries && campaign.targetCountries.length > 0) {
        if (!user.country || !campaign.targetCountries.includes(user.country)) {
          return false;
        }
      }
      
      return true;
    });
  }
}

export const storage = new DatabaseStorage();
