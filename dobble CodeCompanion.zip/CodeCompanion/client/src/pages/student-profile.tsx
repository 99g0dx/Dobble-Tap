import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, GraduationCap, Camera, Save } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function StudentProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    bio: "",
    age: "",
    gender: "",
    state: "",
    country: "Nigeria",
    school: "",
    instagramHandle: "",
    twitterHandle: "",
    youtubeHandle: "",
    facebookHandle: "",
    tiktokHandle: "",
    snapchatHandle: "",
    linkedinHandle: ""
  });

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    onSuccess: (data) => {
      setFormData({
        name: data.name || "",
        email: data.email || "",
        phone: data.phone || "",
        bio: data.bio || "",
        age: data.age?.toString() || "",
        gender: data.gender || "",
        state: data.state || "",
        country: data.country || "Nigeria",
        school: data.school || "",
        instagramHandle: data.instagramHandle || "",
        twitterHandle: data.twitterHandle || "",
        youtubeHandle: data.youtubeHandle || "",
        facebookHandle: data.facebookHandle || "",
        tiktokHandle: data.tiktokHandle || "",
        snapchatHandle: data.snapchatHandle || "",
        linkedinHandle: data.linkedinHandle || ""
      });
    }
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest(`/api/users/${user.id}`, "PUT", data);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setIsEditing(false);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updateData = {
      ...formData,
      age: formData.age ? parseInt(formData.age) : null
    };
    updateProfileMutation.mutate(updateData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white">Student Ambassador Profile</h1>
          </div>
          <Button
            onClick={() => setIsEditing(!isEditing)}
            variant={isEditing ? "outline" : "default"}
            className={isEditing ? "border-gray-600 text-gray-300" : "bg-blue-600 hover:bg-blue-700"}
          >
            {isEditing ? "Cancel" : "Edit Profile"}
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Picture */}
          <Card className="lg:col-span-1 bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="text-center">
                <div className="w-32 h-32 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-12 h-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">{user?.name}</h3>
                <p className="text-gray-400 capitalize">{user?.role}</p>
                <p className="text-blue-400 text-sm mt-1">{formData.school}</p>
                <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                  Upload Photo
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Profile Form */}
          <Card className="lg:col-span-2 bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Profile Information</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-white">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      disabled={!isEditing}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      disabled={true}
                      className="bg-gray-700 border-gray-600 text-white opacity-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-white">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      disabled={!isEditing}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="age" className="text-white">Age</Label>
                    <Input
                      id="age"
                      type="number"
                      value={formData.age}
                      onChange={(e) => setFormData({...formData, age: e.target.value})}
                      disabled={!isEditing}
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="gender" className="text-white">Gender</Label>
                    <Select value={formData.gender} onValueChange={(value) => setFormData({...formData, gender: value})} disabled={!isEditing}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state" className="text-white">State</Label>
                    <Input
                      id="state"
                      value={formData.state}
                      onChange={(e) => setFormData({...formData, state: e.target.value})}
                      disabled={!isEditing}
                      placeholder="Enter your state"
                      className="bg-gray-700 border-gray-600 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="country" className="text-white">Country</Label>
                    <Select value={formData.country} onValueChange={(value) => setFormData({...formData, country: value})} disabled={!isEditing}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Nigeria">Nigeria</SelectItem>
                        <SelectItem value="Ghana">Ghana</SelectItem>
                        <SelectItem value="Kenya">Kenya</SelectItem>
                        <SelectItem value="South Africa">South Africa</SelectItem>
                        <SelectItem value="Egypt">Egypt</SelectItem>
                        <SelectItem value="Morocco">Morocco</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="school" className="text-white">School/Institution</Label>
                    <Input
                      id="school"
                      value={formData.school}
                      onChange={(e) => setFormData({...formData, school: e.target.value})}
                      disabled={!isEditing}
                      placeholder="Enter your school or institution"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="text-white">Tell us about yourself</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData({...formData, bio: e.target.value})}
                    disabled={!isEditing}
                    placeholder="Share your story, interests, and what makes you unique..."
                    className="bg-gray-700 border-gray-600 text-white min-h-[100px]"
                  />
                </div>

                {/* Social Media Handles */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-white">Social Media Handles</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="instagramHandle" className="text-white">Instagram</Label>
                      <Input
                        id="instagramHandle"
                        value={formData.instagramHandle}
                        onChange={(e) => setFormData({...formData, instagramHandle: e.target.value})}
                        disabled={!isEditing}
                        placeholder="@username"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="twitterHandle" className="text-white">Twitter/X</Label>
                      <Input
                        id="twitterHandle"
                        value={formData.twitterHandle}
                        onChange={(e) => setFormData({...formData, twitterHandle: e.target.value})}
                        disabled={!isEditing}
                        placeholder="@username"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tiktokHandle" className="text-white">TikTok</Label>
                      <Input
                        id="tiktokHandle"
                        value={formData.tiktokHandle}
                        onChange={(e) => setFormData({...formData, tiktokHandle: e.target.value})}
                        disabled={!isEditing}
                        placeholder="@username"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="youtubeHandle" className="text-white">YouTube</Label>
                      <Input
                        id="youtubeHandle"
                        value={formData.youtubeHandle}
                        onChange={(e) => setFormData({...formData, youtubeHandle: e.target.value})}
                        disabled={!isEditing}
                        placeholder="@username"
                        className="bg-gray-700 border-gray-600 text-white"
                      />
                    </div>
                  </div>
                </div>

                {isEditing && (
                  <Button
                    type="submit"
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Save Changes
                      </>
                    )}
                  </Button>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}