# Paystack Webhook Setup - Detailed Guide

## Step 1: Access Paystack Dashboard
1. Go to [https://dashboard.paystack.com/](https://dashboard.paystack.com/)
2. Log in with your Paystack account
3. Make sure you're in "Live" mode (toggle at the top right)

## Step 2: Navigate to API Keys & Webhooks
1. In the left sidebar, click **"Settings"**
2. Click **"API Keys & Webhooks"**
3. Scroll down to find the **"Webhooks"** section

## Step 3: Add New Webhook
1. In the Webhooks section, click **"Add Endpoint"** or **"+"** button
2. Enter the URL: `https://www.dobbletap.com/api/payments/webhook`
3. Look for an **"Events"** dropdown or checkboxes

## Step 4: Select Events (Alternative Methods)

### Method A: If you see checkboxes
Look for these checkboxes and select them:
- ✅ `charge.success`
- ✅ `charge.failed` 
- ✅ `transfer.success`
- ✅ `transfer.failed`

### Method B: If you see a dropdown menu
1. Click on the Events dropdown
2. Select "Custom Events"
3. Choose the 4 events listed above

### Method C: If you see "All Events" option
1. You can select "All Events" for now
2. This will include the events we need plus others

## Step 5: Save the Webhook
1. Click **"Save"** or **"Create Webhook"**
2. You should see your webhook listed with status "Active"

## Alternative: Simplified Webhook Setup

If you can't find the specific events section:

1. **Add the webhook URL**: `https://www.dobbletap.com/api/payments/webhook`
2. **Select "All Events"** (this includes what we need)
3. **Save the webhook**

This will work fine - your platform will only respond to the events it needs and ignore others.

## Verification
After saving, you should see:
- Webhook URL: `https://www.dobbletap.com/api/payments/webhook`
- Status: Active
- Events: Either your selected events or "All Events"

## If You Still Can't Find Events Section

The events section might be on a separate page. Try:
1. Click on the webhook after creating it
2. Look for an "Edit" or "Configure" button
3. Check if there's a separate "Events" tab

## Contact Paystack Support
If you're still having trouble:
- Use the chat support in your Paystack dashboard
- Ask: "How do I configure webhook events for my endpoint?"
- They can guide you through their current interface

## For Now: Basic Webhook Setup
**Minimum required**: Just add the webhook URL and save it. The platform will work with basic webhook notifications.