import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  DollarSign, 
  CheckCircle, 
  Activity, 
  TrendingUp, 
  Instagram, 
  Twitter, 
  Youtube,
  Clock,
  Upload,
  CreditCard,
  User,
  Home,
  HelpCircle
} from "lucide-react";

export default function CreatorDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch creator stats
  const { data: stats = {
    totalEarnings: 0,
    tasksCompleted: 0,
    activeCampaigns: 0,
    successRate: 0,
    followers: 0
  }, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/creator-stats"],
    retry: 1
  });

  // Fetch available tasks
  const { data: availableTasks = [], isLoading: tasksLoading } = useQuery({
    queryKey: ["/api/tasks"],
    retry: 1
  });

  // Fetch user's task submissions
  const { data: myTasks = [], isLoading: myTasksLoading } = useQuery({
    queryKey: ["/api/task-submissions"],
    retry: 1
  });

  // Apply to task mutation
  const applyToTaskMutation = useMutation({
    mutationFn: (taskId: string) => apiRequest(`/api/tasks/${taskId}/apply`, {
      method: "POST"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/task-submissions"] });
      toast({
        title: "Application submitted",
        description: "You've successfully applied to this task!"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error applying to task",
        description: error.message || "Something went wrong"
      });
    }
  });

  // Withdraw funds mutation
  const withdrawFundsMutation = useMutation({
    mutationFn: (amount: number) => apiRequest("/api/payments/withdraw", {
      method: "POST",
      body: JSON.stringify({ amount })
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/creator-stats"] });
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal will be processed within 24 hours."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error processing withdrawal",
        description: error.message || "Something went wrong"
      });
    }
  });

  const handleApplyToTask = (taskId: string) => {
    applyToTaskMutation.mutate(taskId);
  };

  const handleWithdrawFunds = () => {
    withdrawFundsMutation.mutate(stats.totalEarnings);
  };

  const handleViewProfile = () => {
    setLocation("/profile");
  };

  const handleHelp = () => {
    setLocation("/help");
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'instagram':
        return <Instagram className="w-5 h-5" />;
      case 'twitter':
        return <Twitter className="w-5 h-5" />;
      case 'youtube':
        return <Youtube className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'instagram':
        return 'bg-pink-500';
      case 'twitter':
        return 'bg-blue-500';
      case 'youtube':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'pending-review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-black via-gray-900 to-red-900 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center py-4 lg:py-6 gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 w-full lg:w-auto">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white hover:text-blue-400 transition-colors duration-200"
              >
                <h1 className="text-xl sm:text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-white/30 pl-6 flex items-center space-x-4 hidden sm:flex">
                <Avatar className="w-12 h-12 sm:w-16 sm:h-16 border-4 border-white/20 shadow-lg">
                  <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b75a7ad4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" />
                  <AvatarFallback className="bg-white text-blue-600 font-bold">CR</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Creator Dashboard</h2>
                  <p className="text-gray-300 mt-1 text-sm sm:text-base">Content Creator & Lifestyle Influencer</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 sm:hidden">
                <Avatar className="w-12 h-12 border-4 border-white/20 shadow-lg">
                  <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b75a7ad4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" />
                  <AvatarFallback className="bg-white text-blue-600 font-bold">CR</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-xl font-bold text-white tracking-tight">Creator Dashboard</h2>
                  <p className="text-gray-300 mt-1 text-sm">Content Creator & Lifestyle Influencer</p>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button 
                onClick={handleHelp}
                className="bg-gray-600 text-white hover:bg-gray-700 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Help
              </Button>
              <Button 
                onClick={handleViewProfile}
                className="bg-blue-600 text-white hover:bg-blue-700 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
              >
                <User className="w-4 h-4 mr-2" />
                View Profile
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-4 bg-white shadow-xl border-2 border-gray-200 h-14 rounded-2xl">
            <TabsTrigger value="overview" className="data-[state=active]:bg-black data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Overview</TabsTrigger>
            <TabsTrigger value="tasks" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Available Tasks</TabsTrigger>
            <TabsTrigger value="my-tasks" className="data-[state=active]:bg-black data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">My Tasks</TabsTrigger>
            <TabsTrigger value="earnings" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Earnings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Stats Cards */}
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8 mb-8">
              <div className="flex items-center mb-6">
                <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                <h2 className="text-2xl font-bold text-black">Creator Overview</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Total Earnings</p>
                        <p className="text-3xl font-bold text-black">{formatCurrency(stats.totalEarnings)}</p>
                      </div>
                      <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <DollarSign className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Tasks Completed</p>
                        <p className="text-3xl font-bold text-black">{stats.tasksCompleted}</p>
                      </div>
                      <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <CheckCircle className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Active Campaigns</p>
                        <p className="text-3xl font-bold text-black">{stats.activeCampaigns}</p>
                      </div>
                      <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Activity className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Success Rate</p>
                        <p className="text-3xl font-bold text-black">{stats.successRate}%</p>
                      </div>
                      <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <TrendingUp className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Total Followers</p>
                        <p className="text-3xl font-bold text-black">{stats.followers?.toLocaleString() || 0}</p>
                      </div>
                      <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Users className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl transition-all duration-300 hover:border-blue-300">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-black flex items-center">
                    <div className="w-2 h-6 bg-blue-600 rounded-full mr-3"></div>
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={handleWithdrawFunds}
                    className="w-full justify-start bg-blue-600 hover:bg-blue-700 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
                    disabled={withdrawFundsMutation.isPending || stats.totalEarnings === 0}
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Withdraw Funds ({formatCurrency(stats.totalEarnings)})
                  </Button>
                  <Button 
                    onClick={() => setActiveTab("tasks")}
                    className="w-full justify-start bg-black hover:bg-gray-800 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    Browse Available Tasks
                  </Button>
                  <Button 
                    onClick={handleViewProfile}
                    className="w-full justify-start bg-blue-600 hover:bg-blue-700 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
                  >
                    <User className="w-4 h-4 mr-2" />
                    View Profile
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl transition-all duration-300 hover:border-blue-300">
                <CardHeader className="pb-4">
                  <CardTitle className="text-xl text-black flex items-center">
                    <div className="w-2 h-6 bg-blue-600 rounded-full mr-3"></div>
                    Recent Activity
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-3 h-3 bg-blue-600 rounded-full shadow-sm"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-black">Task completed</p>
                        <p className="text-xs text-gray-600">2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-3 h-3 bg-black rounded-full shadow-sm"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-black">Applied to new campaign</p>
                        <p className="text-xs text-gray-600">Yesterday</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-3 h-3 bg-blue-600 rounded-full shadow-sm"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-black">Payment received</p>
                        <p className="text-xs text-gray-600">2 days ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center">
                  <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                  <h2 className="text-2xl font-bold text-black">Available Tasks</h2>
                </div>
                <div className="px-4 py-2 bg-blue-600 text-white rounded-full font-semibold shadow-lg">
                  {availableTasks.length} tasks available
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {availableTasks.map((task: any) => (
                  <Card key={task.id} className="hover:shadow-2xl transition-all duration-300 border-2 border-gray-200 shadow-xl bg-white hover:scale-105 group hover:border-blue-300">
                    <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getPlatformColor(task.platform)}`}>
                        {getPlatformIcon(task.platform)}
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{task.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span>Reward:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(task.reward || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Campaign:</span>
                        <span>{task.campaignName || 'Individual Task'}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Deadline:</span>
                        <span>{task.deadline ? new Date(task.deadline).toLocaleDateString() : 'No deadline'}</span>
                      </div>
                    </div>

                    <Button 
                      onClick={() => handleApplyToTask(task.id)}
                      className="w-full"
                      disabled={applyToTaskMutation.isPending}
                    >
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
              </div>

              {availableTasks.length === 0 && (
                <div className="text-center py-12">
                  <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No tasks available</h3>
                  <p className="text-gray-600">Check back later for new opportunities</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="my-tasks" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center">
                  <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                  <h2 className="text-2xl font-bold text-black">My Tasks</h2>
                </div>
                <div className="px-4 py-2 bg-black text-white rounded-full font-semibold shadow-lg">
                  {myTasks.length} tasks in progress
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {myTasks.map((task: any) => (
                  <Card key={task.id} className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 hover:border-blue-300">
                    <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <Badge className={getStatusColor(task.status)}>
                        {task.status?.replace('-', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between text-sm">
                        <span>Reward:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(task.reward || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Status:</span>
                        <span className="capitalize">{task.status?.replace('-', ' ')}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Submitted:</span>
                        <span>{new Date(task.createdAt).toLocaleDateString()}</span>
                      </div>
                      
                      {task.progress && (
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progress:</span>
                            <span>{task.progress}%</span>
                          </div>
                          <Progress value={task.progress} className="h-2" />
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                        {task.status === 'in-progress' && (
                          <Button size="sm">
                            Continue
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              </div>

              {myTasks.length === 0 && (
                <div className="text-center py-12">
                  <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-black mb-2">No tasks yet</h3>
                  <p className="text-gray-600 mb-4">Start by applying to available tasks</p>
                  <Button onClick={() => setActiveTab("tasks")} className="bg-blue-600 hover:bg-blue-700 text-white">
                    Browse Tasks
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="earnings" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex items-center mb-6">
                <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                <h2 className="text-2xl font-bold text-black">Earnings Overview</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-2 border-gray-200 shadow-lg bg-white hover:shadow-xl transition-all duration-300 hover:border-blue-300">
                  <CardContent className="p-6">
                    <h3 className="font-medium text-gray-600 mb-2">Available Balance</h3>
                    <p className="text-3xl font-bold text-black">{formatCurrency(stats.totalEarnings)}</p>
                  </CardContent>
                </Card>
                <Card className="border-2 border-gray-200 shadow-lg bg-white hover:shadow-xl transition-all duration-300 hover:border-blue-300">
                  <CardContent className="p-6">
                    <h3 className="font-medium text-gray-600 mb-2">This Month</h3>
                    <p className="text-3xl font-bold text-black">{formatCurrency(stats.totalEarnings * 0.3)}</p>
                  </CardContent>
                </Card>
                <Card className="border-2 border-gray-200 shadow-lg bg-white hover:shadow-xl transition-all duration-300 hover:border-blue-300">
                  <CardContent className="p-6">
                    <h3 className="font-medium text-gray-600 mb-2">All Time</h3>
                    <p className="text-3xl font-bold text-black">{formatCurrency(stats.totalEarnings * 2)}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-8">
                <Button 
                  onClick={handleWithdrawFunds}
                  className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg px-8 py-3 text-lg font-semibold"
                  disabled={withdrawFundsMutation.isPending || stats.totalEarnings === 0}
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Withdraw {formatCurrency(stats.totalEarnings)}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}