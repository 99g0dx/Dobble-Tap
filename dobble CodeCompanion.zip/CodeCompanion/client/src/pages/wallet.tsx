import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Wallet, Plus, ArrowUpRight, ArrowDownLeft, DollarSign, TrendingUp, History, CreditCard } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function WalletPage() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");
  const [fundAmount, setFundAmount] = useState("");
  const [fundingDialogOpen, setFundingDialogOpen] = useState(false);
  const [error, setError] = useState("");

  // Fetch wallet balance
  const { data: walletData = { balance: 0, currency: "NGN" } } = useQuery({
    queryKey: ["/api/wallet/balance"],
    retry: 1
  });

  // Fetch wallet transactions
  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/wallet/transactions"],
    retry: 1
  });

  // Fetch payment history
  const { data: payments = [] } = useQuery({
    queryKey: ["/api/payments"],
    retry: 1
  });

  // Fund wallet mutation
  const fundWalletMutation = useMutation({
    mutationFn: async (amount: number) => {
      return apiRequest("/api/wallet/fund", "POST", { amount });
    },
    onSuccess: (data) => {
      if (data.authorization_url) {
        window.location.href = data.authorization_url;
      }
    },
    onError: (error: any) => {
      setError(error.message || "Failed to initiate funding");
    }
  });

  const formatCurrency = (amount: number, currency: string = "NGN") => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleFundWallet = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    const amount = parseFloat(fundAmount);
    if (isNaN(amount) || amount <= 0) {
      setError("Please enter a valid amount");
      return;
    }

    if (amount < 100) {
      setError("Minimum funding amount is ₦100");
      return;
    }

    fundWalletMutation.mutate(amount);
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "credit":
      case "funding":
        return <ArrowDownLeft className="w-4 h-4 text-green-600" />;
      case "debit":
      case "payment":
        return <ArrowUpRight className="w-4 h-4 text-red-600" />;
      default:
        return <DollarSign className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
      case "success":
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Failed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gray-900 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <div className="flex items-center space-x-6">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white hover:text-blue-400 transition-colors duration-200"
              >
                <h1 className="text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-white/30 pl-6">
                <h2 className="text-3xl font-bold text-white tracking-tight">My Wallet</h2>
                <p className="text-gray-300 mt-1">Manage your earnings and transactions</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-3 bg-white shadow-xl border-2 border-gray-200 h-14 rounded-2xl">
            <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white font-semibold">
              Overview
            </TabsTrigger>
            <TabsTrigger value="transactions" className="data-[state=active]:bg-black data-[state=active]:text-white font-semibold">
              Transactions
            </TabsTrigger>
            <TabsTrigger value="payments" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white font-semibold">
              Payment History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Balance Card */}
            <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white border-0 shadow-2xl">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-white">
                  <Wallet className="w-6 h-6 mr-2" />
                  Current Balance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-4xl font-bold">
                    {formatCurrency(walletData.balance, walletData.currency)}
                  </div>
                  <div className="flex gap-4">
                    <Dialog open={fundingDialogOpen} onOpenChange={setFundingDialogOpen}>
                      <DialogTrigger asChild>
                        <Button className="bg-white text-blue-600 hover:bg-gray-100">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Money
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Money to Wallet</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={handleFundWallet} className="space-y-4">
                          {error && (
                            <Alert className="border-red-200 bg-red-50">
                              <AlertDescription className="text-red-600">
                                {error}
                              </AlertDescription>
                            </Alert>
                          )}
                          <div className="space-y-2">
                            <Label htmlFor="amount">Amount (NGN)</Label>
                            <Input
                              id="amount"
                              type="number"
                              value={fundAmount}
                              onChange={(e) => setFundAmount(e.target.value)}
                              placeholder="Enter amount"
                              min="100"
                              step="0.01"
                              required
                            />
                            <p className="text-sm text-gray-500">Minimum amount: ₦100</p>
                          </div>
                          <Button
                            type="submit"
                            className="w-full bg-blue-600 hover:bg-blue-700"
                            disabled={fundWalletMutation.isPending}
                          >
                            {fundWalletMutation.isPending ? "Processing..." : "Add Money"}
                          </Button>
                        </form>
                      </DialogContent>
                    </Dialog>
                    <Button variant="outline" className="text-white border-white hover:bg-white/10">
                      <ArrowUpRight className="w-4 h-4 mr-2" />
                      Withdraw
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-2 border-gray-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Earned</p>
                      <p className="text-2xl font-bold text-green-600">
                        {formatCurrency(12500)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-gray-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">This Month</p>
                      <p className="text-2xl font-bold text-blue-600">
                        {formatCurrency(3200)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-gray-200 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Pending</p>
                      <p className="text-2xl font-bold text-yellow-600">
                        {formatCurrency(850)}
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                      <History className="w-6 h-6 text-yellow-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-6">
            <Card className="border-2 border-gray-200 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-black">
                  <History className="w-5 h-5 mr-2" />
                  Recent Transactions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No transactions yet</p>
                  ) : (
                    transactions.map((transaction: any) => (
                      <div key={transaction.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          {getTransactionIcon(transaction.type)}
                          <div>
                            <p className="font-medium text-black">{transaction.description}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(transaction.createdAt).toLocaleDateString()} at{" "}
                              {new Date(transaction.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-bold ${transaction.type === "credit" ? "text-green-600" : "text-red-600"}`}>
                            {transaction.type === "credit" ? "+" : "-"}{formatCurrency(transaction.amount)}
                          </p>
                          {getStatusBadge(transaction.status)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payments" className="space-y-6">
            <Card className="border-2 border-gray-200 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-black">
                  <CreditCard className="w-5 h-5 mr-2" />
                  Payment History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {payments.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No payments yet</p>
                  ) : (
                    payments.map((payment: any) => (
                      <div key={payment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <CreditCard className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-black">
                              {payment.campaignId ? "Campaign Payment" : "Task Payment"}
                            </p>
                            <p className="text-sm text-gray-500">
                              Ref: {payment.reference}
                            </p>
                            <p className="text-sm text-gray-500">
                              {new Date(payment.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600">
                            +{formatCurrency(payment.amount, payment.currency)}
                          </p>
                          {getStatusBadge(payment.status)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}