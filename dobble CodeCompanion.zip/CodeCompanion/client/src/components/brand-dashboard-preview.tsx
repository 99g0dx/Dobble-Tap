import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function BrandDashboardPreview() {
  const campaignAnalytics = [
    { title: "Impressions", value: "2.3M", bgColor: "bg-blue-50" },
    { title: "Engagement", value: "18.5%", bgColor: "bg-green-50" },
    { title: "Clicks", value: "45.2K", bgColor: "bg-purple-50" },
    { title: "Conversions", value: "1,234", bgColor: "bg-orange-50" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-4xl text-dark mb-4">
            Brand Campaign Manager
          </h2>
          <p className="text-xl text-gray max-w-3xl mx-auto">
            Launch, manage, and track your campaigns with powerful analytics and creator collaboration tools.
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-6xl mx-auto">
          {/* Campaign Creation Form */}
          <div className="mb-8">
            <h4 className="font-poppins font-semibold text-lg text-dark mb-6">Create New Campaign</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-sm font-medium text-gray mb-2">Campaign Name</Label>
                <Input 
                  placeholder="Summer Fashion Collection 2024" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-gray mb-2">Budget</Label>
                <Input 
                  placeholder="₦500,000" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>
              <div>
                <Label className="text-sm font-medium text-gray mb-2">Target Audience</Label>
                <Select>
                  <SelectTrigger className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                    <SelectValue placeholder="Select target audience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="young-adults">Young Adults (18-30)</SelectItem>
                    <SelectItem value="fashion">Fashion Enthusiasts</SelectItem>
                    <SelectItem value="students">Students</SelectItem>
                    <SelectItem value="professionals">Professionals</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray mb-2">Campaign Duration</Label>
                <Input 
                  placeholder="2 weeks" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>
            </div>
            <div className="mt-6">
              <Label className="text-sm font-medium text-gray mb-2">Campaign Description</Label>
              <Textarea 
                placeholder="Describe your campaign objectives, key messages, and requirements for creators..." 
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary h-32 resize-none"
              />
            </div>
            <div className="mt-6 flex justify-end">
              <Button className="bg-primary text-white hover:bg-primary/90">
                Create Campaign
              </Button>
            </div>
          </div>

          {/* Active Campaigns */}
          <div className="border-t border-gray-200 pt-8">
            <h4 className="font-poppins font-semibold text-lg text-dark mb-6">Active Campaigns</h4>
            <div className="space-y-6">
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-4">
                  <div className="flex-1">
                    <h5 className="font-poppins font-medium text-lg text-dark mb-2">Summer Fashion Collection 2024</h5>
                    <p className="text-gray text-sm mb-3">Promote our new summer collection through Instagram stories and posts</p>
                    <div className="flex items-center space-x-6 text-sm text-gray">
                      <span>🗓️ 8 days remaining</span>
                      <span>💰 ₦450,000 budget</span>
                      <span>👥 15/20 creators</span>
                    </div>
                  </div>
                  <div className="mt-4 lg:mt-0 lg:ml-6">
                    <span className="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">Active</span>
                  </div>
                </div>
                
                {/* Campaign Analytics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  {campaignAnalytics.map((metric, index) => (
                    <div key={index} className={`${metric.bgColor} p-4 rounded-lg`}>
                      <p className="text-sm text-gray">{metric.title}</p>
                      <p className="font-poppins font-bold text-lg text-dark">{metric.value}</p>
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-end space-x-3">
                  <Button variant="ghost" className="text-gray hover:text-primary">
                    View Details
                  </Button>
                  <Button className="bg-secondary text-white hover:bg-secondary/90">
                    Manage
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
