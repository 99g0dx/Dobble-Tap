# Paystack Live Keys Setup for Dobble Tap

## Step 1: Access Paystack Dashboard

1. Go to [Paystack Dashboard](https://dashboard.paystack.com/)
2. Log in with your Paystack account
3. If you don't have an account, create one first

## Step 2: Switch to Live Mode

1. Look for a toggle switch in the top navigation
2. It will say "Test" or "Live"
3. Click to switch to "Live" mode
4. You'll see the interface change to show live data

## Step 3: Get Your Live API Keys

1. In the left sidebar, click "Settings"
2. Click "API Keys & Webhooks"
3. You'll see two keys:
   - **Public Key**: starts with `pk_live_`
   - **Secret Key**: starts with `sk_live_`
4. Click "Show" next to each key to reveal the full key
5. Copy both keys

## Step 4: Set Up Webhook URL

1. Still in "API Keys & Webhooks" section
2. Scroll down to "Webhooks"
3. Click "Add webhook endpoint"
4. Enter URL: `https://www.dobbletap.com/api/payments/webhook`
5. Select events:
   - `charge.success`
   - `charge.failed`
   - `transfer.success`
   - `transfer.failed`
6. Click "Save"

## Step 5: Add to Environment Variables

In your hosting provider's environment variables section, add:
```
PAYSTACK_SECRET_KEY=sk_live_your_actual_secret_key_here
PAYSTACK_PUBLIC_KEY=pk_live_your_actual_public_key_here
```

Replace with your actual keys from Step 3.

## Important Notes

- **Never share your secret key publicly**
- **Test keys start with `pk_test_` and `sk_test_`**
- **Live keys start with `pk_live_` and `sk_live_`**
- **Only use live keys in production**

## Business Verification

For live mode, Paystack may require:
1. Business verification
2. Bank account details
3. KYC documentation

Complete these requirements in your Paystack dashboard if prompted.

## Testing Live Keys

After setup, test with a small amount:
1. Create a campaign with minimum budget
2. Process payment
3. Check if webhook receives notification
4. Verify transaction appears in Paystack dashboard