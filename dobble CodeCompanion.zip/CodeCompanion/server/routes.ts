import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { authenticateUser, requireRole, type AuthRequest } from "./middleware/auth";
import { authenticateToken, generateToken, hashPassword, comparePassword, setupGoogleOAuth } from "./auth";
import passport from "passport";
import { paystackService } from "./services/paystack";
import { emailService } from "./services/email";
import { walletService } from "./services/wallet";
import { analyticsService } from "./services/analytics";
import { performanceService } from "./services/performance";
import { performLaunchCheck } from "./services/launch-check";
import { 
  insertUserSchema, 
  insertCampaignSchema, 
  insertTaskSchema, 
  insertTaskSubmissionSchema,
  insertPaymentSchema,
  insertNotificationSchema,
  insertCampaignApplicationSchema
} from "@shared/schema";
import { z } from "zod";
import crypto from "crypto";

// Extend session data type
declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

// Session configuration
const sessionConfig = {
  secret: process.env.SESSION_SECRET || "dobble-tap-secret-key-change-in-production",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
  },
};

// Validation schemas
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

const registerSchema = insertUserSchema.extend({
  password: z.string().min(6),
});

const verifyEmailSchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

const resendCodeSchema = z.object({
  email: z.string().email(),
});

const paymentInitSchema = z.object({
  amount: z.number().positive(),
  taskId: z.string().optional(),
  campaignId: z.string().optional(),
});

const supportTicketSchema = z.object({
  subject: z.string().min(5),
  category: z.string().min(1),
  priority: z.string().min(1),
  description: z.string().min(20),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session(sessionConfig));

  // Initialize passport and Google OAuth
  app.use(passport.initialize());
  app.use(passport.session());
  setupGoogleOAuth();

  // Authentication Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      const { password, ...userData } = validatedData;
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      // Hash password
      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({ ...userData, password: hashedPassword });
      
      // Generate JWT token
      const token = generateToken(user);
      
      // Set session for backward compatibility
      req.session.userId = user.id;
      
      // Create welcome notification
      await storage.createNotification({
        userId: user.id,
        title: "Welcome to Dobble Tap!",
        message: `Welcome ${user.name}! Your account has been created successfully.`,
        type: "welcome",
        data: { userId: user.id }
      });

      // Send welcome email
      await emailService.sendWelcomeEmail(user.email, user.name, user.role);

      res.status(201).json({ user, token });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Registration failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Verify password
      const isPasswordValid = await comparePassword(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Generate JWT token
      const token = generateToken(user);
      
      // Set session for backward compatibility
      req.session.userId = user.id;
      
      res.json({ user, token });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Login failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if user exists or not for security
        return res.json({ message: "If an account with this email exists, a reset link has been sent" });
      }

      // In a real application, you would:
      // 1. Generate a secure reset token
      // 2. Store it in the database with expiration
      // 3. Send an email with the reset link
      // For now, we'll just simulate the process
      
      console.log(`Password reset requested for: ${email}`);
      res.json({ message: "If an account with this email exists, a reset link has been sent" });
    } catch (error) {
      console.error("Forgot password error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Google OAuth routes (only if credentials are provided)
  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    app.get("/api/auth/google", passport.authenticate("google", { scope: ["profile", "email"] }));

    app.get("/api/auth/google/callback", 
      passport.authenticate("google", { failureRedirect: "/login" }),
      async (req, res) => {
      try {
        const user = req.user as User;
        
        // Generate JWT token
        const token = generateToken(user);
        
        // Set session for backward compatibility
        req.session.userId = user.id;
        
        // Create welcome notification for new users
        const existingNotifications = await storage.getNotificationsByUser(user.id);
        const hasWelcomeNotification = existingNotifications.some(n => n.type === "welcome");
        
        if (!hasWelcomeNotification) {
          await storage.createNotification({
            userId: user.id,
            title: "Welcome to Dobble Tap!",
            message: `Welcome ${user.name}! Your account has been created successfully.`,
            type: "welcome",
            data: { userId: user.id }
          });
        }
        
        // Redirect to appropriate dashboard based on role
        const dashboardPath = user.role === "brand" ? "/brand-dashboard" : 
                            user.role === "student" ? "/student-dashboard" : 
                            "/creator-dashboard";
        
        res.redirect(dashboardPath);
      } catch (error) {
        console.error("Google OAuth callback error:", error);
        res.redirect("/login?error=oauth");
      }
    }
  );
  } else {
    // Fallback route if Google OAuth is not configured
    app.get("/api/auth/google", (req, res) => {
      res.status(503).json({ message: "Google OAuth not configured" });
    });
  }

  // Update user role route for Google OAuth users
  app.post("/api/auth/update-role", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { role } = req.body;
      
      if (!role || !["creator", "brand", "student"].includes(role)) {
        return res.status(400).json({ message: "Invalid role selected" });
      }

      const updatedUser = await storage.updateUser(req.user.id, { role });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Role update error:", error);
      res.status(500).json({ message: "Failed to update role" });
    }
  });

  app.get("/api/auth/me", authenticateToken, (req: AuthRequest, res) => {
    res.json(req.user);
  });

  // User Routes
  app.get("/api/users/:id", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error fetching user", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/users/:id", authenticateUser, async (req: AuthRequest, res) => {
    try {
      if (req.user.id !== req.params.id) {
        return res.status(403).json({ message: "Cannot update other users" });
      }
      
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Error updating user", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Campaign Routes
  app.get("/api/campaigns", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const campaigns = await storage.getCampaignsByUser(req.user.id);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Error fetching campaigns", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/campaigns", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertCampaignSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      const campaign = await storage.createCampaign(validatedData);
      
      // Create notification
      await storage.createNotification({
        userId: req.user.id,
        title: "Campaign Created",
        message: `Your campaign "${campaign.name}" has been created successfully.`,
        type: "campaign_created",
        data: { campaignId: campaign.id }
      });

      res.status(201).json(campaign);
    } catch (error) {
      res.status(400).json({ message: "Error creating campaign", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/campaigns/:id", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      // Check if user owns the campaign or is an admin
      if (campaign.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json(campaign);
    } catch (error) {
      res.status(500).json({ message: "Error fetching campaign", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/campaigns/:id", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      if (campaign.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updates = req.body;
      const updatedCampaign = await storage.updateCampaign(req.params.id, updates);
      res.json(updatedCampaign);
    } catch (error) {
      res.status(500).json({ message: "Error updating campaign", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.delete("/api/campaigns/:id", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      if (campaign.userId !== req.user.id) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      await storage.deleteCampaign(req.params.id);
      res.json({ message: "Campaign deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Error deleting campaign", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Task Routes
  app.get("/api/tasks", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const tasks = await storage.getAvailableTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/tasks", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertTaskSchema.parse(req.body);
      
      // Verify campaign ownership
      const campaign = await storage.getCampaign(validatedData.campaignId);
      if (!campaign || campaign.userId !== req.user.id) {
        return res.status(403).json({ message: "Campaign not found or access denied" });
      }
      
      const task = await storage.createTask(validatedData);
      res.status(201).json(task);
    } catch (error) {
      res.status(400).json({ message: "Error creating task", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/tasks/:id", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Error fetching task", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/campaigns/:id/tasks", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const campaign = await storage.getCampaign(req.params.id);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      // Check if user owns the campaign or is a creator
      if (campaign.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const tasks = await storage.getTasksByCampaign(req.params.id);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching tasks", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Task Submission Routes
  app.get("/api/task-submissions", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const submissions = await storage.getTaskSubmissionsByUser(req.user.id);
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching submissions", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/task-submissions", authenticateUser, requireRole("creator"), async (req: AuthRequest, res) => {
    try {
      const validatedData = insertTaskSubmissionSchema.parse({
        ...req.body,
        userId: req.user.id
      });
      
      // Verify task exists and is active
      const task = await storage.getTask(validatedData.taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      if (task.status !== "active") {
        return res.status(400).json({ message: "Task is not active" });
      }
      
      // Check if user already submitted for this task
      const existingSubmissions = await storage.getTaskSubmissionsByTask(validatedData.taskId);
      const userSubmission = existingSubmissions.find(s => s.userId === req.user.id);
      if (userSubmission) {
        return res.status(400).json({ message: "Already submitted for this task" });
      }
      
      const submission = await storage.createTaskSubmission(validatedData);
      
      // Create notification
      await storage.createNotification({
        userId: req.user.id,
        title: "Task Submitted",
        message: `Your submission for "${task.title}" has been received and is under review.`,
        type: "task_submitted",
        data: { taskId: task.id, submissionId: submission.id }
      });

      res.status(201).json(submission);
    } catch (error) {
      res.status(400).json({ message: "Error creating submission", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/tasks/:id/submissions", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Verify user owns the campaign or is admin
      const campaign = await storage.getCampaign(task.campaignId);
      if (!campaign || (campaign.userId !== req.user.id && req.user.role !== "admin")) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const submissions = await storage.getTaskSubmissionsByTask(req.params.id);
      res.json(submissions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching submissions", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/task-submissions/:id", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const submission = await storage.getTaskSubmission(req.params.id);
      if (!submission) {
        return res.status(404).json({ message: "Submission not found" });
      }
      
      const task = await storage.getTask(submission.taskId);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      const campaign = await storage.getCampaign(task.campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      // Check permissions
      if (campaign.userId !== req.user.id && req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updates = req.body;
      const updatedSubmission = await storage.updateTaskSubmission(req.params.id, updates);
      
      // Create notification for status changes
      if (updates.status) {
        let notificationMessage = "";
        let notificationType = "";
        
        if (updates.status === "approved") {
          notificationMessage = `Your submission for "${task.title}" has been approved! Payment will be processed shortly.`;
          notificationType = "task_approved";
          
          // Create payment record
          await storage.createPayment({
            userId: submission.userId,
            taskId: task.id,
            campaignId: task.campaignId,
            amount: task.rewardAmount,
            currency: "NGN",
            status: "pending",
            paymentMethod: "paystack",
            reference: `task_${task.id}_${submission.id}_${Date.now()}`,
            metadata: {
              taskTitle: task.title,
              submissionId: submission.id
            }
          });
        } else if (updates.status === "rejected") {
          notificationMessage = `Your submission for "${task.title}" has been rejected. ${updates.adminNotes || "Please check the requirements and try again."}`;
          notificationType = "task_rejected";
        }
        
        if (notificationMessage) {
          await storage.createNotification({
            userId: submission.userId,
            title: "Task Status Update",
            message: notificationMessage,
            type: notificationType,
            data: { taskId: task.id, submissionId: submission.id }
          });
        }
      }
      
      res.json(updatedSubmission);
    } catch (error) {
      res.status(500).json({ message: "Error updating submission", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Wallet Routes
  app.get("/api/wallet/balance", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const userId = req.user.id;
      
      // First ensure the user exists in the database
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const balance = await walletService.getWalletBalance(userId);
      res.json(balance);
    } catch (error) {
      console.error("Wallet balance error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/wallet/transactions", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const userId = req.user.id;
      
      // First ensure the user exists in the database
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const transactions = await walletService.getWalletTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Wallet transactions error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/wallet/fund", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const userId = req.user.id;
      const { amount } = req.body;
      
      if (!amount || parseFloat(amount) <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const reference = `fund_${userId}_${Date.now()}`;
      const amountInKobo = parseFloat(amount) * 100;

      const paymentData = await paystackService.initializePayment({
        email: user.email,
        amount: amountInKobo,
        reference,
        callback_url: `${process.env.FRONTEND_URL || 'http://localhost:5000'}/wallet/callback`,
        metadata: {
          purpose: "wallet_funding",
          userId,
        },
      });

      res.json({
        authorization_url: paymentData.data.authorization_url,
        access_code: paymentData.data.access_code,
        reference: paymentData.data.reference,
      });
    } catch (error) {
      console.error("Wallet funding error:", error);
      res.status(500).json({ message: "Failed to initialize payment" });
    }
  });

  app.post("/api/wallet/verify/:reference", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const { reference } = req.params;
      const userId = req.user.id;

      const verification = await paystackService.verifyPayment(reference);
      
      if (verification.data.status === "success") {
        const amountInNaira = (verification.data.amount / 100).toFixed(2);
        
        await walletService.addFunds(
          userId,
          amountInNaira,
          reference,
          `Wallet funding via Paystack`
        );

        // Create notification
        await storage.createNotification({
          userId,
          type: "wallet_funded",
          title: "Wallet Funded Successfully",
          message: `Your wallet has been funded with ₦${amountInNaira}`,
          read: false,
          data: { amount: amountInNaira, reference }
        });

        res.json({ success: true, amount: amountInNaira });
      } else {
        res.status(400).json({ message: "Payment verification failed" });
      }
    } catch (error) {
      console.error("Payment verification error:", error);
      res.status(500).json({ message: "Payment verification failed" });
    }
  });

  // Payment Routes
  app.get("/api/payments", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const payments = await storage.getPaymentsByUser(req.user.id);
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Error fetching payments", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/payments/initialize", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const validatedData = paymentInitSchema.parse(req.body);
      
      const reference = `payment_${req.user.id}_${Date.now()}`;
      
      // Initialize payment with Paystack
      const paystackResponse = await paystackService.initializePayment({
        email: req.user.email,
        amount: validatedData.amount,
        reference,
        callback_url: `${process.env.APP_URL || 'http://localhost:5000'}/payment/callback`,
        metadata: {
          userId: req.user.id,
          taskId: validatedData.taskId,
          campaignId: validatedData.campaignId
        }
      });
      
      // Create payment record
      await storage.createPayment({
        userId: req.user.id,
        taskId: validatedData.taskId,
        campaignId: validatedData.campaignId,
        amount: validatedData.amount.toString(),
        currency: "NGN",
        status: "pending",
        paymentMethod: "paystack",
        reference,
        gatewayResponse: paystackResponse,
        metadata: {
          taskId: validatedData.taskId,
          campaignId: validatedData.campaignId
        }
      });
      
      res.json(paystackResponse);
    } catch (error) {
      res.status(500).json({ message: "Error initializing payment", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/payments/verify/:reference", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const { reference } = req.params;
      
      // Verify payment with Paystack
      const paystackResponse = await paystackService.verifyPayment(reference);
      
      if (paystackResponse.status && paystackResponse.data.status === "success") {
        // Update payment status
        const payments = await storage.getPaymentsByUser(req.user.id);
        const payment = payments.find(p => p.reference === reference);
        
        if (payment) {
          await storage.updatePayment(payment.id, {
            status: "completed",
            gatewayResponse: paystackResponse
          });
          
          // Create notification
          await storage.createNotification({
            userId: req.user.id,
            title: "Payment Received",
            message: `You have received ₦${payment.amount} for your task completion.`,
            type: "payment_received",
            data: { paymentId: payment.id, amount: payment.amount }
          });
        }
      }
      
      res.json(paystackResponse);
    } catch (error) {
      res.status(500).json({ message: "Error verifying payment", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/payments/webhook", async (req, res) => {
    try {
      const signature = req.headers["x-paystack-signature"] as string;
      const body = JSON.stringify(req.body);
      
      if (!paystackService.verifyWebhook(body, signature)) {
        console.warn('Invalid webhook signature', { 
          signature, 
          timestamp: new Date().toISOString(),
          ip: req.ip 
        });
        return res.status(400).json({ message: "Invalid signature" });
      }
      
      const event = req.body;
      
      await performanceService.trackApiCall('webhook-processing', async () => {
        if (event.event === "charge.success") {
          const reference = event.data.reference;
          const userId = event.data.metadata.userId;
          
          // Find and update payment
          const payments = await storage.getPaymentsByUser(userId);
          const payment = payments.find(p => p.reference === reference);
          
          if (payment) {
            await storage.updatePayment(payment.id, {
              status: "completed",
              gatewayResponse: event,
              verifiedAt: new Date().toISOString()
            });
            
            // Create notification
            await storage.createNotification({
              userId: payment.userId,
              title: "Payment Confirmed",
              message: `Your payment of ₦${payment.amount} has been confirmed.`,
              type: "payment_confirmed",
              data: { paymentId: payment.id, amount: payment.amount }
            });
            
            // Send payment confirmation email
            const user = await storage.getUser(userId);
            if (user) {
              await emailService.sendPaymentConfirmationEmail({
                userEmail: user.email,
                userName: user.firstName || user.email,
                amount: payment.amount,
                reference: payment.reference || '',
                transactionDate: new Date().toISOString()
              });
            }
            
            // Track analytics
            await analyticsService.trackUserActivity(userId, 'payment_confirmed', {
              amount: payment.amount,
              reference: payment.reference
            });
          }
        }
      });
      
      res.status(200).json({ message: "Webhook processed successfully" });
    } catch (error) {
      console.error('Webhook processing error:', error);
      res.status(500).json({ message: "Webhook error", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Notification Routes
  app.get("/api/notifications", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const notifications = await storage.getNotificationsByUser(req.user.id);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Error fetching notifications", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Support ticket route
  app.post("/api/support/ticket", authenticateUser, async (req: AuthRequest, res) => {
    try {
      const validatedData = supportTicketSchema.parse(req.body);
      
      // Create support ticket ID
      const ticketId = `TICKET_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // For now, we'll just log the ticket and send an email notification
      console.log("Support Ticket Created:", {
        ticketId,
        userId: req.user.id,
        userEmail: req.user.email,
        ...validatedData,
        createdAt: new Date().toISOString()
      });
      
      // Send email notification to support team
      try {
        await emailService.sendSupportTicketEmail({
          ticketId,
          userEmail: req.user.email,
          subject: validatedData.subject,
          category: validatedData.category,
          priority: validatedData.priority,
          description: validatedData.description,
          createdAt: new Date().toISOString()
        });
      } catch (emailError) {
        console.error("Failed to send support ticket email:", emailError);
      }
      
      // Create notification for user
      await storage.createNotification({
        userId: req.user.id,
        title: "Support Ticket Submitted",
        message: `Your support ticket "${validatedData.subject}" has been submitted. We'll respond within 24 hours.`,
        type: "support_ticket",
        data: { ticketId, subject: validatedData.subject }
      });
      
      res.json({ 
        success: true, 
        ticketId,
        message: "Support ticket submitted successfully" 
      });
    } catch (error) {
      console.error("Support ticket error:", error);
      res.status(500).json({ message: "Error submitting support ticket", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/notifications/:id/read", authenticateUser, async (req: AuthRequest, res) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Error updating notification", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Campaign Application Routes
  app.get("/api/campaigns/available", authenticateUser, requireRole("creator"), async (req: AuthRequest, res) => {
    try {
      const campaigns = await storage.getAvailableCampaignsForCreator(req.user.id);
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ message: "Error fetching available campaigns", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.post("/api/campaigns/:id/apply", authenticateUser, requireRole("creator"), async (req: AuthRequest, res) => {
    try {
      const campaignId = req.params.id;
      
      // Check if campaign exists
      const campaign = await storage.getCampaign(campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      // Check if user has already applied
      const existingApplications = await storage.getCampaignApplicationsByUser(req.user.id);
      const hasApplied = existingApplications.some(app => app.campaignId === campaignId);
      
      if (hasApplied) {
        return res.status(400).json({ message: "You have already applied to this campaign" });
      }
      
      // Create application (no message required)
      const application = await storage.createCampaignApplication({
        campaignId,
        userId: req.user.id,
        status: campaign.autoApprove ? "approved" : "pending"
      });
      
      // Send notification to brand owner
      await storage.createNotification({
        userId: campaign.userId,
        title: "New Campaign Application",
        message: `${req.user.name} has applied to your campaign "${campaign.name}"`,
        type: "campaign_application",
        data: { campaignId, applicationId: application.id }
      });
      
      // Send notification to creator
      const notificationMessage = campaign.autoApprove 
        ? `Your application to "${campaign.name}" has been automatically approved!`
        : `Your application to "${campaign.name}" has been submitted and is under review.`;
      
      await storage.createNotification({
        userId: req.user.id,
        title: campaign.autoApprove ? "Application Approved" : "Application Submitted",
        message: notificationMessage,
        type: campaign.autoApprove ? "application_approved" : "application_submitted",
        data: { campaignId, applicationId: application.id }
      });
      
      res.status(201).json(application);
    } catch (error) {
      res.status(500).json({ message: "Error applying to campaign", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/campaigns/:id/applications", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const campaignId = req.params.id;
      
      // Verify campaign ownership
      const campaign = await storage.getCampaign(campaignId);
      if (!campaign || campaign.userId !== req.user.id) {
        return res.status(403).json({ message: "Campaign not found or access denied" });
      }
      
      const applications = await storage.getCampaignApplicationsByCampaign(campaignId);
      
      // Get user details for each application
      const applicationsWithUsers = await Promise.all(
        applications.map(async (app) => {
          const user = await storage.getUser(app.userId);
          return {
            ...app,
            user: user ? {
              id: user.id,
              name: user.name,
              email: user.email,
              country: user.country,
              instagramHandle: user.instagramHandle,
              twitterHandle: user.twitterHandle,
              tiktokHandle: user.tiktokHandle,
              youtubeHandle: user.youtubeHandle
            } : null
          };
        })
      );
      
      res.json(applicationsWithUsers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching applications", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.put("/api/applications/:id/review", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const applicationId = req.params.id;
      const { status, brandNotes } = req.body;
      
      if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status. Must be 'approved' or 'rejected'" });
      }
      
      const application = await storage.updateCampaignApplication(applicationId, {
        status,
        brandNotes
      });
      
      // Get campaign details for notification
      const campaign = await storage.getCampaign(application.campaignId);
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }
      
      // Send notification to creator
      const notificationMessage = status === "approved" 
        ? `Congratulations! Your application to "${campaign.name}" has been approved. You can now start working on tasks for this campaign.`
        : `Your application to "${campaign.name}" has been rejected. ${brandNotes || "Please check the requirements and consider applying to other campaigns."}`;
      
      await storage.createNotification({
        userId: application.userId,
        title: status === "approved" ? "Application Approved" : "Application Rejected",
        message: notificationMessage,
        type: status === "approved" ? "application_approved" : "application_rejected",
        data: { campaignId: application.campaignId, applicationId: application.id }
      });
      
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Error reviewing application", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Payment distribution route for approved creators
  app.post("/api/campaigns/:id/distribute-payments", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const campaignId = req.params.id;
      
      // Verify campaign ownership
      const campaign = await storage.getCampaign(campaignId);
      if (!campaign || campaign.userId !== req.user.id) {
        return res.status(403).json({ message: "Campaign not found or access denied" });
      }
      
      // Get all approved creators for this campaign
      const applications = await storage.getCampaignApplicationsByCampaign(campaignId);
      const approvedApplications = applications.filter(app => app.status === "approved");
      
      if (approvedApplications.length === 0) {
        return res.status(400).json({ message: "No approved creators found for this campaign" });
      }
      
      // Calculate payment per creator
      const totalBudget = parseFloat(campaign.budget);
      const paymentPerCreator = totalBudget / approvedApplications.length;
      
      // Validate minimum payment amount (₦5,000 equivalent)
      const minimumPayment = 5000; // ₦5,000 minimum
      if (paymentPerCreator < minimumPayment) {
        const maxCreators = Math.floor(totalBudget / minimumPayment);
        return res.status(400).json({ 
          message: `Campaign budget too low for ${approvedApplications.length} creators. Maximum ${maxCreators} creators can be approved with ₦${minimumPayment.toLocaleString()} minimum payment each.`,
          maxCreators,
          minimumPayment,
          currentPaymentPerCreator: paymentPerCreator.toFixed(2)
        });
      }
      
      // Process payments for each approved creator
      const paymentPromises = approvedApplications.map(async (application) => {
        const reference = `campaign_${campaignId}_${application.userId}_${Date.now()}`;
        
        // Create payment record
        const payment = await storage.createPayment({
          userId: application.userId,
          campaignId: campaignId,
          amount: paymentPerCreator.toFixed(2),
          currency: campaign.currency,
          status: "pending",
          paymentMethod: "paystack",
          reference,
          metadata: {
            campaignId,
            applicationId: application.id,
            paymentType: "campaign_distribution"
          }
        });
        
        // Send notification to creator
        await storage.createNotification({
          userId: application.userId,
          title: "Payment Processing",
          message: `Your payment of ${campaign.currency === "NGN" ? "₦" : "$"}${paymentPerCreator.toFixed(2)} for "${campaign.name}" is being processed.`,
          type: "payment_processing",
          data: { campaignId, paymentId: payment.id, amount: paymentPerCreator }
        });
        
        return payment;
      });
      
      const payments = await Promise.all(paymentPromises);
      
      res.json({
        message: "Payments distributed successfully",
        totalCreators: approvedApplications.length,
        paymentPerCreator: paymentPerCreator.toFixed(2),
        currency: campaign.currency,
        payments
      });
    } catch (error) {
      res.status(500).json({ message: "Error distributing payments", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Dashboard Stats Routes
  app.get("/api/dashboard/creator-stats", authenticateUser, requireRole("creator"), async (req: AuthRequest, res) => {
    try {
      const userId = req.user.id;
      
      const stats = await performanceService.trackApiCall('creator-stats', async () => {
        return await analyticsService.getUserStats(userId);
      });
      
      // Track user activity
      await analyticsService.trackUserActivity(userId, 'view_dashboard_stats');
      
      res.json(stats);
    } catch (error) {
      console.error("Creator stats error:", error);
      res.status(500).json({ message: "Error fetching creator stats" });
    }
  });

  app.get("/api/dashboard/brand-stats", authenticateUser, requireRole("brand"), async (req: AuthRequest, res) => {
    try {
      const campaigns = await storage.getCampaignsByUser(req.user.id);
      const activeCampaigns = campaigns.filter(c => c.status === "active").length;
      const totalSpent = campaigns.reduce((sum, c) => sum + parseFloat(c.budget), 0);
      
      res.json({
        activeCampaigns,
        totalSpent,
        totalCampaigns: campaigns.length,
        totalReach: 2300000, // Mock data - would come from analytics
        avgEngagement: 18.5  // Mock data - would come from analytics
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching stats", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "OK", message: "Dobble Tap API is running" });
  });

  // Launch readiness check endpoint
  app.get("/api/launch-check", async (req, res) => {
    try {
      const result = await performLaunchCheck();
      res.json(result);
    } catch (error) {
      console.error("Launch check error:", error);
      res.status(500).json({ message: "Launch check failed", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });
  
  // Performance metrics endpoint
  app.get("/api/performance", async (req, res) => {
    try {
      const metrics = performanceService.getMetrics();
      res.json(metrics);
    } catch (error) {
      console.error("Performance metrics error:", error);
      res.status(500).json({ message: "Error fetching performance metrics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
