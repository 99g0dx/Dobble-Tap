import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogDescription 
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  Wallet, 
  Plus, 
  Loader2 
} from "lucide-react";
import { formatCurrency } from "@/lib/currencies";
import WalletCard from "./wallet-card";
import { useAuth } from "@/hooks/use-auth";

interface WalletBalance {
  balance: string;
  currency: string;
}

export default function WalletButton() {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  const { data: balance, isLoading } = useQuery<WalletBalance>({
    queryKey: ["/api/wallet/balance"],
    enabled: !!user,
  });

  if (!user) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="flex items-center gap-3 bg-white border-2 border-gray-300 hover:bg-gray-50 hover:border-primary shadow-md hover:shadow-lg transition-all duration-200"
        >
          <Wallet className="h-4 w-4" />
          <div className="flex flex-col items-start">
            <span className="text-xs text-muted-foreground font-medium">Balance</span>
            <span className="text-base font-bold text-green-600">
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                formatCurrency(parseFloat(balance?.balance || "0"), balance?.currency || "NGN")
              )}
            </span>
          </div>
          <Badge variant="default" className="ml-2 bg-primary text-white hover:bg-primary/90">
            <Plus className="h-3 w-3 mr-1" />
            Fund
          </Badge>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Wallet Management
          </DialogTitle>
          <DialogDescription>
            View your balance, fund your wallet, and manage your transactions
          </DialogDescription>
        </DialogHeader>
        <WalletCard />
      </DialogContent>
    </Dialog>
  );
}