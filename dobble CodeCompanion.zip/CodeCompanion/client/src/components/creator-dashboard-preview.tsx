import { Button } from "@/components/ui/button";
import { Users, DollarSign, CheckCircle, Activity, TrendingUp, Instagram, Twitter } from "lucide-react";

export default function CreatorDashboardPreview() {
  const stats = [
    { title: "Total Earnings", value: "₦145,230", icon: DollarSign, bgColor: "bg-green-50", iconColor: "bg-green-500" },
    { title: "Tasks Completed", value: "47", icon: CheckCircle, bgColor: "bg-blue-50", iconColor: "bg-blue-500" },
    { title: "Active Campaigns", value: "8", icon: Activity, bgColor: "bg-purple-50", iconColor: "bg-purple-500" },
    { title: "Success Rate", value: "94%", icon: TrendingUp, bgColor: "bg-orange-50", iconColor: "bg-orange-500" }
  ];

  const availableTasks = [
    {
      platform: "Instagram",
      icon: Instagram,
      iconColor: "bg-pink-500",
      title: "Instagram Story Promotion",
      brand: "Fashion Brand Campaign",
      description: "Create an engaging Instagram story showcasing our new summer collection. Include branded hashtags and product mentions.",
      timeLeft: "3 days left",
      spots: "8/10 spots filled",
      reward: "₦15,000"
    },
    {
      platform: "Twitter",
      icon: Twitter,
      iconColor: "bg-blue-500",
      title: "Twitter Engagement Campaign",
      brand: "Tech Startup Launch",
      description: "Tweet about our new mobile app launch with specific hashtags and mention key features that resonate with your audience.",
      timeLeft: "5 days left",
      spots: "12/15 spots filled",
      reward: "₦8,500"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-4xl text-dark mb-4">
            Creator Dashboard
          </h2>
          <p className="text-xl text-gray max-w-3xl mx-auto">
            Manage your campaigns, track earnings, and grow your influence from one powerful dashboard.
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-6xl mx-auto">
          {/* Dashboard Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div className="flex items-center space-x-4">
              <img 
                src="https://images.unsplash.com/photo-1494790108755-2616b75a7ad4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" 
                alt="Creator profile" 
                className="w-16 h-16 rounded-full object-cover" 
              />
              <div>
                <h3 className="font-poppins font-semibold text-xl text-dark">Amara Okafor</h3>
                <p className="text-gray">Content Creator & Lifestyle Influencer</p>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-sm text-gray">@amaraokafor</span>
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4 text-gray" />
                    <span className="text-sm text-gray">12.5K followers</span>
                  </div>
                </div>
              </div>
            </div>
            <Button className="bg-primary text-white hover:bg-primary/90 mt-4 md:mt-0">
              View Profile
            </Button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <div key={index} className={`${stat.bgColor} p-6 rounded-lg`}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray">{stat.title}</p>
                    <p className="font-poppins font-bold text-2xl text-dark">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${stat.iconColor} rounded-full flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Available Tasks */}
          <div className="mb-8">
            <h4 className="font-poppins font-semibold text-lg text-dark mb-4">Available Tasks</h4>
            <div className="space-y-4">
              {availableTasks.map((task, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className={`w-10 h-10 ${task.iconColor} rounded-full flex items-center justify-center`}>
                          <task.icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h5 className="font-medium text-dark">{task.title}</h5>
                          <p className="text-sm text-gray">{task.brand}</p>
                        </div>
                      </div>
                      <p className="text-gray text-sm mb-2">{task.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray">
                        <span>⏰ {task.timeLeft}</span>
                        <span>👥 {task.spots}</span>
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 md:ml-6 text-right">
                      <p className="font-poppins font-bold text-xl text-primary">{task.reward}</p>
                      <Button className="bg-primary text-white hover:bg-primary/90 mt-2">
                        Apply Now
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
