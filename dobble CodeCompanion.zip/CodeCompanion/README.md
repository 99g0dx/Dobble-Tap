# Dobble Tap Platform

> **African Creator Monetization Platform** - Connecting content creators with brands through task-based promotional work

![Platform Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)
![Version](https://img.shields.io/badge/Version-1.0.0-blue)
![Completion](https://img.shields.io/badge/Completion-95%25-success)

## 🌟 Overview

Dobble Tap is a comprehensive creator monetization platform designed specifically for the African market. It connects content creators with brands through a task-based system where creators complete promotional tasks and earn money instantly.

### Key Features
- **Multi-Role System**: Creators, Brands, and Students
- **Task-Based Earning**: Complete promotional tasks for instant payment
- **Geographic Targeting**: Country-specific campaign targeting
- **Real-Time Payments**: Instant payouts via Paystack
- **SMM Panel**: Micro-earning tasks for social media activities
- **Analytics Dashboard**: Real-time performance tracking

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- Paystack account (for payments)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/dobble-tap-platform.git
   cd dobble-tap-platform
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Set up database**
   ```bash
   npm run db:push
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

## 🏗️ Architecture

### Tech Stack
- **Frontend**: React + TypeScript + Tailwind CSS
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Payments**: Paystack integration
- **Authentication**: JWT + Session-based
- **Email**: Resend service

### Project Structure
```
dobble-tap-platform/
├── client/             # React frontend
│   ├── src/
│   │   ├── components/ # UI components
│   │   ├── pages/      # Application pages
│   │   └── lib/        # Utilities
├── server/             # Express backend
│   ├── middleware/     # Security & auth
│   ├── services/       # Business logic
│   └── routes.ts       # API endpoints
├── shared/             # Shared types & schema
└── docs/              # Documentation
```

## 🔧 Configuration

### Environment Variables
```env
# Database
DATABASE_URL=your_postgres_connection_string

# Payments
PAYSTACK_PUBLIC_KEY=pk_live_xxx
PAYSTACK_SECRET_KEY=sk_live_xxx

# Authentication
JWT_SECRET=your_jwt_secret
SESSION_SECRET=your_session_secret

# Email
RESEND_API_KEY=your_resend_key

# Google OAuth (optional)
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
```

## 📊 Features

### For Creators
- Browse and apply to campaigns
- Complete tasks with proof submission
- Real-time earnings tracking
- Instant payment withdrawals
- Social media profile integration

### For Brands
- Create targeted campaigns
- Geographic and demographic targeting
- Real-time analytics
- Creator selection and approval
- Payment distribution system

### For Students
- Educational campaign access
- Flexible earning opportunities
- Academic profile integration
- Study-friendly task scheduling

## 🔒 Security

- Rate limiting on API endpoints
- Input validation and sanitization
- CORS protection
- Helmet.js security headers
- JWT token authentication
- Session management

## 📈 Performance

- **User Capacity**: 10,000-15,000 daily active users
- **Concurrent Users**: 1,000-2,000 simultaneously
- **API Requests**: 50,000-100,000 per day
- **Geographic Coverage**: 195+ countries

## 🚀 Deployment

### Production Build
```bash
npm run build
npm run start
```

### Environment Setup
1. Set up production database
2. Configure Paystack live keys
3. Set up domain and SSL
4. Configure email service

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🌍 African Market Focus

Built specifically for the African creator economy with:
- Local payment methods (Paystack)
- Multi-currency support
- Geographic targeting
- Cultural relevance
- Mobile-first design

## 📞 Support

- Email: support@dobletap.com
- Documentation: [docs.dobletap.com](https://docs.dobletap.com)
- Issues: GitHub Issues

---

**Made with ❤️ for the African Creator Economy**