import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Shield, Lock, Eye, FileText } from "lucide-react";
import { useLocation } from "wouter";

export default function PrivacyPolicy() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/")}
                className="text-white hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div className="border-l border-gray-600 pl-4">
                <h1 className="text-2xl font-bold text-white">Privacy Policy</h1>
                <p className="text-gray-300 text-sm">Last updated: January 2025</p>
              </div>
            </div>
            <Shield className="w-8 h-8 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Introduction */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Introduction
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Welcome to Dobble Tap, Africa's leading creator monetization platform. We are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, and protect your information when you use our platform.
              </p>
            </CardContent>
          </Card>

          {/* Information We Collect */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-blue-600" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Personal Information</h3>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Name, email address, and phone number</li>
                  <li>Profile information and bio</li>
                  <li>Social media handles and account information</li>
                  <li>Payment information (bank details for withdrawals)</li>
                  <li>Location data (country and state)</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Usage Information</h3>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Campaign participation and task completion data</li>
                  <li>Platform usage analytics and engagement metrics</li>
                  <li>Communication history and support tickets</li>
                  <li>Device information and IP addresses</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Financial Information</h3>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Payment transactions and history</li>
                  <li>Earnings and withdrawal records</li>
                  <li>Tax information where applicable</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* How We Use Your Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-blue-600" />
                How We Use Your Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Platform Operations</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Facilitate campaign matching between creators and brands</li>
                    <li>Process payments and manage earnings</li>
                    <li>Provide customer support and resolve disputes</li>
                    <li>Verify user identities and prevent fraud</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Communication</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Send transactional emails and notifications</li>
                    <li>Provide updates about campaigns and opportunities</li>
                    <li>Share important platform announcements</li>
                    <li>Respond to support inquiries</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Platform Improvement</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Analyze platform usage to improve user experience</li>
                    <li>Develop new features and services</li>
                    <li>Ensure platform security and prevent abuse</li>
                    <li>Comply with legal and regulatory requirements</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Data Protection */}
          <Card>
            <CardHeader>
              <CardTitle>Data Protection & Security</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>We implement robust security measures to protect your personal information:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Encryption of sensitive data in transit and at rest</li>
                  <li>Regular security audits and vulnerability assessments</li>
                  <li>Limited access to personal information on a need-to-know basis</li>
                  <li>Secure payment processing through trusted providers</li>
                  <li>Regular backups and disaster recovery procedures</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Data Sharing */}
          <Card>
            <CardHeader>
              <CardTitle>Data Sharing & Third Parties</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>We may share your information with:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li><strong>Payment Processors:</strong> To process payments and withdrawals</li>
                  <li><strong>Service Providers:</strong> For email delivery, analytics, and customer support</li>
                  <li><strong>Legal Authorities:</strong> When required by law or to protect our rights</li>
                  <li><strong>Business Partners:</strong> With your explicit consent for specific campaigns</li>
                </ul>
                <p className="text-sm text-gray-600">
                  We never sell your personal information to third parties for marketing purposes.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Your Rights */}
          <Card>
            <CardHeader>
              <CardTitle>Your Rights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>You have the right to:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Access and review your personal information</li>
                  <li>Update or correct inaccurate information</li>
                  <li>Request deletion of your account and data</li>
                  <li>Opt-out of marketing communications</li>
                  <li>Data portability and export</li>
                  <li>Lodge complaints with data protection authorities</li>
                </ul>
                <p className="text-sm text-gray-600">
                  To exercise these rights, contact us at privacy@dobletap.com
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Cookies */}
          <Card>
            <CardHeader>
              <CardTitle>Cookies & Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                We use cookies and similar technologies to enhance your experience:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700">
                <li><strong>Essential Cookies:</strong> Required for platform functionality</li>
                <li><strong>Analytics Cookies:</strong> To understand platform usage</li>
                <li><strong>Preference Cookies:</strong> To remember your settings</li>
                <li><strong>Marketing Cookies:</strong> For relevant advertising (with consent)</li>
              </ul>
              <p className="text-sm text-gray-600 mt-4">
                You can manage cookie preferences in your browser settings.
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                If you have questions about this Privacy Policy or your data, contact us:
              </p>
              <div className="space-y-2 text-gray-700">
                <p><strong>Email:</strong> privacy@dobletap.com</p>
                <p><strong>Support:</strong> support@dobletap.com</p>
                <p><strong>Address:</strong> Lagos, Nigeria</p>
              </div>
              <p className="text-sm text-gray-600 mt-4">
                This Privacy Policy may be updated periodically. We will notify you of significant changes.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}