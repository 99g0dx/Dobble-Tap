import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, DollarSign, Users, Clock, ExternalLink } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Tasks() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("available");
  const [searchTerm, setSearchTerm] = useState("");
  const [platformFilter, setPlatformFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  // Fetch available tasks
  const { data: availableTasks = [], isLoading: availableLoading } = useQuery({
    queryKey: ["/api/campaigns/available"],
    retry: 1
  });

  // Fetch user's applied tasks
  const { data: myTasks = [], isLoading: myTasksLoading } = useQuery({
    queryKey: ["/api/tasks/my-tasks"],
    retry: 1
  });

  // Apply to campaign mutation
  const applyMutation = useMutation({
    mutationFn: async (campaignId: string) => {
      return apiRequest(`/api/campaigns/${campaignId}/apply`, "POST", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns/available"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks/my-tasks"] });
    }
  });

  const formatCurrency = (amount: number, currency: string = "NGN") => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0
    }).format(amount);
  };

  const filteredTasks = availableTasks.filter((task: any) => {
    const matchesSearch = task.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPlatform = platformFilter === "all" || 
                           task.preferredPlatforms?.includes(platformFilter);
    
    const matchesType = typeFilter === "all" || task.type === typeFilter;
    
    return matchesSearch && matchesPlatform && matchesType;
  });

  const getPlatformBadgeColor = (platform: string) => {
    const colors: { [key: string]: string } = {
      instagram: "bg-pink-500",
      twitter: "bg-blue-500",
      tiktok: "bg-black",
      youtube: "bg-red-500",
      snapchat: "bg-yellow-500"
    };
    return colors[platform] || "bg-gray-500";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gray-900 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <div className="flex items-center space-x-6">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white hover:text-blue-400 transition-colors duration-200"
              >
                <h1 className="text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-white/30 pl-6">
                <h2 className="text-3xl font-bold text-white tracking-tight">Available Tasks</h2>
                <p className="text-gray-300 mt-1">Discover and apply to brand campaigns</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 bg-white shadow-xl border-2 border-gray-200 h-14 rounded-2xl">
            <TabsTrigger value="available" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white font-semibold">
              Available Tasks
            </TabsTrigger>
            <TabsTrigger value="my-tasks" className="data-[state=active]:bg-black data-[state=active]:text-white font-semibold">
              My Applications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-6">
            {/* Filters */}
            <div className="bg-white rounded-2xl shadow-lg border-2 border-gray-200 p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      placeholder="Search campaigns..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 border-2 border-gray-300 focus:border-blue-600 h-12"
                    />
                  </div>
                </div>
                <Select value={platformFilter} onValueChange={setPlatformFilter}>
                  <SelectTrigger className="w-full md:w-48 border-2 border-gray-300 focus:border-blue-600 h-12">
                    <SelectValue placeholder="Platform" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Platforms</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="twitter">Twitter</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="snapchat">Snapchat</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full md:w-48 border-2 border-gray-300 focus:border-blue-600 h-12">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="regular">Regular Campaign</SelectItem>
                    <SelectItem value="smm">SMM Panel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Task Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {availableLoading ? (
                <div className="col-span-full flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-500 text-lg">No tasks available matching your criteria</p>
                </div>
              ) : (
                filteredTasks.map((task: any) => (
                  <Card key={task.id} className="border-2 border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <CardTitle className="text-lg font-bold text-black mb-2">
                            {task.name}
                          </CardTitle>
                          <Badge 
                            variant={task.type === "regular" ? "default" : "secondary"}
                            className="mb-2"
                          >
                            {task.type === "regular" ? "Regular Campaign" : "SMM Panel"}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">
                            {formatCurrency(task.budget, task.currency)}
                          </div>
                          <div className="text-sm text-gray-500">{task.currency}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-600 line-clamp-3">{task.description}</p>
                      
                      {task.preferredPlatforms && (
                        <div className="flex flex-wrap gap-2">
                          {task.preferredPlatforms.map((platform: string) => (
                            <Badge 
                              key={platform}
                              className={`${getPlatformBadgeColor(platform)} text-white`}
                            >
                              {platform}
                            </Badge>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {task.minFollowers ? `${task.minFollowers}+ followers` : "No minimum"}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {task.maxCreators} spots
                        </div>
                      </div>
                      
                      <Button
                        onClick={() => applyMutation.mutate(task.id)}
                        disabled={applyMutation.isPending}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {applyMutation.isPending ? "Applying..." : "Apply Now"}
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="my-tasks" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {myTasksLoading ? (
                <div className="col-span-full flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : myTasks.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-500 text-lg">You haven't applied to any tasks yet</p>
                </div>
              ) : (
                myTasks.map((application: any) => (
                  <Card key={application.id} className="border-2 border-gray-200 shadow-lg">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg font-bold text-black">
                          {application.campaign?.name}
                        </CardTitle>
                        <Badge 
                          variant={
                            application.status === "approved" ? "default" : 
                            application.status === "rejected" ? "destructive" : "secondary"
                          }
                        >
                          {application.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-gray-600 line-clamp-3">
                        {application.campaign?.description}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-lg font-bold text-blue-600">
                          {formatCurrency(application.campaign?.budget, application.campaign?.currency)}
                        </div>
                        <div className="text-sm text-gray-500">
                          Applied {new Date(application.appliedAt).toLocaleDateString()}
                        </div>
                      </div>
                      
                      {application.status === "approved" && (
                        <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View Task Details
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}