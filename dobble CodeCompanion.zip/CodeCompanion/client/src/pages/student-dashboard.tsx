import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Users, 
  DollarSign, 
  CheckCircle, 
  Activity, 
  TrendingUp, 
  Clock,
  Star,
  Award,
  Target,
  Play,
  User,
  CreditCard,
  Instagram,
  Twitter,
  Youtube,
  GraduationCap,
  Home,
  HelpCircle
} from "lucide-react";

export default function StudentDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch student stats (same as creator stats)
  const { data: stats = {
    totalEarnings: 0,
    tasksCompleted: 0,
    activeCampaigns: 0,
    successRate: 0,
    followers: 0
  }, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/creator-stats"],
    retry: 1
  });

  // Fetch available tasks
  const { data: availableTasks = [], isLoading: tasksLoading } = useQuery({
    queryKey: ["/api/tasks"],
    retry: 1
  });

  // Fetch user's task submissions
  const { data: myTasks = [], isLoading: myTasksLoading } = useQuery({
    queryKey: ["/api/task-submissions"],
    retry: 1
  });

  // Apply to task mutation
  const applyToTaskMutation = useMutation({
    mutationFn: (taskId: string) => apiRequest(`/api/tasks/${taskId}/apply`, {
      method: "POST"
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/task-submissions"] });
      toast({
        title: "Application submitted",
        description: "You've successfully applied to this task!"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error applying to task",
        description: error.message || "Something went wrong"
      });
    }
  });

  // Withdraw funds mutation
  const withdrawFundsMutation = useMutation({
    mutationFn: (amount: number) => apiRequest("/api/payments/withdraw", {
      method: "POST",
      body: JSON.stringify({ amount })
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/creator-stats"] });
      toast({
        title: "Withdrawal request submitted",
        description: "Your withdrawal will be processed within 24 hours."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error processing withdrawal",
        description: error.message || "Something went wrong"
      });
    }
  });

  const handleApplyToTask = (taskId: string) => {
    applyToTaskMutation.mutate(taskId);
  };

  const handleWithdrawFunds = () => {
    withdrawFundsMutation.mutate(stats.totalEarnings);
  };

  const handleViewProfile = () => {
    setLocation("/profile");
  };

  const handleHelp = () => {
    setLocation("/help");
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'instagram':
        return <Instagram className="w-5 h-5" />;
      case 'twitter':
        return <Twitter className="w-5 h-5" />;
      case 'youtube':
        return <Youtube className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  const getPlatformColor = (platform: string) => {
    switch (platform?.toLowerCase()) {
      case 'instagram':
        return 'bg-pink-500';
      case 'twitter':
        return 'bg-blue-500';
      case 'youtube':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'pending-review':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center py-4 gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 w-full lg:w-auto">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white hover:text-blue-400 transition-colors duration-200"
              >
                <h1 className="text-xl sm:text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-white/30 pl-6 flex items-center space-x-4 hidden sm:flex">
                <Avatar className="w-12 h-12 border-2 border-blue-600">
                  <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" />
                  <AvatarFallback className="bg-blue-600 text-white">ST</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white">Student Dashboard</h2>
                  <p className="text-gray-300 text-sm sm:text-base">Student & Campus Ambassador</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 sm:hidden">
                <Avatar className="w-12 h-12 border-2 border-blue-600">
                  <AvatarImage src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" />
                  <AvatarFallback className="bg-blue-600 text-white">ST</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="text-xl font-bold text-white">Student Dashboard</h2>
                  <p className="text-gray-300 text-sm">Student & Campus Ambassador</p>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button 
                onClick={handleHelp}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Help
              </Button>
              <Button 
                onClick={handleViewProfile}
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <User className="w-4 h-4 mr-2" />
                View Profile
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800 border-gray-700">
            <TabsTrigger value="overview" className="text-gray-300 data-[state=active]:bg-blue-600 data-[state=active]:text-white">Overview</TabsTrigger>
            <TabsTrigger value="tasks" className="text-gray-300 data-[state=active]:bg-blue-600 data-[state=active]:text-white">Available Tasks</TabsTrigger>
            <TabsTrigger value="my-tasks" className="text-gray-300 data-[state=active]:bg-blue-600 data-[state=active]:text-white">My Tasks</TabsTrigger>
            <TabsTrigger value="earnings" className="text-gray-300 data-[state=active]:bg-blue-600 data-[state=active]:text-white">Earnings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-800 border-gray-700 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-400">Total Earnings</p>
                      <p className="text-2xl font-bold text-white">{formatCurrency(stats.totalEarnings)}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Tasks Completed</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.tasksCompleted}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Campaigns</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.activeCampaigns}</p>
                    </div>
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                      <Activity className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Success Rate</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.successRate}%</p>
                    </div>
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5" />
                    Student Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button 
                    onClick={handleWithdrawFunds}
                    className="w-full justify-start"
                    variant="outline"
                    disabled={withdrawFundsMutation.isPending || stats.totalEarnings === 0}
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Withdraw Funds ({formatCurrency(stats.totalEarnings)})
                  </Button>
                  <Button 
                    onClick={() => setActiveTab("tasks")}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <Activity className="w-4 h-4 mr-2" />
                    Browse Available Tasks
                  </Button>
                  <Button 
                    onClick={handleViewProfile}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <User className="w-4 h-4 mr-2" />
                    View Profile
                  </Button>
                  <Button 
                    onClick={handleHelp}
                    className="w-full justify-start"
                    variant="outline"
                  >
                    <HelpCircle className="w-4 h-4 mr-2" />
                    Get Help & Support
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Campus task completed</p>
                        <p className="text-xs text-gray-500">2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Applied to new campaign</p>
                        <p className="text-xs text-gray-500">Yesterday</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Student verification completed</p>
                        <p className="text-xs text-gray-500">2 days ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tasks" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Available Tasks</h2>
              <p className="text-gray-600">{availableTasks.length} tasks available</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {availableTasks.map((task: any) => (
                <Card key={task.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getPlatformColor(task.platform)}`}>
                        {getPlatformIcon(task.platform)}
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{task.description}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span>Reward:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(task.reward || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Campaign:</span>
                        <span>{task.campaignName || 'Individual Task'}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Deadline:</span>
                        <span>{task.deadline ? new Date(task.deadline).toLocaleDateString() : 'No deadline'}</span>
                      </div>
                    </div>

                    <Button 
                      onClick={() => handleApplyToTask(task.id)}
                      className="w-full"
                      disabled={applyToTaskMutation.isPending}
                    >
                      Apply Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {availableTasks.length === 0 && (
              <div className="text-center py-12">
                <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No tasks available</h3>
                <p className="text-gray-600">Check back later for new student opportunities</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-tasks" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">My Tasks</h2>
              <p className="text-gray-600">{myTasks.length} tasks in progress</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {myTasks.map((task: any) => (
                <Card key={task.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{task.title}</CardTitle>
                      <Badge className={getStatusColor(task.status)}>
                        {task.status?.replace('-', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between text-sm">
                        <span>Reward:</span>
                        <span className="font-semibold text-green-600">{formatCurrency(task.reward || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Status:</span>
                        <span className="capitalize">{task.status?.replace('-', ' ')}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Submitted:</span>
                        <span>{new Date(task.createdAt).toLocaleDateString()}</span>
                      </div>
                      
                      {task.progress && (
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progress:</span>
                            <span>{task.progress}%</span>
                          </div>
                          <Progress value={task.progress} className="h-2" />
                        </div>
                      )}

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          View Details
                        </Button>
                        {task.status === 'in-progress' && (
                          <Button size="sm">
                            Continue
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {myTasks.length === 0 && (
              <div className="text-center py-12">
                <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No tasks yet</h3>
                <p className="text-gray-600 mb-4">Start by applying to available tasks</p>
                <Button onClick={() => setActiveTab("tasks")}>
                  Browse Tasks
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="earnings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Student Earnings Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <h3 className="font-medium text-green-800">Available Balance</h3>
                      <p className="text-2xl font-bold text-green-600">{formatCurrency(stats.totalEarnings)}</p>
                    </div>
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-medium text-blue-800">This Month</h3>
                      <p className="text-2xl font-bold text-blue-600">{formatCurrency(stats.totalEarnings * 0.3)}</p>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <h3 className="font-medium text-purple-800">All Time</h3>
                      <p className="text-2xl font-bold text-purple-600">{formatCurrency(stats.totalEarnings * 2)}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">Payment Actions</h3>
                    <Button 
                      onClick={handleWithdrawFunds}
                      disabled={withdrawFundsMutation.isPending || stats.totalEarnings === 0}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Withdraw Funds
                    </Button>
                  </div>

                  <div className="text-center py-8">
                    <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Detailed transaction history will appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}