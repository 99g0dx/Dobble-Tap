import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function CTASection() {
  return (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="font-poppins font-bold text-3xl md:text-4xl text-white mb-4">
          Ready to Transform Your Influence?
        </h2>
        <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
          Join thousands of creators and brands who are already building authentic connections and driving real results on Dobble Tap.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/auth/register?role=creator">
            <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-4 text-lg font-semibold">
              Start as Creator
            </Button>
          </Link>
          <Link href="/auth/register?role=brand">
            <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 border-2 border-blue-600 hover:border-blue-700 px-8 py-4 text-lg font-semibold shadow-lg">
              Launch Campaign
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
