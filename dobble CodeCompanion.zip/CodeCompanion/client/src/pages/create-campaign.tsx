import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function CreateCampaign() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    budget: "",
    currency: "NGN",
    type: "regular",
    startDate: "",
    endDate: "",
    requirements: "",
    targetCountries: "Nigeria",
    minFollowers: "1000",
    maxCreators: "50",
    preferredPlatforms: "instagram,twitter,tiktok",
    autoApprove: false
  });
  const [error, setError] = useState("");

  const createCampaignMutation = useMutation({
    mutationFn: async (campaignData: any) => {
      return apiRequest("/api/campaigns", "POST", campaignData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      setLocation("/brand-dashboard");
    },
    onError: (error: any) => {
      setError(error.message || "Failed to create campaign");
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!formData.name || !formData.description || !formData.budget) {
      setError("Please fill in all required fields");
      return;
    }

    const budget = parseFloat(formData.budget);
    if (isNaN(budget) || budget <= 0) {
      setError("Please enter a valid budget amount");
      return;
    }

    const campaignData = {
      ...formData,
      budget: budget.toString(),
      targetCountries: formData.targetCountries.split(",").map(c => c.trim()),
      preferredPlatforms: formData.preferredPlatforms.split(",").map(p => p.trim()),
      minFollowers: parseInt(formData.minFollowers) || 0,
      maxCreators: parseInt(formData.maxCreators) || 50,
      startDate: formData.startDate ? new Date(formData.startDate) : null,
      endDate: formData.endDate ? new Date(formData.endDate) : null
    };

    createCampaignMutation.mutate(campaignData);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/brand-dashboard")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-black">Create New Campaign</h1>
          <p className="text-gray-600 mt-2">Launch your brand campaign and connect with creators</p>
        </div>

        <Card className="border-2 border-gray-200 shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-black">Campaign Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <AlertDescription className="text-red-600">
                    {error}
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-700">
                    Campaign Name *
                  </Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Enter campaign name"
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type" className="text-sm font-medium text-gray-700">
                    Campaign Type
                  </Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                    <SelectTrigger className="border-2 border-gray-300 focus:border-blue-600 h-12">
                      <SelectValue placeholder="Select campaign type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="regular">Regular Campaign</SelectItem>
                      <SelectItem value="smm">SMM Panel Activities</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium text-gray-700">
                  Description *
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Describe your campaign goals and requirements"
                  className="border-2 border-gray-300 focus:border-blue-600 min-h-[100px]"
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="budget" className="text-sm font-medium text-gray-700">
                    Budget *
                  </Label>
                  <Input
                    id="budget"
                    type="number"
                    value={formData.budget}
                    onChange={(e) => setFormData({...formData, budget: e.target.value})}
                    placeholder="Enter budget amount"
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                    min="0"
                    step="0.01"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency" className="text-sm font-medium text-gray-700">
                    Currency
                  </Label>
                  <Select value={formData.currency} onValueChange={(value) => setFormData({...formData, currency: value})}>
                    <SelectTrigger className="border-2 border-gray-300 focus:border-blue-600 h-12">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NGN">NGN (₦)</SelectItem>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="EUR">EUR (€)</SelectItem>
                      <SelectItem value="GBP">GBP (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="startDate" className="text-sm font-medium text-gray-700">
                    Start Date
                  </Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endDate" className="text-sm font-medium text-gray-700">
                    End Date
                  </Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="requirements" className="text-sm font-medium text-gray-700">
                  Requirements
                </Label>
                <Textarea
                  id="requirements"
                  value={formData.requirements}
                  onChange={(e) => setFormData({...formData, requirements: e.target.value})}
                  placeholder="Specific requirements for creators (optional)"
                  className="border-2 border-gray-300 focus:border-blue-600 min-h-[80px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="minFollowers" className="text-sm font-medium text-gray-700">
                    Minimum Followers
                  </Label>
                  <Input
                    id="minFollowers"
                    type="number"
                    value={formData.minFollowers}
                    onChange={(e) => setFormData({...formData, minFollowers: e.target.value})}
                    placeholder="Minimum follower count"
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                    min="0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxCreators" className="text-sm font-medium text-gray-700">
                    Maximum Creators
                  </Label>
                  <Input
                    id="maxCreators"
                    type="number"
                    value={formData.maxCreators}
                    onChange={(e) => setFormData({...formData, maxCreators: e.target.value})}
                    placeholder="Maximum number of creators"
                    className="border-2 border-gray-300 focus:border-blue-600 h-12"
                    min="1"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/brand-dashboard")}
                  className="px-8 py-3"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
                  disabled={createCampaignMutation.isPending}
                >
                  {createCampaignMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Campaign"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}