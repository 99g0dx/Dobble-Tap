import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function RoleSelection() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [role, setRole] = useState<string>("");

  const roleSelectionMutation = useMutation({
    mutationFn: async (selectedRole: string) => {
      return apiRequest("/api/auth/update-role", {
        method: "POST",
        body: { role: selectedRole }
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Role Selected",
        description: "Your role has been updated successfully!"
      });
      
      // Redirect to appropriate dashboard based on role
      const dashboardPath = data.role === "brand" ? "/brand-dashboard" : 
                          data.role === "student" ? "/student-dashboard" : 
                          "/creator-dashboard";
      setLocation(dashboardPath);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update role",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!role) {
      toast({
        title: "Error",
        description: "Please select a role to continue",
        variant: "destructive"
      });
      return;
    }
    roleSelectionMutation.mutate(role);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">Complete Your Profile</CardTitle>
          <CardDescription className="text-center">
            Choose your role to get started with Dobble Tap
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="role" className="text-sm font-medium text-gray-700">
                I want to join as
              </Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger className="border-2 border-gray-300 focus:border-blue-600 h-12">
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="creator">Content Creator</SelectItem>
                  <SelectItem value="brand">Brand/Company</SelectItem>
                  <SelectItem value="student">Student Ambassador</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white h-12 text-lg font-semibold shadow-lg"
              disabled={roleSelectionMutation.isPending}
            >
              {roleSelectionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Saving...
                </>
              ) : (
                "Continue"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}