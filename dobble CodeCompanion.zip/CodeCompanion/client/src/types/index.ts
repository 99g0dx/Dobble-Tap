export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  role: 'creator' | 'brand' | 'student' | 'admin';
  avatarUrl?: string;
  bio?: string;
  location?: string;
  verificationStatus: 'pending' | 'verified' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export interface Campaign {
  id: string;
  userId: string;
  name: string;
  description: string;
  budget: string;
  status: 'draft' | 'active' | 'paused' | 'completed' | 'cancelled';
  startDate?: string;
  endDate?: string;
  targetAudience?: any;
  requirements?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Task {
  id: string;
  campaignId: string;
  title: string;
  type: string;
  platform: string;
  rewardAmount: string;
  instructions: string;
  targetUrl?: string;
  maxCompletions: number;
  currentCompletions: number;
  status: 'active' | 'paused' | 'completed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
}

export interface TaskSubmission {
  id: string;
  taskId: string;
  userId: string;
  proofUrl: string;
  screenshotUrl?: string;
  notes?: string;
  status: 'pending' | 'approved' | 'rejected';
  adminNotes?: string;
  submittedAt: string;
  verifiedAt?: string;
}

export interface Payment {
  id: string;
  userId: string;
  campaignId?: string;
  taskId?: string;
  reference?: string;
  amount: string;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  paymentMethod: string;
  gatewayResponse?: any;
  metadata?: any;
  createdAt: string;
  verifiedAt?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  data?: any;
  createdAt: string;
}

export interface UserStats {
  totalEarnings: number;
  tasksCompleted: number;
  activeCampaigns: number;
  successRate: number;
}

export interface CampaignStats {
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
}
