import crypto from 'crypto';
import { Resend } from 'resend';

export interface EmailVerificationData {
  email: string;
  code: string;
  expiresAt: Date;
  attempts: number;
}

// Simple in-memory store for verification codes
const verificationCodes = new Map<string, EmailVerificationData>();

export class EmailService {
  private resend: Resend;
  private maxAttempts = 5;
  private codeExpiry = 10 * 60 * 1000; // 10 minutes
  private fromEmail = 'noreply@dobletap.com';

  constructor() {
    this.resend = new Resend(process.env.RESEND_API_KEY);
  }

  generateVerificationCode(): string {
    return crypto.randomInt(100000, 999999).toString();
  }

  async sendVerificationEmail(email: string, code: string): Promise<void> {
    try {
      await this.resend.emails.send({
        from: this.fromEmail,
        to: email,
        subject: 'Verify your Dobble Tap account',
        html: this.getVerificationEmailTemplate(code)
      });
      
      // Store the verification code
      verificationCodes.set(email, {
        email,
        code,
        expiresAt: new Date(Date.now() + this.codeExpiry),
        attempts: 0
      });
    } catch (error) {
      console.error('Failed to send verification email:', error);
      // Fallback: log code for development
      console.log(`Email Verification Code for ${email}: ${code}`);
    }
  }

  async verifyCode(email: string, code: string): Promise<boolean> {
    const verificationData = verificationCodes.get(email);
    
    if (!verificationData) {
      return false;
    }

    // Check if code has expired
    if (new Date() > verificationData.expiresAt) {
      verificationCodes.delete(email);
      return false;
    }

    // Check if too many attempts
    if (verificationData.attempts >= this.maxAttempts) {
      verificationCodes.delete(email);
      return false;
    }

    // Increment attempts
    verificationData.attempts++;

    // Check if code matches
    if (verificationData.code === code) {
      verificationCodes.delete(email);
      return true;
    }

    return false;
  }

  async resendVerificationCode(email: string): Promise<string> {
    const newCode = this.generateVerificationCode();
    await this.sendVerificationEmail(email, newCode);
    return newCode;
  }

  // Email templates for different scenarios
  generateWelcomeMessage(name: string, role: string): string {
    return `
      Welcome to Dobble Tap, ${name}!
      
      Your ${role} account has been successfully created and verified.
      
      You can now:
      ${role === 'creator' ? `
      - Apply to brand campaigns
      - Complete tasks and earn money
      - Build your creator profile
      - Connect your social media accounts
      ` : role === 'brand' ? `
      - Create marketing campaigns
      - Find and hire creators
      - Track campaign performance
      - Manage your brand profile
      ` : `
      - Apply to study-related campaigns
      - Complete educational tasks
      - Earn money while studying
      - Build your academic profile
      `}
      
      Get started at: https://dobletap.com
      
      Need help? Contact support at support@dobletap.com
      
      Best regards,
      The Dobble Tap Team
    `;
  }

  async sendWelcomeEmail(email: string, name: string, role: string): Promise<void> {
    try {
      await this.resend.emails.send({
        from: this.fromEmail,
        to: email,
        subject: 'Welcome to Dobble Tap!',
        html: this.getWelcomeEmailTemplate(name, role)
      });
    } catch (error) {
      console.error('Failed to send welcome email:', error);
      // Fallback: log for development
      console.log(`Welcome Email for ${email}:`, this.generateWelcomeMessage(name, role));
    }
  }

  async sendPasswordResetEmail(email: string, resetToken: string): Promise<void> {
    try {
      await this.resend.emails.send({
        from: this.fromEmail,
        to: email,
        subject: 'Reset your Dobble Tap password',
        html: this.getPasswordResetEmailTemplate(resetToken)
      });
    } catch (error) {
      console.error('Failed to send password reset email:', error);
      console.log(`Password Reset Token for ${email}: ${resetToken}`);
    }
  }

  async sendSupportTicketEmail(ticketData: any): Promise<void> {
    try {
      await this.resend.emails.send({
        from: this.fromEmail,
        to: 'support@dobletap.com',
        subject: `New Support Ticket: ${ticketData.subject}`,
        html: this.getSupportTicketEmailTemplate(ticketData)
      });
    } catch (error) {
      console.error('Failed to send support ticket email:', error);
      console.log(`Support Ticket:`, ticketData);
    }
  }

  async sendPaymentConfirmationEmail(email: string, paymentData: any): Promise<void> {
    try {
      await this.resend.emails.send({
        from: this.fromEmail,
        to: email,
        subject: 'Payment Confirmation - Dobble Tap',
        html: this.getPaymentConfirmationEmailTemplate(paymentData)
      });
    } catch (error) {
      console.error('Failed to send payment confirmation email:', error);
      console.log(`Payment Confirmation for ${email}:`, paymentData);
    }
  }

  // Email Templates
  private getVerificationEmailTemplate(code: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Verify your Dobble Tap account</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #1f2937; color: white; padding: 20px; text-align: center; }
          .content { background: #f9fafb; padding: 30px; }
          .code { background: #2563eb; color: white; font-size: 24px; padding: 15px; text-align: center; margin: 20px 0; }
          .footer { background: #374151; color: white; padding: 20px; text-align: center; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Dobble Tap</h1>
          <p>Verify your account</p>
        </div>
        <div class="content">
          <p>Thanks for signing up! Please verify your email address by entering this code:</p>
          <div class="code">${code}</div>
          <p>This code will expire in 10 minutes.</p>
          <p>If you didn't create an account, please ignore this email.</p>
        </div>
        <div class="footer">
          <p>© 2025 Dobble Tap. All rights reserved.</p>
          <p>Need help? Contact support@dobletap.com</p>
        </div>
      </body>
      </html>
    `;
  }

  private getWelcomeEmailTemplate(name: string, role: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome to Dobble Tap!</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #1f2937; color: white; padding: 20px; text-align: center; }
          .content { background: #f9fafb; padding: 30px; }
          .cta { background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
          .footer { background: #374151; color: white; padding: 20px; text-align: center; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Welcome to Dobble Tap!</h1>
        </div>
        <div class="content">
          <h2>Hi ${name}!</h2>
          <p>Welcome to Dobble Tap, Africa's leading creator monetization platform!</p>
          <p>Your ${role} account has been successfully created. You can now:</p>
          ${role === 'creator' ? `
            <ul>
              <li>Apply to brand campaigns</li>
              <li>Complete tasks and earn money instantly</li>
              <li>Build your creator profile</li>
              <li>Connect your social media accounts</li>
            </ul>
          ` : role === 'brand' ? `
            <ul>
              <li>Create marketing campaigns</li>
              <li>Find and hire talented creators</li>
              <li>Track campaign performance</li>
              <li>Manage your brand profile</li>
            </ul>
          ` : `
            <ul>
              <li>Apply to student-friendly campaigns</li>
              <li>Complete educational tasks</li>
              <li>Earn money while studying</li>
              <li>Build your academic profile</li>
            </ul>
          `}
          <a href="https://dobletap.com" class="cta">Get Started Now</a>
        </div>
        <div class="footer">
          <p>© 2025 Dobble Tap. All rights reserved.</p>
          <p>Need help? Contact support@dobletap.com</p>
        </div>
      </body>
      </html>
    `;
  }

  private getPasswordResetEmailTemplate(resetToken: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Reset your Dobble Tap password</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #1f2937; color: white; padding: 20px; text-align: center; }
          .content { background: #f9fafb; padding: 30px; }
          .cta { background: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
          .footer { background: #374151; color: white; padding: 20px; text-align: center; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Reset Your Password</h1>
        </div>
        <div class="content">
          <p>You requested to reset your password for your Dobble Tap account.</p>
          <p>Click the button below to reset your password:</p>
          <a href="https://dobletap.com/reset-password?token=${resetToken}" class="cta">Reset Password</a>
          <p>This link will expire in 1 hour.</p>
          <p>If you didn't request this reset, please ignore this email.</p>
        </div>
        <div class="footer">
          <p>© 2025 Dobble Tap. All rights reserved.</p>
          <p>Need help? Contact support@dobletap.com</p>
        </div>
      </body>
      </html>
    `;
  }

  private getSupportTicketEmailTemplate(ticketData: any): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>New Support Ticket</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #1f2937; color: white; padding: 20px; }
          .content { background: #f9fafb; padding: 30px; }
          .ticket-info { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #2563eb; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>New Support Ticket</h1>
        </div>
        <div class="content">
          <div class="ticket-info">
            <h3>Subject: ${ticketData.subject}</h3>
            <p><strong>Category:</strong> ${ticketData.category}</p>
            <p><strong>Priority:</strong> ${ticketData.priority}</p>
            <p><strong>User:</strong> ${ticketData.userEmail}</p>
            <p><strong>Description:</strong></p>
            <p>${ticketData.description}</p>
          </div>
        </div>
      </body>
      </html>
    `;
  }

  private getPaymentConfirmationEmailTemplate(paymentData: any): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Payment Confirmation</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #1f2937; color: white; padding: 20px; text-align: center; }
          .content { background: #f9fafb; padding: 30px; }
          .payment-info { background: white; padding: 20px; margin: 20px 0; border-left: 4px solid #10b981; }
          .footer { background: #374151; color: white; padding: 20px; text-align: center; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Payment Confirmed!</h1>
        </div>
        <div class="content">
          <div class="payment-info">
            <h3>Payment Successfully Processed</h3>
            <p><strong>Amount:</strong> ${paymentData.amount}</p>
            <p><strong>Reference:</strong> ${paymentData.reference}</p>
            <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
            <p><strong>Status:</strong> Completed</p>
          </div>
          <p>Your payment has been successfully processed. You can view your transaction history in your dashboard.</p>
        </div>
        <div class="footer">
          <p>© 2025 Dobble Tap. All rights reserved.</p>
          <p>Need help? Contact support@dobletap.com</p>
        </div>
      </body>
      </html>
    `;
  }
}

export const emailService = new EmailService();