import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/currencies";
import { apiRequest } from "@/lib/queryClient";
import { 
  Wallet, 
  Plus, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle, 
  XCircle,
  CreditCard
} from "lucide-react";

interface WalletBalance {
  balance: string;
  currency: string;
}

interface WalletTransaction {
  id: string;
  type: string;
  amount: string;
  description: string;
  status: string;
  createdAt: string;
  reference?: string;
}

export default function WalletCard() {
  const [fundAmount, setFundAmount] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: balance, isLoading: balanceLoading } = useQuery<WalletBalance>({
    queryKey: ["/api/wallet/balance"],
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<WalletTransaction[]>({
    queryKey: ["/api/wallet/transactions"],
  });

  const fundWalletMutation = useMutation({
    mutationFn: async (amount: string) => {
      const response = await apiRequest(`/api/wallet/fund`, {
        method: "POST",
        body: { amount },
      });
      return response;
    },
    onSuccess: (data) => {
      // Redirect to Paystack payment page
      window.location.href = data.authorization_url;
    },
    onError: (error: any) => {
      toast({
        title: "Funding Failed",
        description: error.message || "Failed to initialize payment",
        variant: "destructive",
      });
    },
  });

  const handleFundWallet = async () => {
    if (!fundAmount || parseFloat(fundAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(fundAmount) < 100) {
      toast({
        title: "Minimum Amount",
        description: "Minimum funding amount is ₦100",
        variant: "destructive",
      });
      return;
    }

    fundWalletMutation.mutate(fundAmount);
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownLeft className="h-4 w-4 text-green-500" />;
      case "payment":
        return <ArrowUpRight className="h-4 w-4 text-blue-500" />;
      case "withdrawal":
        return <ArrowUpRight className="h-4 w-4 text-blue-500" />;
      case "refund":
        return <ArrowDownLeft className="h-4 w-4 text-yellow-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatTransactionAmount = (amount: string, type: string) => {
    const numAmount = parseFloat(amount);
    const absAmount = Math.abs(numAmount);
    const sign = type === "deposit" || type === "refund" ? "+" : "-";
    return `${sign}${formatCurrency(absAmount, "NGN")}`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Wallet Balance Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Wallet Balance
          </CardTitle>
          <CardDescription>
            Fund your wallet to create campaigns and pay creators
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600">
              {balanceLoading ? "Loading..." : formatCurrency(parseFloat(balance?.balance || "0"), balance?.currency || "NGN")}
            </div>
            <p className="text-sm text-muted-foreground mt-1">Available Balance</p>
          </div>

          <Separator />

          <div className="space-y-4">
            <div>
              <Label htmlFor="fundAmount">Fund Amount (₦)</Label>
              <Input
                id="fundAmount"
                type="number"
                placeholder="Enter amount (minimum ₦100)"
                value={fundAmount}
                onChange={(e) => setFundAmount(e.target.value)}
                min="100"
                step="0.01"
              />
            </div>

            <Button
              onClick={handleFundWallet}
              disabled={fundWalletMutation.isPending || !fundAmount}
              className="w-full"
            >
              {fundWalletMutation.isPending ? (
                <>
                  <Clock className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Fund Wallet
                </>
              )}
            </Button>

            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <CreditCard className="h-4 w-4" />
              Secured by Paystack
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transaction History Card */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
          <CardDescription>
            Your wallet transaction history
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-80">
            {transactionsLoading ? (
              <div className="text-center py-8">Loading transactions...</div>
            ) : !transactions || transactions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No transactions yet. Fund your wallet to get started!
              </div>
            ) : (
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-3 border rounded-lg bg-card hover:bg-muted/50"
                  >
                    <div className="flex items-center gap-3">
                      {getTransactionIcon(transaction.type)}
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(transaction.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <span className={`font-medium ${
                          transaction.type === "deposit" || transaction.type === "refund"
                            ? "text-green-600"
                            : "text-blue-600"
                        }`}>
                          {formatTransactionAmount(transaction.amount, transaction.type)}
                        </span>
                        {getStatusIcon(transaction.status)}
                      </div>
                      <Badge variant={
                        transaction.status === "completed" ? "default" :
                        transaction.status === "pending" ? "secondary" :
                        "destructive"
                      }>
                        {transaction.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}