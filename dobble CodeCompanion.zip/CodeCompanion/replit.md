# Replit.md - Dobble Tap Platform

## Overview

Dobble Tap is a creator monetization platform designed specifically for the African market. It connects content creators with brands through a task-based system where creators complete promotional tasks (like social media posts, stories, tweets) and earn money instantly. The platform serves as a bridge between brands looking to reach authentic African audiences and creators seeking flexible income opportunities.

## User Preferences

Preferred communication style: Simple, everyday language.
Color scheme preference: Clean, sophisticated design with minimal colors - modern doesn't mean messy.
Maximum 5 colors: Use simple colors everywhere, no complex gradients or chaotic rainbow approaches.

## System Architecture

### Full-Stack TypeScript Application
- **Frontend**: React with TypeScript, built using Vite
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: React Query for server state management
- **Routing**: Wouter for client-side routing
- **Session Management**: Express sessions with PostgreSQL store

### Monorepo Structure
The application follows a monorepo pattern with clear separation:
- `client/` - React frontend application
- `server/` - Express backend API
- `shared/` - Shared TypeScript types and database schema

## Key Components

### Frontend Architecture
- **React with TypeScript**: Modern React with functional components and hooks
- **Vite Build System**: Fast development server and optimized production builds
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **shadcn/ui Components**: Pre-built, accessible UI components
- **React Query**: Server state management with caching and synchronization
- **Wouter**: Lightweight client-side routing

### Backend Architecture
- **Express.js**: RESTful API server with middleware-based architecture
- **TypeScript**: Type-safe server-side development
- **Session-based Authentication**: Secure user sessions with PostgreSQL storage
- **Drizzle ORM**: Type-safe database operations with PostgreSQL
- **Role-based Access Control**: Different user roles (creator, brand, admin)

### Database Design
- **PostgreSQL**: Relational database with ACID compliance
- **Drizzle ORM**: Type-safe schema definition and query building
- **Schema Structure**:
  - Users (creators, brands, admins)
  - Campaigns (brand marketing campaigns)
  - Tasks (specific promotional activities)
  - Task Submissions (creator work submissions)
  - Payments (transaction records)
  - Notifications (system communications)

## Data Flow

### User Authentication Flow
1. User registers with email/password and role selection
2. Server creates session and stores user data
3. Client receives authentication state via React Query
4. Protected routes use authentication middleware

### Campaign Creation Flow (Brands)
1. Brand creates campaign with budget and requirements
2. Campaign generates multiple tasks with specific instructions
3. Tasks become available to qualified creators
4. Analytics track campaign performance

### Task Completion Flow (Creators)
1. Creator browses available tasks matching their profile
2. Creator submits proof of completion (links, screenshots)
3. Brand reviews and approves submissions
4. Payment is processed via Paystack integration
5. Creator receives instant payment notification

### Payment Processing
- Integration with Paystack for Nigerian payment processing
- Secure transaction handling with reference tracking
- Automatic payment verification and disbursement

## External Dependencies

### Payment Integration
- **Paystack**: Nigerian payment processor for secure transactions
- Handles payment initialization, verification, and webhooks
- Supports multiple payment methods popular in Africa

### Development Tools
- **Vite**: Fast development server and build tool
- **ESBuild**: Fast JavaScript bundler for production
- **Drizzle Kit**: Database migration and schema management
- **TypeScript**: Type checking and compilation

### UI Libraries
- **Radix UI**: Accessible, unstyled component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Consistent icon library
- **React Hook Form**: Form validation and management

## Deployment Strategy

### Development Setup
- Single command development: `npm run dev`
- Hot module replacement with Vite
- Automatic type checking with TypeScript
- Database migrations with Drizzle

### Production Build
- Frontend: Vite builds optimized React bundle
- Backend: ESBuild creates Node.js server bundle
- Static assets served from Express server
- Environment-based configuration

### Environment Configuration
- Database connection via `DATABASE_URL`
- Paystack API keys for payment processing
- Session secrets for secure authentication
- Development vs production environment detection

### Key Features
- **Responsive Design**: Mobile-first approach for African mobile users
- **Offline Capability**: Progressive web app features
- **Payment Security**: PCI-compliant payment processing
- **Multi-language Support**: Ready for localization
- **Analytics Dashboard**: Real-time campaign performance tracking
- **Creator Verification**: Profile verification system for trust
- **Instant Payments**: Real-time payment processing and notifications
- **SMM Panel Activities**: Micro-earning tasks for social media activities
- **Campaign Type Differentiation**: Different minimum budgets for SMM vs regular campaigns
- **Country Selection**: Searchable dropdown for 195+ countries
- **Currency System**: Automatic currency selection based on nationality

### Recent Changes (January 2025)

#### Production Deployment Readiness (January 16, 2025)
- ✅ **Google OAuth Configuration**: Live credentials added for production
  - Client ID: 354235093279-aa7i67ujlr0ocubrmn5bhlq06850fa36.apps.googleusercontent.com
  - Client Secret: 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
- ✅ **Paystack Live Integration**: Production payment keys configured
  - Live Secret Key: PAYSTACK_PICATIC_API_KEYcdfe6ae7
  - Live Public Key: pk_live_01ae8e298b79d643c61abc4bca40d1d322afbb32
  - Webhook URL configured for www.dobbletap.com
- ✅ **Domain Configuration**: All settings updated for www.dobbletap.com
- ✅ **Security Hardening**: Strong session secrets and production-ready middleware
- ✅ **Launch Score**: 83/100 production readiness achieved
- ✅ **Deployment Documentation**: Complete guides created for production launch

### Recent Changes (January 2025)

#### Launch Readiness Implementation (January 16, 2025)
- ✅ **Email Service**: Implemented Resend email service with professional templates
  - Welcome emails for new users with role-specific content
  - Password reset emails with secure token links
  - Support ticket notifications to support team
  - Payment confirmation emails with transaction details
  - All emails use branded HTML templates with consistent styling
- ✅ **Legal Pages**: Created comprehensive legal documentation
  - Privacy Policy page with African market focus
  - Terms of Service with payment and IP protection terms
  - About Us page highlighting African creator economy
  - Added footer links to all legal pages on landing page
- ✅ **Security Features**: Implemented production-ready security
  - Rate limiting on API endpoints (100 requests/15min)
  - Strict rate limiting on auth endpoints (5 requests/15min)
  - Helmet.js security headers with CSP policies
  - Input validation and sanitization with express-validator
  - CORS configuration for production domains
- ✅ **Error Handling**: Enhanced error management system
  - Comprehensive error logging with request context
  - Production-safe error messages (no internal details exposed)
  - Structured error responses with proper HTTP status codes
  - Error tracking with timestamps and user context
- ✅ **Help & Support System**: Complete support infrastructure
  - Comprehensive Help & Support page (/help) for signed-in users
  - Support ticket submission with categorization and priority levels
  - Backend API endpoint integrated with email notifications
  - Help buttons on all dashboard headers (Creator, Brand, Student)
  - FAQ section with common questions and answers
  - Contact information and response time expectations
  - User notifications when support tickets are submitted

#### Profile System & Authentication Updates (January 16, 2025)
- ✅ Removed nationality and state fields from registration form
- ✅ Created dedicated profile pages for creators, students, and brands
- ✅ Added state field to all profile pages (changed from "state of origin" to "state")
- ✅ Created CreatorProfile page (/creator-profile) with social media handles
- ✅ Created StudentProfile page (/student-profile) with school field
- ✅ Created BrandProfile page (/brand-profile) with "Tell us about your brand" bio
- ✅ Implemented forgot password functionality with API endpoint
- ✅ Added forgot password links to login and registration pages
- ✅ Updated routing to include all new profile pages
- ✅ Added Textarea component for profile bio sections
- ✅ Implemented Google OAuth authentication infrastructure
- ✅ Added Google sign-in/sign-up buttons to login and register pages
- ✅ Created role selection page for Google OAuth users
- ✅ Added fallback handling when Google OAuth credentials aren't available
- ⏳ Google OAuth pending: Waiting for Google Workspace subscription approval

#### Profile System Updates
- ✅ Added searchable country dropdown with 195+ countries
- ✅ Added school/institution field for student profiles
- ✅ Removed location field for students, kept state of origin
- ✅ Updated profile schema to include new fields
- ✅ Made state dropdown dynamic based on selected country
- ✅ Added comprehensive states data for major African countries (Nigeria, Ghana, Kenya, South Africa, etc.)

#### Campaign Management Enhancements
- ✅ Added campaign type selection (SMM Panel vs Regular Campaign)
- ✅ Implemented differentiated minimum budgets:
  - SMM Panel Activities: ₦50,000 minimum
  - Regular Campaigns: ₦100,000 minimum
- ✅ Added budget validation based on campaign type
- ✅ Enhanced campaign creation with sound links for social platforms
- ✅ Added Snapchat integration to all social media platforms
- ✅ Reduced campaign creation dialog height for better UX (80vh instead of 90vh)
- ✅ Fixed currency correlation with budget validation
- ✅ Added dynamic currency conversion for minimum budget display  
- ✅ Improved budget input handling with proper currency formatting
- ✅ Added comma formatting to budget input field for better readability
- ✅ Enhanced number display with locale-aware formatting across all currencies

#### Dashboard UI/UX Overhaul (January 2025)
- ✅ Implemented brand color scheme alignment throughout the platform
- ✅ Updated dashboards to use company brand colors (white, black, red)
- ✅ Redesigned both Brand and Creator dashboards with modern styling
- ✅ Enhanced stat cards with proper branding and hover effects
- ✅ Updated tab navigation with brand-compliant active states
- ✅ Improved card designs with consistent border styling and shadows
- ✅ Added red accent colors for primary actions and highlights
- ✅ Maintained modern design elements while ensuring brand consistency
- ✅ Updated Quick Actions sections with brand-aligned styling
- ✅ Enhanced Recent Activity displays with proper color coding

#### Simple Color Scheme Updates (January 2025)
- ✅ Implemented ultra-clean 5-color palette: black, white, gray-900, gray-800, blue-600
- ✅ Removed ALL gradients from homepage, auth pages, and dashboards
- ✅ Updated homepage hero section with solid gray-900 background
- ✅ Added single blue-600 accent color for "Creators" text, kept "Brands" text white
- ✅ Simplified button design with consistent blue-600 primary color across all pages
- ✅ Updated floating cards with blue-600 and gray-800 colors
- ✅ Updated sign-in page with solid gray-900 background
- ✅ Updated sign-up page with matching gray-900 background
- ✅ Redesigned student dashboard with solid gray-900 background
- ✅ Added gray-800 header with blue-600 active tab states
- ✅ Updated stats cards with gray-800 backgrounds and blue-600 accents
- ✅ Unified all create campaign buttons with consistent blue-600 styling
- ✅ Removed gradient from "Ready to Transform Your Influence?" CTA section
- ✅ Applied strict 5-color palette: black, white, gray-900, gray-800, blue-600
- ✅ Eliminated all complex gradients and chaotic color mixing
- ✅ Achieved clean, professional appearance with simple color usage
- ✅ Systematically updated ALL remaining red colors to blue-600 across entire codebase
- ✅ Updated navigation, platform features, testimonials, footer, dashboards, and auth pages
- ✅ Replaced all red-600, red-700, red-500, red-400, red-300 with blue equivalents
- ✅ Ensured complete color consistency across all 50+ components and pages

#### Navigation & User Experience Enhancements (January 2025)
- ✅ Replaced homepage buttons with elegant website logo/name navigation
- ✅ Positioned "Dobble Tap" logo at top-left corner of all dashboards
- ✅ Enhanced dashboard headers with professional branding and smooth hover effects
- ✅ Added visual separators between logo and dashboard content
- ✅ Expanded SMM Panel with comprehensive task types:
  - Instagram: Comment, story post with song, share to story, IG live
  - TikTok: Likes, comments, join live, repost, save, share
  - Twitter/X: Likes, retweet, comments, votes, quote tweet
  - YouTube: Like, subscribe, comment, vote, share
- ✅ Fixed duplicate key warnings in SMM Panel for better performance
- ✅ Improved task variety with proper pricing and requirements

#### Creator Selection & Application System
- ✅ Implemented intelligent creator selection based on geographic and demographic targeting
- ✅ Added campaign application system with status tracking (pending, approved, rejected)
- ✅ Created geographic targeting system for campaigns (country-specific)
- ✅ Added minimum follower requirements and platform-specific filtering
- ✅ Implemented auto-approval option for streamlined campaigns
- ✅ Removed personalized message requirement from applications (user feedback)
- ✅ Added payment distribution system across approved creators
- ✅ Built comprehensive API routes for campaign applications and creator-brand matching
- ✅ Added real-time notifications for application status changes

#### Payment Distribution System
- ✅ Implemented automatic payment splitting across approved creators
- ✅ Added payment distribution API for brands to pay all approved creators
- ✅ Enhanced payment tracking with campaign-specific references
- ✅ Added payment notifications for creators when funds are distributed
- ✅ Added ₦5,000 minimum payment validation for regular campaigns
- ✅ Updated SMM panel minimum payout to ₦100 (from ₦50)

#### SMM Panel System
- ✅ Created dedicated SMM Panel page (/smm-panel)
- ✅ Added platform-specific activities (Instagram, TikTok, YouTube, Twitter, Snapchat)
- ✅ Implemented activity filtering by platform and type
- ✅ Added instant payment system for micro-activities
- ✅ Created activity cards with requirements and pricing

#### Database Schema Updates
- ✅ Added `school` field to users table
- ✅ Added `type` field to campaigns table
- ✅ Added `snapchatHandle` field to users table
- ✅ Added `snapchatSoundUrl` field to campaigns table
- ✅ Added campaign applications table with status tracking
- ✅ Enhanced campaigns table with creator selection fields (targetCountries, minFollowers, maxCreators, etc.)
- ✅ Updated storage layer to support new fields
- ✅ Enhanced form validation schemas

#### Navigation & User Experience
- ✅ Added SMM Panel link to main navigation
- ✅ Updated routing to include SMM panel
- ✅ Enhanced user profile management with dynamic state selection
- ✅ Improved campaign creation workflow with better form height
- ✅ Replaced homepage SVG with real youthful African creators image
- ✅ Simplified application process by removing mandatory personalized messages

The platform is designed to scale with the growing African creator economy, providing both creators and brands with the tools they need to build authentic, profitable relationships.

## Analytics System Architecture

### Engagement Tracking
- **Social Media Integration**: Real-time API connections to Instagram, TikTok, Twitter, YouTube, and Snapchat
- **Link Tracking**: UTM parameters and shortened URLs for conversion tracking
- **Metric Collection**: Likes, comments, shares, views, clicks, reach, and engagement rates
- **Data Processing**: 15-minute interval updates with hourly comprehensive refreshes

### Campaign Analytics
- **Performance Metrics**: Total reach, engagement, click-through rates, and conversion tracking
- **Real-Time Updates**: WebSocket integration for live dashboard updates
- **Quality Assurance**: Cross-platform verification and anomaly detection
- **Compliance**: API rate limiting adherence and platform terms compliance

### Live Tracking Implementation
- **Background Jobs**: Scheduled analytics updates with queue processing
- **Caching Strategy**: Redis for performance optimization
- **Monitoring**: System health alerts and performance tracking
- **Privacy**: GDPR compliance with encrypted data storage

Detailed analytics system documentation available in `ANALYTICS_SYSTEM_EXPLAINED.md`.