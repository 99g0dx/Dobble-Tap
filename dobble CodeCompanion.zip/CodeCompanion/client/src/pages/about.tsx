import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Heart, Users, Globe, Target, Zap, Shield } from "lucide-react";
import { useLocation } from "wouter";

export default function About() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/")}
                className="text-white hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div className="border-l border-gray-600 pl-4">
                <h1 className="text-2xl font-bold text-white">About Dobble Tap</h1>
                <p className="text-gray-300 text-sm">Africa's Leading Creator Monetization Platform</p>
              </div>
            </div>
            <Heart className="w-8 h-8 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Mission */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-600" />
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-lg">
                To empower African creators by providing them with opportunities to monetize their influence and creativity while connecting brands with authentic voices that resonate with their target audiences.
              </p>
            </CardContent>
          </Card>

          {/* What We Do */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-600" />
                What We Do
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Dobble Tap is a comprehensive creator monetization platform that bridges the gap between talented African creators and brands seeking authentic engagement. We provide:
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-blue-600 mb-2">For Creators</h3>
                    <ul className="text-sm space-y-1">
                      <li>• Access to diverse brand campaigns</li>
                      <li>• Instant payment processing</li>
                      <li>• Profile building and verification</li>
                      <li>• Educational content and resources</li>
                      <li>• Community support and networking</li>
                    </ul>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-blue-600 mb-2">For Brands</h3>
                    <ul className="text-sm space-y-1">
                      <li>• Access to verified African creators</li>
                      <li>• Campaign management tools</li>
                      <li>• Performance analytics and tracking</li>
                      <li>• Secure payment processing</li>
                      <li>• Dedicated support team</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Why Africa */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-blue-600" />
                Why Africa?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Africa represents the world's fastest-growing digital economy with unprecedented opportunities:
                </p>
                
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">1.4B+</div>
                    <div className="text-sm text-gray-600">Population</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">60%</div>
                    <div className="text-sm text-gray-600">Under 25 years</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">500M+</div>
                    <div className="text-sm text-gray-600">Internet users</div>
                  </div>
                </div>
                
                <p className="text-sm text-gray-600">
                  This demographic shift creates an enormous opportunity for authentic, locally-relevant content creation and brand engagement.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Our Values */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Our Values
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold text-blue-600 mb-2">Authenticity</h3>
                  <p className="text-sm text-gray-600">
                    We believe in genuine connections and authentic content that resonates with real audiences.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-blue-600 mb-2">Empowerment</h3>
                  <p className="text-sm text-gray-600">
                    We empower creators to build sustainable careers and achieve financial independence.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-blue-600 mb-2">Innovation</h3>
                  <p className="text-sm text-gray-600">
                    We continuously evolve our platform to meet the changing needs of the creator economy.
                  </p>
                </div>
                
                <div>
                  <h3 className="font-semibold text-blue-600 mb-2">Community</h3>
                  <p className="text-sm text-gray-600">
                    We foster a supportive community where creators and brands can thrive together.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Platform Features */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-600" />
                Platform Features
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold mb-2">Campaign Management</h3>
                    <ul className="text-sm space-y-1 text-gray-600">
                      <li>• Intuitive campaign creation tools</li>
                      <li>• Automated creator matching</li>
                      <li>• Real-time performance tracking</li>
                      <li>• Comprehensive analytics dashboard</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-2">Payment Processing</h3>
                    <ul className="text-sm space-y-1 text-gray-600">
                      <li>• Secure payment infrastructure</li>
                      <li>• Multiple payment methods</li>
                      <li>• Instant payment processing</li>
                      <li>• Transparent fee structure</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-2">Creator Tools</h3>
                    <ul className="text-sm space-y-1 text-gray-600">
                      <li>• Profile verification system</li>
                      <li>• Performance analytics</li>
                      <li>• Educational resources</li>
                      <li>• Community support</li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-2">Support System</h3>
                    <ul className="text-sm space-y-1 text-gray-600">
                      <li>• 24/7 customer support</li>
                      <li>• Dispute resolution</li>
                      <li>• Knowledge base and FAQs</li>
                      <li>• Community forums</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Success Stories */}
          <Card>
            <CardHeader>
              <CardTitle>Success Stories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm italic mb-2">
                    "Dobble Tap has transformed how I monetize my content. The platform is user-friendly, payments are instant, and the support team is amazing!"
                  </p>
                  <p className="text-sm font-semibold">- Sarah M., Lagos-based Creator</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm italic mb-2">
                    "We've found incredible talent through Dobble Tap. The quality of creators and the campaign management tools make it easy to run successful campaigns."
                  </p>
                  <p className="text-sm font-semibold">- David K., Brand Manager</p>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm italic mb-2">
                    "As a student, Dobble Tap has helped me earn money while studying. The platform respects my schedule and offers flexible opportunities."
                  </p>
                  <p className="text-sm font-semibold">- Amina J., University of Lagos</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle>Get in Touch</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Ready to join the Dobble Tap community? We'd love to hear from you!
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold mb-2">For Creators</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      Join thousands of creators earning money through authentic content creation.
                    </p>
                    <Button 
                      onClick={() => setLocation("/register")}
                      className="w-full"
                    >
                      Join as Creator
                    </Button>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-2">For Brands</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      Connect with verified creators and launch successful campaigns.
                    </p>
                    <Button 
                      onClick={() => setLocation("/register")}
                      className="w-full"
                      variant="outline"
                    >
                      Join as Brand
                    </Button>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <p className="text-sm text-gray-600">
                    <strong>Contact:</strong> hello@dobletap.com | <strong>Support:</strong> support@dobletap.com
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}