# SMM Panel Process - Dobble Tap Platform

## Overview

The SMM Panel system is designed for micro-activities that provide instant engagement for brands through small, quick tasks. It operates differently from regular campaigns with immediate payments and simplified workflows.

## Key Differences: SMM Panel vs Regular Campaigns

### **Regular Campaigns**
- **Budget**: ₦100,000+ minimum
- **Process**: Application → Brand approval → Task completion → Payment
- **Duration**: Days to weeks
- **Payment**: Split equally among approved creators (minimum ₦5,000 per creator)
- **Selection**: Geographic targeting, follower requirements, manual approval
- **Tasks**: Complex content creation, sponsored posts, brand partnerships

### **SMM Panel Activities**
- **Budget**: ₦50,000+ minimum (lower barrier)
- **Process**: Direct participation → Complete task → Instant payment
- **Duration**: Minutes to hours
- **Payment**: Fixed amount per activity (₦100-₦2,000 per task)
- **Selection**: First-come, first-served basis
- **Tasks**: Simple actions (likes, follows, comments, shares)

## SMM Panel Workflow

### 1. Activity Creation (Brands)
Brands create micro-activities with:
- **Platform**: Instagram, TikTok, YouTube, Twitter, Snapchat
- **Activity Type**: Like, Follow, Comment, Share, Watch
- **Price per Action**: ₦100-₦2,000 per completion
- **Max Participants**: 100-1,000 people
- **Time Limit**: 5-60 minutes
- **Target Link**: Specific post/video to engage with

### 2. Activity Discovery (Creators)
Creators see available activities on `/smm-panel` page:
- **Real-time Feed**: Live activities from all platforms
- **Platform Filters**: Filter by Instagram, TikTok, etc.
- **Activity Filters**: Filter by like, follow, comment, etc.
- **Instant Participation**: Click to join immediately
- **Quick Requirements**: Must have account on target platform

### 3. Task Completion
Simple process for creators:
1. **Click Activity**: Join the activity instantly
2. **Follow Instructions**: Click provided link, perform action
3. **Submit Proof**: Upload screenshot of completed action
4. **Get Paid**: Instant payment upon verification

### 4. Payment Processing
- **Instant Payments**: No waiting for brand approval
- **Fixed Amounts**: Each activity has predetermined payment
- **Automatic Verification**: System checks proof and pays instantly
- **Micro-Transactions**: Small amounts (₦100-₦2,000) per task

## Example SMM Panel Activities

### Instagram Activities
- **Like Post**: ₦100 per like (5 minutes, 500 participants)
- **Follow Account**: ₦150 per follow (10 minutes, 300 participants)
- **Comment on Post**: ₦250 per comment (15 minutes, 100 participants)
- **Share Story**: ₦200 per share (10 minutes, 200 participants)

### TikTok Activities
- **Like Video**: ₦120 per like (5 minutes, 400 participants)
- **Follow Creator**: ₦180 per follow (10 minutes, 250 participants)
- **Comment on Video**: ₦300 per comment (20 minutes, 80 participants)
- **Share Video**: ₦250 per share (15 minutes, 150 participants)

### YouTube Activities
- **Like Video**: ₦150 per like (10 minutes, 300 participants)
- **Subscribe to Channel**: ₦250 per subscription (15 minutes, 200 participants)
- **Comment on Video**: ₦400 per comment (20 minutes, 50 participants)
- **Watch Video (full)**: ₦500 per watch (video duration + 5 minutes, 100 participants)

## Benefits of SMM Panel

### For Brands:
- **Instant Engagement**: Immediate likes, follows, comments
- **Cost-Effective**: Pay only for completed actions
- **Scalable**: Reach hundreds of users quickly
- **Platform Specific**: Target specific social media platforms
- **No Long-term Commitment**: One-time activities

### For Creators:
- **Quick Earnings**: Earn money in minutes
- **No Application Process**: Join activities instantly
- **Low Barrier**: Simple tasks anyone can complete
- **Flexible**: Work when you want, as much as you want
- **Instant Payment**: Get paid immediately after completion

## Payment Structure Examples

### Scenario 1: Instagram Like Campaign
- **Activity**: Like Instagram post
- **Price**: ₦100 per like
- **Budget**: ₦50,000
- **Max Participants**: 500 creators
- **Payment**: Each creator gets ₦100 instantly

### Scenario 2: YouTube Subscribe Campaign
- **Activity**: Subscribe to YouTube channel
- **Price**: ₦250 per subscription
- **Budget**: ₦50,000
- **Max Participants**: 200 creators
- **Payment**: Each creator gets ₦250 instantly

## Quality Control

### Verification Process:
1. **Screenshot Proof**: Creators submit screenshot of completed action
2. **Automatic Checking**: System verifies screenshot matches requirements
3. **Instant Payment**: Payment released immediately upon verification
4. **Fraud Prevention**: Duplicate submissions blocked, accounts monitored

### Activity Limits:
- **Per User**: Maximum 10 activities per day per platform
- **Per Activity**: Each creator can only complete same activity once
- **Time Limits**: Activities expire after set time limit
- **Geographic**: Some activities limited by country/region

## Technical Implementation

### Database Schema:
- **SMM Activities**: Store activity details, pricing, limits
- **Activity Completions**: Track who completed what
- **Instant Payments**: Immediate payment processing
- **Verification System**: Screenshot and proof management

### API Endpoints:
- `GET /api/smm-activities` - Get available activities
- `POST /api/smm-activities/:id/complete` - Complete an activity
- `POST /api/smm-activities/create` - Create new activity (brands)
- `GET /api/smm-activities/my-completions` - Get creator's completions

This system provides a complementary earning opportunity alongside regular campaigns, focusing on quick, simple tasks with immediate rewards.