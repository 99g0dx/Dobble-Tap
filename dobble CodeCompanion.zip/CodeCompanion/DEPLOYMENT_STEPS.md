# Deployment Steps for www.dobbletap.com

## Where to Set Environment Variables

### Option 1: Replit (Current Environment)
1. In your Replit project, click the "Secrets" tab (lock icon)
2. Add each environment variable:
   - Key: `GOOGLE_CLIENT_ID`
   - Value: `your_google_client_id_here`
   - Click "Add secret"
3. Repeat for all variables in your `.env` file

### Option 2: Other Hosting Providers

**Vercel:**
1. Go to your project dashboard
2. Click "Settings" → "Environment Variables"
3. Add each variable with its value

**Netlify:**
1. Go to Site settings
2. Click "Environment variables"
3. Add each variable

**Railway:**
1. Go to your project
2. Click "Variables"
3. Add each variable

**DigitalOcean App Platform:**
1. Go to your app
2. Click "Settings" → "App-Level Environment Variables"
3. Add each variable

## Complete Environment Variables List

```bash
# Domain Configuration
FRONTEND_URL=https://www.dobbletap.com
DOMAIN_URL=https://www.dobbletap.com

# Security
SESSION_SECRET=ec45f5663f719f11780dbb1cd64d4e66fa2a3e60d8170cd9f937a649f842936b

# Google OAuth (get from Google Cloud Console)
GOOGLE_CLIENT_ID=your_google_client_id_here
GOOGLE_CLIENT_SECRET=your_google_client_secret_here

# Paystack (get from Paystack Dashboard)
PAYSTACK_SECRET_KEY=your_live_paystack_secret_key
PAYSTACK_PUBLIC_KEY=your_live_paystack_public_key

# Email (already configured)
RESEND_API_KEY=your_resend_api_key

# Production
NODE_ENV=production
PORT=5000
```

## Deployment Commands

### Build the application:
```bash
npm run build
```

### Start production server:
```bash
npm start
```

### For development testing:
```bash
npm run dev
```

## After Deployment Testing

### Test these URLs:
1. `https://www.dobbletap.com/health` - Should return healthy status
2. `https://www.dobbletap.com/api/launch-check` - Should show readiness score
3. `https://www.dobbletap.com` - Should load homepage

### Test user flows:
1. Register new account
2. Login with Google OAuth
3. Create campaign (brand)
4. Apply to campaign (creator)
5. Process payment