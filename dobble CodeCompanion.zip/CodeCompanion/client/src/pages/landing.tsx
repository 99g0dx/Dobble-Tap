import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState } from "react";
import { 
  Zap, 
  Users, 
  Building, 
  ShieldCheck, 
  CheckCircle, 
  Star,
  DollarSign,
  Activity,
  TrendingUp,
  Instagram,
  Twitter,
  Check,
  Mail,
  Send
} from "lucide-react";
import { 
  SiInstagram, 
  SiX, 
  SiTiktok, 
  SiYoutube, 
  SiLinkedin, 
  SiFacebook 
} from "react-icons/si";

export default function Landing() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // Here you would typically send the email to your backend
      console.log("Email submitted:", email);
      setIsSubmitted(true);
      setEmail("");
    }
  };

  const stats = [
    { label: "Active Creators", value: "5K+" },
    { label: "Tasks Completed", value: "1.2M+" },
    { label: "Paid to Creators", value: "₦450M+" },
  ];

  const features = [
    {
      icon: Users,
      title: "For Creators",
      description: "Complete engaging tasks, build your audience, and earn money doing what you love.",
      benefits: [
        "Browse available campaigns",
        "Complete tasks & submit proof",
        "Get paid instantly"
      ]
    },
    {
      icon: Building,
      title: "For Brands", 
      description: "Launch targeted campaigns, reach authentic audiences, and measure real impact.",
      benefits: [
        "Create targeted campaigns",
        "Connect with verified creators",
        "Track performance analytics"
      ]
    },
    {
      icon: ShieldCheck,
      title: "Secure & Trusted",
      description: "Built with security and trust at its core, ensuring safe transactions and authentic connections.",
      benefits: [
        "Verified creator profiles",
        "Secure payment processing",
        "24/7 support"
      ]
    }
  ];

  const testimonials = [
    {
      name: "Kemi Adebayo",
      role: "Lifestyle Creator, Lagos",
      content: "Dobble Tap has completely changed how I monetize my content. The platform is intuitive, payments are instant, and the campaigns are always relevant to my audience.",
      avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64"
    },
    {
      name: "Chidi Okonkwo",
      role: "Marketing Director, TechFlow",
      content: "As a startup, finding authentic creators to promote our brand was challenging. Dobble Tap connected us with amazing talent that truly understands our target market.",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64"
    },
    {
      name: "Amina Hassan",
      role: "Student, University of Ibadan",
      content: "Being a student, I needed flexible income. Dobble Tap lets me complete tasks around my class schedule and I've earned enough to pay for my books and meals.",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b5b5eb8f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header with Logo */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-black">Dobble Tap</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="ghost" className="text-gray-700 hover:text-black">
                  Login
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  Sign Up
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gray-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="font-bold text-4xl md:text-5xl text-white mb-6">
                Empowering African <span className="text-blue-600">Creators</span> & Brands
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Connect, create, and monetize your influence. The first platform designed specifically for African creators and brands to collaborate on impactful campaigns.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link href="/register?role=creator">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-semibold">
                    Start Creating
                  </Button>
                </Link>
                <Link href="/register?role=brand">
                  <Button className="bg-white text-black hover:bg-gray-100 border-2 border-white px-8 py-4 text-lg font-semibold">
                    Launch Campaign
                  </Button>
                </Link>
              </div>
              
              {/* Stats */}
              <div className="flex justify-center lg:justify-start space-x-8 mt-12">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className="font-bold text-2xl text-white">{stat.value}</div>
                    <div className="text-gray-300 text-sm">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="/attached_assets/black girl_1752650711247.webp" 
                alt="Black female creator with ring light creating content" 
                className="rounded-2xl shadow-2xl w-full h-auto" 
              />
              
              {/* Floating cards */}
              <div className="absolute -top-6 -left-6 bg-background rounded-lg shadow-lg p-4 max-w-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center">
                    <Check className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-dark">Task Completed!</p>
                    <p className="text-xs text-gray">Earned ₦2,500</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -bottom-6 -right-6 bg-background rounded-lg shadow-lg p-4 max-w-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-sm text-dark">Campaign Active</p>
                    <p className="text-xs text-gray">85% completion rate</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Features */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-dark mb-4">
              How Dobble Tap Works
            </h2>
            <p className="text-xl text-gray max-w-3xl mx-auto">
              A seamless platform connecting creators and brands for authentic, impactful campaigns across Africa.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-light text-center p-8">
                <CardContent className="space-y-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <feature.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="font-semibold text-xl text-dark">{feature.title}</h3>
                  <p className="text-gray">{feature.description}</p>
                  <div className="space-y-3">
                    {feature.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center justify-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <span className="text-sm text-gray">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Creator Dashboard Preview */}
      <section className="py-20 gradient-hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-dark mb-4">
              Creator Dashboard
            </h2>
            <p className="text-xl text-gray max-w-3xl mx-auto">
              Manage your campaigns, track earnings, and grow your influence from one powerful dashboard.
            </p>
          </div>
          
          <Card className="max-w-6xl mx-auto p-8">
            <CardContent className="space-y-8">
              {/* Dashboard Header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                <div className="flex items-center space-x-4">
                  <img 
                    src="https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=64&h=64" 
                    alt="Creator profile" 
                    className="w-16 h-16 rounded-full object-cover" 
                  />
                  <div>
                    <h3 className="font-semibold text-xl text-dark">Amara Okafor</h3>
                    <p className="text-gray">Content Creator & Lifestyle Influencer</p>
                    <div className="flex items-center space-x-4 mt-1">
                      <span className="text-sm text-gray">@amaraokafor</span>
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4 text-gray" />
                        <span className="text-sm text-gray">12.5K followers</span>
                      </div>
                    </div>
                  </div>
                </div>
                <Button className="btn-primary mt-4 md:mt-0">
                  View Profile
                </Button>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-green-50 p-6">
                  <CardContent className="flex items-center justify-between p-0">
                    <div>
                      <p className="text-sm text-gray">Total Earnings</p>
                      <p className="font-bold text-2xl text-dark">₦145,230</p>
                    </div>
                    <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-blue-50 p-6">
                  <CardContent className="flex items-center justify-between p-0">
                    <div>
                      <p className="text-sm text-gray">Tasks Completed</p>
                      <p className="font-bold text-2xl text-dark">47</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-6 h-6 text-white" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-purple-50 p-6">
                  <CardContent className="flex items-center justify-between p-0">
                    <div>
                      <p className="text-sm text-gray">Active Campaigns</p>
                      <p className="font-bold text-2xl text-dark">8</p>
                    </div>
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                      <Activity className="w-6 h-6 text-white" />
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-orange-50 p-6">
                  <CardContent className="flex items-center justify-between p-0">
                    <div>
                      <p className="text-sm text-gray">Success Rate</p>
                      <p className="font-bold text-2xl text-dark">94%</p>
                    </div>
                    <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Available Tasks */}
              <div className="space-y-4">
                <h4 className="font-semibold text-lg text-dark">Available Tasks</h4>
                <div className="space-y-4">
                  <Card className="border hover:shadow-md transition-shadow p-6">
                    <CardContent className="flex flex-col md:flex-row justify-between items-start md:items-center p-0">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="w-10 h-10 bg-pink-500 rounded-full flex items-center justify-center">
                            <Instagram className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h5 className="font-medium text-dark">Instagram Story Promotion</h5>
                            <p className="text-sm text-gray">Fashion Brand Campaign</p>
                          </div>
                        </div>
                        <p className="text-gray text-sm mb-2">Create an engaging Instagram story showcasing our new summer collection. Include branded hashtags and product mentions.</p>
                        <div className="flex items-center space-x-4 text-sm text-gray">
                          <span>⏰ 3 days left</span>
                          <span>👥 8/10 spots filled</span>
                        </div>
                      </div>
                      <div className="mt-4 md:mt-0 md:ml-6 text-right">
                        <p className="font-bold text-xl text-primary">₦15,000</p>
                        <Button className="btn-primary mt-2">
                          Apply Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="border hover:shadow-md transition-shadow p-6">
                    <CardContent className="flex flex-col md:flex-row justify-between items-start md:items-center p-0">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                            <Twitter className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h5 className="font-medium text-dark">Twitter Engagement Campaign</h5>
                            <p className="text-sm text-gray">Tech Startup Launch</p>
                          </div>
                        </div>
                        <p className="text-gray text-sm mb-2">Tweet about our new mobile app launch with specific hashtags and mention key features that resonate with your audience.</p>
                        <div className="flex items-center space-x-4 text-sm text-gray">
                          <span>⏰ 5 days left</span>
                          <span>👥 12/15 spots filled</span>
                        </div>
                      </div>
                      <div className="mt-4 md:mt-0 md:ml-6 text-right">
                        <p className="font-bold text-xl text-primary">₦8,500</p>
                        <Button className="btn-primary mt-2">
                          Apply Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-r from-secondary/10 to-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-3xl md:text-4xl text-dark mb-4">
              Loved by Creators & Brands
            </h2>
            <p className="text-xl text-gray max-w-3xl mx-auto">
              See how Dobble Tap is transforming the creator economy across Africa.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-background p-8 shadow-lg">
                <CardContent className="space-y-4">
                  <div className="flex text-accent">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray italic">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name} 
                      className="w-12 h-12 rounded-full object-cover mr-4" 
                    />
                    <div>
                      <p className="font-medium text-dark">{testimonial.name}</p>
                      <p className="text-sm text-gray">{testimonial.role}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-bold text-3xl md:text-4xl text-white mb-4">
            Ready to Transform Your Influence?
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Join thousands of creators and brands who are already building authentic connections and driving real results on Dobble Tap.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register?role=creator">
              <Button className="bg-white text-black hover:bg-gray-100 px-8 py-4 text-lg">
                Start as Creator
              </Button>
            </Link>
            <Link href="/register?role=brand">
              <Button className="bg-blue-600 text-white hover:bg-blue-700 px-8 py-4 text-lg font-semibold">
                Launch Campaign
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="font-bold text-2xl md:text-3xl text-black mb-2">
              Get in Touch
            </h2>
            <p className="text-gray-600">
              Leave your email and we'll get back to you soon.
            </p>
          </div>
          
          <div className="max-w-sm mx-auto">
            <Card className="p-6 border border-gray-200 shadow-md">
              <CardContent className="space-y-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                
                {isSubmitted ? (
                  <div className="text-center space-y-3">
                    <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center mx-auto">
                      <Check className="w-5 h-5 text-white" />
                    </div>
                    <p className="text-green-600 font-medium">Thank you! We'll be in touch soon.</p>
                  </div>
                ) : (
                  <form onSubmit={handleEmailSubmit} className="space-y-3">
                    <div>
                      <Input
                        id="contact-email"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        className="border-2 border-gray-300 focus:border-blue-600 h-10"
                        required
                      />
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white h-10 font-semibold"
                    >
                      Submit
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-2xl font-bold text-white">Dobble Tap</h1>
              </div>
              <p className="text-gray-300 mb-6 max-w-md">
                Empowering African creators and brands to build authentic connections and drive real results through innovative campaigns.
              </p>
              
              {/* Social Media Icons */}
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiInstagram className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiX className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiTiktok className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiYoutube className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiLinkedin className="w-5 h-5 text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                  <SiFacebook className="w-5 h-5 text-white" />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">For Creators</h3>
              <ul className="space-y-2 text-gray-300">
                <li><Link href="/register?role=creator" className="hover:text-white">Join as Creator</Link></li>
                <li><Link href="/tasks" className="hover:text-white">Browse Tasks</Link></li>
                <li><Link href="/smm-panel" className="hover:text-white">SMM Panel</Link></li>
                <li><Link href="/wallet" className="hover:text-white">Wallet</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">For Brands</h3>
              <ul className="space-y-2 text-gray-300">
                <li><Link href="/register?role=brand" className="hover:text-white">Join as Brand</Link></li>
                <li><Link href="/create-campaign" className="hover:text-white">Create Campaign</Link></li>
                <li><Link href="/brand-dashboard" className="hover:text-white">Dashboard</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <a href="mailto:support@dobbletap.com" className="hover:text-white flex items-center">
                    <Mail className="w-4 h-4 mr-2" />
                    support@dobbletap.com
                  </a>
                </li>
                <li><Link href="/help" className="hover:text-white">Help Center</Link></li>
                <li><Link href="/about" className="hover:text-white">About Us</Link></li>
                <li className="text-gray-400 text-sm">Response within 24 hours</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-6 mb-4">
              <Link href="/privacy-policy" className="hover:text-white text-sm">Privacy Policy</Link>
              <Link href="/terms-of-service" className="hover:text-white text-sm">Terms of Service</Link>
              <Link href="/about" className="hover:text-white text-sm">About</Link>
            </div>
            <p>&copy; 2025 Dobble Tap. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
