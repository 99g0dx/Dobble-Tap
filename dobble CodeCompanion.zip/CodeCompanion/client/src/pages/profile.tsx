import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Edit2, 
  Save, 
  X, 
  Instagram, 
  Twitter, 
  Youtube, 
  Facebook, 
  Linkedin,
  Music,
  CheckCircle,
  Calendar,
  Globe,
  Upload,
  Camera,
  GraduationCap,
  Search,
  Zap
} from "lucide-react";
import { countries, getCountryByCode } from "@/lib/countries";
import { getStatesByCountry, hasStates } from "@/lib/states";

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().optional(),
  bio: z.string().optional(),
  age: z.number().min(13, "You must be at least 13 years old").max(120, "Please enter a valid age").optional(),
  gender: z.enum(["male", "female", "other"], {
    required_error: "Please select your gender",
  }).optional(),
  state: z.string().optional(),
  country: z.string().optional(),
  school: z.string().optional(),
  instagramHandle: z.string().optional(),
  twitterHandle: z.string().optional(),
  youtubeHandle: z.string().optional(),
  facebookHandle: z.string().optional(),
  tiktokHandle: z.string().optional(),
  snapchatHandle: z.string().optional(),
  linkedinHandle: z.string().optional(),
});

type ProfileForm = z.infer<typeof profileSchema>;

const nigerianStates = [
  "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno", "Cross River", "Delta",
  "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT", "Gombe", "Imo", "Jigawa", "Kaduna", "Kano", "Katsina",
  "Kebbi", "Kogi", "Kwara", "Lagos", "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau",
  "Rivers", "Sokoto", "Taraba", "Yobe", "Zamfara"
];

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [countrySearch, setCountrySearch] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  // Fetch user profile data
  const { data: userProfile, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: 1
  });

  const form = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: userProfile?.name || "",
      phone: userProfile?.phone || "",
      bio: userProfile?.bio || "",
      age: userProfile?.age || undefined,
      gender: userProfile?.gender || undefined,
      state: userProfile?.state || "",
      country: userProfile?.country || "NG",
      school: userProfile?.school || "",
      instagramHandle: userProfile?.instagramHandle || "",
      twitterHandle: userProfile?.twitterHandle || "",
      youtubeHandle: userProfile?.youtubeHandle || "",
      facebookHandle: userProfile?.facebookHandle || "",
      tiktokHandle: userProfile?.tiktokHandle || "",
      snapchatHandle: userProfile?.snapchatHandle || "",
      linkedinHandle: userProfile?.linkedinHandle || "",
    }
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: (data: ProfileForm) => apiRequest(`/api/users/${user?.id}`, {
      method: "PUT",
      data: data
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setIsEditing(false);
      toast({
        title: "Profile updated successfully",
        description: "Your profile information has been saved."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating profile",
        description: error.message || "Something went wrong"
      });
    }
  });

  const onSubmit = (data: ProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  // Initialize selected country when userProfile loads
  useEffect(() => {
    if (userProfile?.country) {
      setSelectedCountry(userProfile.country);
    }
  }, [userProfile]);

  const handleCancel = () => {
    form.reset();
    setIsEditing(false);
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive"
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select an image under 5MB",
        variant: "destructive"
      });
      return;
    }

    setUploadingImage(true);

    try {
      // Convert to base64 for simple storage
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        
        // Update profile with new avatar
        await apiRequest(`/api/users/${user?.id}`, {
          method: "PUT",
          data: { avatarUrl: base64String }
        });
        
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        toast({
          title: "Profile picture updated",
          description: "Your profile picture has been updated successfully"
        });
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload image. Please try again.",
        variant: "destructive"
      });
    } finally {
      setUploadingImage(false);
    }
  };

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case 'instagram':
        return <Instagram className="w-4 h-4" />;
      case 'twitter':
        return <Twitter className="w-4 h-4" />;
      case 'youtube':
        return <Youtube className="w-4 h-4" />;
      case 'facebook':
        return <Facebook className="w-4 h-4" />;
      case 'tiktok':
        return <Music className="w-4 h-4" />;
      case 'linkedin':
        return <Linkedin className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getSocialColor = (platform: string) => {
    switch (platform) {
      case 'instagram':
        return 'text-pink-500';
      case 'twitter':
        return 'text-blue-500';
      case 'youtube':
        return 'text-red-500';
      case 'facebook':
        return 'text-blue-600';
      case 'tiktok':
        return 'text-black';
      case 'linkedin':
        return 'text-blue-700';
      default:
        return 'text-gray-500';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={userProfile?.avatarUrl} />
                  <AvatarFallback className="text-lg">
                    {userProfile?.name?.charAt(0)?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                {isEditing && (
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingImage}
                  >
                    {uploadingImage ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                  </Button>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{userProfile?.name}</h1>
                <p className="text-gray-600 capitalize">{userProfile?.role}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={userProfile?.verificationStatus === 'verified' ? 'default' : 'secondary'}>
                    {userProfile?.verificationStatus === 'verified' ? (
                      <>
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Verified
                      </>
                    ) : (
                      'Pending Verification'
                    )}
                  </Badge>
                </div>
              </div>
            </div>
            <Button
              onClick={() => setIsEditing(!isEditing)}
              variant={isEditing ? "secondary" : "default"}
            >
              {isEditing ? (
                <>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </>
              ) : (
                <>
                  <Edit2 className="w-4 h-4 mr-2" />
                  Edit Profile
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    {...form.register("name")}
                    disabled={!isEditing}
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-red-500">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Enter your phone number"
                    {...form.register("phone")}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  placeholder="Tell us about yourself"
                  {...form.register("bio")}
                  disabled={!isEditing}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="Enter your age"
                    {...form.register("age", { valueAsNumber: true })}
                    disabled={!isEditing}
                  />
                  {form.formState.errors.age && (
                    <p className="text-sm text-red-500">{form.formState.errors.age.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select
                    value={form.watch("gender")}
                    onValueChange={(value) => form.setValue("gender", value as any)}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Select 
                    value={form.watch("country")} 
                    onValueChange={(value) => {
                      form.setValue("country", value);
                      setSelectedCountry(value);
                      // Reset state when country changes
                      form.setValue("state", "");
                    }}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your country" />
                    </SelectTrigger>
                    <SelectContent>
                      <div className="flex items-center px-3 py-2 border-b">
                        <Search className="w-4 h-4 mr-2 text-gray-500" />
                        <Input
                          placeholder="Search countries..."
                          value={countrySearch}
                          onChange={(e) => setCountrySearch(e.target.value)}
                          className="border-0 p-0 h-6 focus:ring-0"
                        />
                      </div>
                      {countries
                        .filter(country => 
                          country.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
                          country.code.toLowerCase().includes(countrySearch.toLowerCase())
                        )
                        .map(country => (
                          <SelectItem key={country.code} value={country.name}>
                            {country.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="state">State of Origin</Label>
                  <Select 
                    value={form.watch("state")} 
                    onValueChange={(value) => form.setValue("state", value)}
                    disabled={!isEditing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your state of origin" />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedCountry && hasStates(selectedCountry) ? (
                        getStatesByCountry(selectedCountry).map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))
                      ) : (
                        <SelectItem value="n/a">No states available</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                
                {/* School field for students */}
                {userProfile?.role === "student" && (
                  <div className="space-y-2">
                    <Label htmlFor="school" className="flex items-center gap-2">
                      <GraduationCap className="w-4 h-4" />
                      School/Institution
                    </Label>
                    <Input
                      id="school"
                      placeholder="Enter your school or institution name"
                      {...form.register("school")}
                      disabled={!isEditing}
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Social Media Handles */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Social Media Handles
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="instagramHandle" className="flex items-center gap-2">
                    <Instagram className="w-4 h-4 text-pink-500" />
                    Instagram Handle
                  </Label>
                  <Input
                    id="instagramHandle"
                    placeholder="@username"
                    {...form.register("instagramHandle")}
                    disabled={!isEditing}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="twitterHandle" className="flex items-center gap-2">
                    <Twitter className="w-4 h-4 text-blue-500" />
                    Twitter Handle
                  </Label>
                  <Input
                    id="twitterHandle"
                    placeholder="@username"
                    {...form.register("twitterHandle")}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="youtubeHandle" className="flex items-center gap-2">
                    <Youtube className="w-4 h-4 text-red-500" />
                    YouTube Handle
                  </Label>
                  <Input
                    id="youtubeHandle"
                    placeholder="@username"
                    {...form.register("youtubeHandle")}
                    disabled={!isEditing}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="facebookHandle" className="flex items-center gap-2">
                    <Facebook className="w-4 h-4 text-blue-600" />
                    Facebook Handle
                  </Label>
                  <Input
                    id="facebookHandle"
                    placeholder="username"
                    {...form.register("facebookHandle")}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tiktokHandle" className="flex items-center gap-2">
                    <Music className="w-4 h-4 text-black" />
                    TikTok Handle
                  </Label>
                  <Input
                    id="tiktokHandle"
                    placeholder="@username"
                    {...form.register("tiktokHandle")}
                    disabled={!isEditing}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="snapchatHandle" className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    Snapchat Handle
                  </Label>
                  <Input
                    id="snapchatHandle"
                    placeholder="@username"
                    {...form.register("snapchatHandle")}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="linkedinHandle" className="flex items-center gap-2">
                    <Linkedin className="w-4 h-4 text-blue-700" />
                    LinkedIn Handle
                  </Label>
                  <Input
                    id="linkedinHandle"
                    placeholder="username"
                    {...form.register("linkedinHandle")}
                    disabled={!isEditing}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                Account Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email Address</Label>
                  <Input
                    value={userProfile?.email || ""}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Member Since</Label>
                  <Input
                    value={userProfile?.createdAt ? new Date(userProfile.createdAt).toLocaleDateString() : ""}
                    disabled
                    className="bg-gray-50"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          {isEditing && (
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={handleCancel}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={updateProfileMutation.isPending}
              >
                <Save className="w-4 h-4 mr-2" />
                {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}