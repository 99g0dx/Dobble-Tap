import express, { type Request, Response, NextFunction } from "express";
import cors from "cors";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { 
  generalRateLimit, 
  authRateLimit,
  paymentRateLimit,
  securityHeaders, 
  corsOptions, 
  sanitizeInput, 
  securityLogger 
} from "./middleware/security";
import { 
  healthCheck 
} from "./middleware/monitoring";
import { analyticsService } from "./services/analytics";
import { performanceService } from "./services/performance";

const app = express();

// Security middleware - disabled for clean deployment
// app.use(securityHeaders);
// app.use(securityLogger);
// app.use(sanitizeInput);

// Simple request logging (only in development)
if (process.env.NODE_ENV === 'development') {
  app.use((req, res, next) => {
    const start = Date.now();
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    
    res.on('finish', () => {
      const duration = Date.now() - start;
      if (duration > 1000) {
        console.warn(`Slow request: ${req.method} ${req.url} - ${duration}ms`);
      }
    });
    
    next();
  });
}

// Rate limiting - disabled for clean deployment
// app.use('/api', generalRateLimit);
// app.use('/api/auth', authRateLimit);
// app.use('/api/payments', paymentRateLimit);

// CORS configuration - simplified for development
app.use(cors({
  origin: true,
  credentials: true,
  optionsSuccessStatus: 200
}));

// Health check endpoint
app.get('/health', healthCheck);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    // Log error for debugging
    console.error(`Error ${status}: ${message}`, {
      method: req.method,
      url: req.url,
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      timestamp: new Date().toISOString(),
      stack: err.stack
    });

    // Don't expose internal errors in production
    if (process.env.NODE_ENV === 'production' && status === 500) {
      res.status(500).json({ message: "Something went wrong. Please try again later." });
    } else {
      res.status(status).json({ message });
    }
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
