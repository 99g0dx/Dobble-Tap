import { Button } from "@/components/ui/button";
import { CheckCircle, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import africanCreators from "@/assets/african-creators.svg";
import africanBrands from "@/assets/african-brands.svg";

export default function HeroSection() {
  return (
    <section className="bg-gray-900 py-12 sm:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="font-poppins font-bold text-3xl sm:text-4xl md:text-5xl text-white mb-4 sm:mb-6">
              Empowering African <span className="text-blue-400">Creators</span> & <span className="text-white">Brands</span>
            </h1>
            <p className="text-lg sm:text-xl text-gray-300 mb-6 sm:mb-8 leading-relaxed">
              Connect, create, and monetize your influence. The first platform designed specifically for African creators and brands to collaborate on impactful campaigns.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center lg:justify-start">
              <Link href="/auth/register?role=creator">
                <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold shadow-lg w-full sm:w-auto">
                  Start Creating
                </Button>
              </Link>
              <Link href="/auth/register?role=brand">
                <Button size="lg" className="bg-blue-600 text-white hover:bg-blue-700 border-2 border-blue-600 hover:border-blue-700 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-semibold shadow-lg w-full sm:w-auto">
                  Launch Campaign
                </Button>
              </Link>
            </div>
            
            {/* Stats */}
            <div className="flex justify-center lg:justify-start space-x-4 sm:space-x-8 mt-8 sm:mt-12">
              <div className="text-center">
                <div className="font-poppins font-bold text-xl sm:text-2xl text-white">5K+</div>
                <div className="text-white/80 text-xs sm:text-sm">Active Creators</div>
              </div>
              <div className="text-center">
                <div className="font-poppins font-bold text-xl sm:text-2xl text-white">1.2M+</div>
                <div className="text-white/80 text-xs sm:text-sm">Tasks Completed</div>
              </div>
              <div className="text-center">
                <div className="font-poppins font-bold text-xl sm:text-2xl text-white">₦450M+</div>
                <div className="text-white/80 text-xs sm:text-sm">Paid to Creators</div>
              </div>
            </div>
          </div>
          
          <div className="relative mt-8 lg:mt-0">
            <img 
              src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
              alt="Young African creators collaborating and creating content"
              className="rounded-2xl shadow-2xl w-full h-auto" 
            />
            
            {/* Floating cards */}
            <div className="absolute -top-3 -left-3 sm:-top-6 sm:-left-6 bg-blue-600 rounded-lg shadow-lg p-3 sm:p-4 max-w-xs">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-xs sm:text-sm text-white">Task Completed!</p>
                  <p className="text-xs text-white/80">Earned ₦2,500</p>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-3 -right-3 sm:-bottom-6 sm:-right-6 bg-gray-800 rounded-lg shadow-lg p-3 sm:p-4 max-w-xs">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-xs sm:text-sm text-white">Campaign Active</p>
                  <p className="text-xs text-white/80">5.2K reach</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
