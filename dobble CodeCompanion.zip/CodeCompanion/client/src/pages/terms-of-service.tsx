import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, FileText, Scale, CreditCard, AlertTriangle } from "lucide-react";
import { useLocation } from "wouter";

export default function TermsOfService() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLocation("/")}
                className="text-white hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
              <div className="border-l border-gray-600 pl-4">
                <h1 className="text-2xl font-bold text-white">Terms of Service</h1>
                <p className="text-gray-300 text-sm">Last updated: January 2025</p>
              </div>
            </div>
            <Scale className="w-8 h-8 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          {/* Introduction */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Agreement to Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p>
                Welcome to Dobble Tap! By accessing and using our platform, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using our platform.
              </p>
            </CardContent>
          </Card>

          {/* Platform Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Platform Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Dobble Tap is a creator monetization platform that connects content creators with brands for promotional campaigns. Our platform facilitates:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700">
                <li>Campaign creation and management by brands</li>
                <li>Creator recruitment and task assignment</li>
                <li>Payment processing and earnings distribution</li>
                <li>Performance tracking and analytics</li>
                <li>Support and dispute resolution services</li>
              </ul>
            </CardContent>
          </Card>

          {/* User Responsibilities */}
          <Card>
            <CardHeader>
              <CardTitle>User Responsibilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">For All Users</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Provide accurate and truthful information</li>
                    <li>Maintain the security of your account credentials</li>
                    <li>Comply with all applicable laws and regulations</li>
                    <li>Respect intellectual property rights</li>
                    <li>Engage in professional and respectful communication</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">For Creators</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Complete tasks according to campaign requirements</li>
                    <li>Provide authentic engagement and content</li>
                    <li>Disclose sponsored content as required by law</li>
                    <li>Maintain active and genuine social media accounts</li>
                    <li>Submit work within specified deadlines</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">For Brands</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Provide clear and achievable campaign requirements</li>
                    <li>Make timely payments as agreed</li>
                    <li>Respect creator intellectual property</li>
                    <li>Provide constructive feedback and reviews</li>
                    <li>Comply with advertising standards and regulations</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Terms */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-600" />
                Payment Terms
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Payment Processing</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Payments are processed through secure third-party providers</li>
                    <li>Platform fees are deducted from earnings as disclosed</li>
                    <li>Minimum withdrawal amounts apply as specified</li>
                    <li>Payment processing times may vary by method and location</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Disputes and Refunds</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Payment disputes must be reported within 30 days</li>
                    <li>Refunds are processed according to our refund policy</li>
                    <li>Fraudulent activities may result in account suspension</li>
                    <li>Chargebacks may incur additional fees</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Taxation</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Users are responsible for their own tax obligations</li>
                    <li>Tax reporting may be required for high-earning accounts</li>
                    <li>Consult with tax professionals for compliance guidance</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Prohibited Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Prohibited Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>The following activities are strictly prohibited:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Creating fake accounts or using automated tools</li>
                  <li>Engaging in fraudulent or deceptive practices</li>
                  <li>Purchasing fake followers, likes, or engagement</li>
                  <li>Violating platform terms of social media networks</li>
                  <li>Sharing or selling account credentials</li>
                  <li>Harassment, discrimination, or inappropriate behavior</li>
                  <li>Posting illegal, harmful, or offensive content</li>
                  <li>Attempting to circumvent platform security measures</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Content and IP Rights */}
          <Card>
            <CardHeader>
              <CardTitle>Content and Intellectual Property</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Content Ownership</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Creators retain ownership of their original content</li>
                    <li>Brands receive usage rights as specified in campaigns</li>
                    <li>Platform reserves rights to use content for promotional purposes</li>
                    <li>Users grant platform limited license for service operation</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Copyright Protection</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Users must not infringe on third-party copyrights</li>
                    <li>DMCA takedown procedures are in place</li>
                    <li>Repeat infringers may face account termination</li>
                    <li>Fair use principles apply where applicable</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Termination */}
          <Card>
            <CardHeader>
              <CardTitle>Account Termination</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Termination by User</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Users may terminate their account at any time</li>
                    <li>Outstanding payments will be processed according to policy</li>
                    <li>Some data may be retained for legal compliance</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Termination by Platform</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Accounts may be suspended for terms violations</li>
                    <li>Repeated violations may result in permanent termination</li>
                    <li>Platform reserves right to refuse service</li>
                    <li>Users will be notified of termination when possible</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Limitation of Liability */}
          <Card>
            <CardHeader>
              <CardTitle>Limitation of Liability</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  Dobble Tap operates as a platform connecting creators and brands. We are not responsible for:
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Quality of work or content created by users</li>
                  <li>Disputes between creators and brands</li>
                  <li>Third-party payment processor issues</li>
                  <li>Social media platform policy changes</li>
                  <li>Loss of income due to platform changes</li>
                  <li>Indirect, incidental, or consequential damages</li>
                </ul>
                <p className="text-sm text-gray-600 mt-4">
                  Our liability is limited to the amount paid to us in the 12 months preceding any claim.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Governing Law */}
          <Card>
            <CardHeader>
              <CardTitle>Governing Law and Disputes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p>
                  These terms are governed by the laws of Nigeria. Any disputes will be resolved through:
                </p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Good faith negotiation between parties</li>
                  <li>Mediation through agreed mediators</li>
                  <li>Arbitration in Lagos, Nigeria if necessary</li>
                  <li>Local courts as a last resort</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Changes to Terms */}
          <Card>
            <CardHeader>
              <CardTitle>Changes to Terms</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                We may update these Terms of Service periodically. We will notify users of significant changes through:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700">
                <li>Email notifications to registered users</li>
                <li>Platform announcements and notifications</li>
                <li>Updates to this page with revision dates</li>
              </ul>
              <p className="text-sm text-gray-600 mt-4">
                Continued use of the platform constitutes acceptance of updated terms.
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                For questions about these Terms of Service, contact us:
              </p>
              <div className="space-y-2 text-gray-700">
                <p><strong>Email:</strong> legal@dobletap.com</p>
                <p><strong>Support:</strong> support@dobletap.com</p>
                <p><strong>Address:</strong> Lagos, Nigeria</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}