import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  profileImageUrl?: string;
  nationality?: string;
  stateOfOrigin?: string;
  instagramHandle?: string;
  twitterHandle?: string;
  tiktokHandle?: string;
  youtubeHandle?: string;
  snapchatHandle?: string;
}

export function useAuth() {
  const [token, setToken] = useState<string | null>(
    localStorage.getItem("token")
  );

  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      if (!token) return null;
      return apiRequest("/api/auth/me", "GET");
    },
    enabled: !!token,
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const login = async (email: string, password: string) => {
    try {
      const response = await apiRequest("/api/auth/login", "POST", {
        email,
        password,
      });
      
      if (response.token) {
        localStorage.setItem("token", response.token);
        setToken(response.token);
        return response;
      }
      
      throw new Error("Invalid credentials");
    } catch (error) {
      throw error;
    }
  };

  const register = async (userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: string;
    nationality?: string;
    stateOfOrigin?: string;
  }) => {
    try {
      const response = await apiRequest("/api/auth/register", "POST", userData);
      
      if (response.token) {
        localStorage.setItem("token", response.token);
        setToken(response.token);
        return response;
      }
      
      throw new Error("Registration failed");
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    setToken(null);
    window.location.href = "/";
  };

  const updateProfile = async (profileData: Partial<User>) => {
    try {
      const response = await apiRequest("/api/auth/profile", "PUT", profileData);
      return response;
    } catch (error) {
      throw error;
    }
  };

  return {
    user,
    isLoading,
    isAuthenticated: !!token && !!user,
    login,
    register,
    logout,
    updateProfile,
    error,
  };
}