# Dobble Tap Deployment Guide for www.dobbletap.com

## **STEP 2: Production Environment Variables** ✅

### Your Environment Variables (Set these in your hosting provider):

```bash
# Domain Configuration
FRONTEND_URL=https://www.dobbletap.com
DOMAIN_URL=https://www.dobbletap.com

# Security - Use this generated secret
SESSION_SECRET=ec45f5663f719f11780dbb1cd64d4e66fa2a3e60d8170cd9f937a649f842936b

# Google OAuth - Get from Google Cloud Console
GOOGLE_CLIENT_ID=your_google_client_id_here
GOOGLE_CLIENT_SECRET=your_google_client_secret_here

# Paystack Live Keys - Get from Paystack Dashboard
PAYSTACK_SECRET_KEY=sk_live_your_live_secret_key
PAYSTACK_PUBLIC_KEY=pk_live_your_live_public_key

# Email Service (already configured)
RESEND_API_KEY=your_resend_api_key

# Production Settings
NODE_ENV=production
PORT=5000
```

### How to Get Google OAuth Credentials:
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create project: "Dobble Tap Production"
3. Enable Google+ API
4. Create OAuth 2.0 credentials:
   - Authorized JavaScript origins: `https://www.dobbletap.com`
   - Authorized redirect URIs: `https://www.dobbletap.com/api/auth/google/callback`

### How to Get Paystack Live Keys:
1. Go to [Paystack Dashboard](https://dashboard.paystack.com/)
2. Switch to "Live" mode
3. Copy Live Secret Key (starts with `sk_live_`)
4. Copy Live Public Key (starts with `pk_live_`)

## **STEP 3: Database Migration** ✅ COMPLETED

Your database is already set up with all tables. No migration needed!

## **STEP 4: Deploy and Test for www.dobbletap.com**

### Pre-Deployment Checklist:
- [ ] Set all environment variables above
- [ ] Verify SSL certificate for www.dobbletap.com
- [ ] Configure your hosting provider to serve on port 5000

### Test Endpoints After Deployment:
1. **Health Check**: `https://www.dobbletap.com/health`
   - Should return: `{"status":"healthy"}`

2. **Launch Check**: `https://www.dobbletap.com/api/launch-check`
   - Should show readiness score and system status

3. **Homepage**: `https://www.dobbletap.com`
   - Should load the Dobble Tap landing page

4. **API Status**: `https://www.dobbletap.com/api/status`
   - Should return: `{"status":"OK","message":"Dobble Tap API is running"}`

### Paystack Webhook Configuration:
Set webhook URL in Paystack Dashboard:
```
https://www.dobbletap.com/api/payments/webhook
```

## **STEP 6: Final Verification**

### Critical User Flows to Test:

#### 1. User Registration:
- Go to `https://www.dobbletap.com/sign-up`
- Test email registration
- Verify welcome email is received
- Check user can access dashboard

#### 2. Google OAuth Login:
- Go to `https://www.dobbletap.com/sign-in`
- Click "Continue with Google"
- Verify OAuth flow works
- Check user lands on appropriate dashboard

#### 3. Payment Processing:
- Create a brand account
- Try to create a campaign with minimum budget
- Test payment initialization
- Verify Paystack integration works

#### 4. Creator Features:
- Create a creator account
- Browse available campaigns
- Apply to campaigns
- Test task submission flow

#### 5. Email Notifications:
- Test registration emails
- Test password reset emails
- Test campaign notifications
- Test support ticket emails

### Expected Performance:
Your platform can handle:
- **1,000-2,000 concurrent users**
- **10,000-15,000 daily active users**
- **50,000-100,000 API requests per day**

### Monitoring Commands:
```bash
# Check system health
curl https://www.dobbletap.com/health

# Check launch readiness
curl https://www.dobbletap.com/api/launch-check

# Check API status
curl https://www.dobbletap.com/api/status
```

### Security Features Active:
- ✅ Rate limiting (100 requests/15min)
- ✅ CORS protection for www.dobbletap.com
- ✅ Input sanitization
- ✅ Security headers with Helmet.js
- ✅ Session security with strong secrets
- ✅ Password hashing with bcrypt
- ✅ Payment webhook validation

### Common Issues and Solutions:

**Google OAuth Not Working:**
- Verify callback URL is exactly: `https://www.dobbletap.com/api/auth/google/callback`
- Check Google+ API is enabled
- Ensure using correct project credentials

**Payment Issues:**
- Verify using Live keys (not Test keys)
- Check webhook URL is accessible
- Ensure SSL certificate is valid

**CORS Errors:**
- Verify FRONTEND_URL and DOMAIN_URL are set to `https://www.dobbletap.com`
- Check SSL certificate is properly configured

**Database Connection:**
- DATABASE_URL should be automatically configured in your environment
- Verify database is accessible from your hosting provider

### Success Indicators:
- [ ] `/api/launch-check` shows score above 85
- [ ] All user registration flows work
- [ ] Payment processing completes successfully
- [ ] Email notifications are delivered
- [ ] Google OAuth login works
- [ ] No console errors in browser
- [ ] All pages load within 2 seconds

**Your platform is production-ready for www.dobbletap.com!**

Once you complete Steps 2, 4, and 6, you'll have a fully operational creator monetization platform ready for thousands of users.