import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/currencies";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Play, 
  UserPlus,
  Eye,
  ThumbsUp,
  Repeat2,
  Instagram,
  Twitter,
  Youtube,
  Facebook,
  Music,
  Filter,
  Search,
  Radio,
  Bookmark,
  Quote,
  Bell,
  Home
} from "lucide-react";

const smmActivities = [
  // Instagram tasks
  {
    id: "ig-likes-1",
    platform: "Instagram",
    type: "likes",
    title: "Instagram Likes",
    description: "Like this post and get paid instantly",
    price: 100,
    currency: "NGN",
    postUrl: "https://instagram.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have active Instagram account", "Account must be at least 30 days old"],
    icon: Heart,
    platformIcon: Instagram,
    color: "text-pink-500"
  },
  {
    id: "ig-comment-1",
    platform: "Instagram",
    type: "comment",
    title: "Instagram Comment",
    description: "Comment on this post with engagement",
    price: 250,
    currency: "NGN",
    postUrl: "https://instagram.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have active Instagram account", "Comment must be genuine and relevant"],
    icon: MessageCircle,
    platformIcon: Instagram,
    color: "text-pink-500"
  },
  {
    id: "ig-story-song-1",
    platform: "Instagram",
    type: "story-song",
    title: "Instagram Story with Song",
    description: "Post on story using provided song",
    price: 500,
    currency: "NGN",
    postUrl: "https://instagram.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have active Instagram account", "Story must include provided song"],
    icon: Music,
    platformIcon: Instagram,
    color: "text-pink-500"
  },
  {
    id: "ig-share-story-1",
    platform: "Instagram",
    type: "share-story",
    title: "Share to Instagram Story",
    description: "Share this post to your story",
    price: 300,
    currency: "NGN",
    postUrl: "https://instagram.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have active Instagram account", "Story must be visible for 24 hours"],
    icon: Share2,
    platformIcon: Instagram,
    color: "text-pink-500"
  },
  {
    id: "ig-live-1",
    platform: "Instagram",
    type: "live",
    title: "Instagram Live",
    description: "Go live and mention brand",
    price: 1500,
    currency: "NGN",
    postUrl: "https://instagram.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have active Instagram account", "Live must be at least 5 minutes"],
    icon: Radio,
    platformIcon: Instagram,
    color: "text-pink-500"
  },
  
  // TikTok tasks
  {
    id: "tt-likes-1",
    platform: "TikTok",
    type: "likes",
    title: "TikTok Likes",
    description: "Like this TikTok video",
    price: 100,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Account must be at least 30 days old"],
    icon: Heart,
    platformIcon: Music,
    color: "text-purple-500"
  },
  {
    id: "tt-comment-1",
    platform: "TikTok",
    type: "comment",
    title: "TikTok Comment",
    description: "Comment on this TikTok video",
    price: 200,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Comment must be engaging"],
    icon: MessageCircle,
    platformIcon: Music,
    color: "text-purple-500"
  },
  {
    id: "tt-live-1",
    platform: "TikTok",
    type: "live",
    title: "Join TikTok Live",
    description: "Join and engage in live stream",
    price: 300,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Must engage for at least 5 minutes"],
    icon: Radio,
    platformIcon: Music,
    color: "text-purple-500"
  },
  {
    id: "tt-repost-1",
    platform: "TikTok",
    type: "repost",
    title: "TikTok Repost",
    description: "Repost this TikTok video",
    price: 400,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Repost must stay up for 24 hours"],
    icon: Repeat2,
    platformIcon: Music,
    color: "text-purple-500"
  },
  {
    id: "tt-save-1",
    platform: "TikTok",
    type: "save",
    title: "Save TikTok Video",
    description: "Save this video to your favorites",
    price: 150,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Video must be saved"],
    icon: Bookmark,
    platformIcon: Music,
    color: "text-purple-500"
  },
  {
    id: "tt-share-1",
    platform: "TikTok",
    type: "share",
    title: "Share TikTok Video",
    description: "Share this video with friends",
    price: 200,
    currency: "NGN",
    postUrl: "https://tiktok.com/@example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have TikTok account", "Must share to at least 3 friends"],
    icon: Share2,
    platformIcon: Music,
    color: "text-purple-500"
  },
  
  // Twitter/X tasks
  {
    id: "tw-likes-1",
    platform: "Twitter",
    type: "likes",
    title: "Twitter Likes",
    description: "Like this tweet",
    price: 100,
    currency: "NGN",
    postUrl: "https://twitter.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have Twitter account", "Account must be at least 30 days old"],
    icon: Heart,
    platformIcon: Twitter,
    color: "text-blue-500"
  },
  {
    id: "tw-retweet-1",
    platform: "Twitter",
    type: "retweet",
    title: "Twitter Retweet",
    description: "Retweet this post",
    price: 200,
    currency: "NGN",
    postUrl: "https://twitter.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have Twitter account", "Retweet must stay up for 24 hours"],
    icon: Repeat2,
    platformIcon: Twitter,
    color: "text-blue-500"
  },
  {
    id: "tw-comment-1",
    platform: "Twitter",
    type: "comment",
    title: "Twitter Comment",
    description: "Reply to this tweet",
    price: 250,
    currency: "NGN",
    postUrl: "https://twitter.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have Twitter account", "Reply must be meaningful"],
    icon: MessageCircle,
    platformIcon: Twitter,
    color: "text-blue-500"
  },
  {
    id: "tw-vote-1",
    platform: "Twitter",
    type: "vote",
    title: "Twitter Poll Vote",
    description: "Vote in this Twitter poll",
    price: 150,
    currency: "NGN",
    postUrl: "https://twitter.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have Twitter account", "Must vote in poll"],
    icon: ThumbsUp,
    platformIcon: Twitter,
    color: "text-blue-500"
  },
  {
    id: "tw-quote-1",
    platform: "Twitter",
    type: "quote",
    title: "Quote Tweet",
    description: "Quote tweet with your thoughts",
    price: 400,
    currency: "NGN",
    postUrl: "https://twitter.com/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have Twitter account", "Quote must add value"],
    icon: Quote,
    platformIcon: Twitter,
    color: "text-blue-500"
  },
  
  // YouTube tasks
  {
    id: "yt-like-1",
    platform: "YouTube",
    type: "like",
    title: "YouTube Like",
    description: "Like this YouTube video",
    price: 150,
    currency: "NGN",
    postUrl: "https://youtube.com/watch?v=example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have YouTube account", "Must watch for at least 30 seconds"],
    icon: ThumbsUp,
    platformIcon: Youtube,
    color: "text-red-500"
  },
  {
    id: "yt-subscribe-1",
    platform: "YouTube",
    type: "subscribe",
    title: "YouTube Subscribe",
    description: "Subscribe to this channel",
    price: 300,
    currency: "NGN",
    postUrl: "https://youtube.com/channel/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have YouTube account", "Must stay subscribed for 7 days"],
    icon: Bell,
    platformIcon: Youtube,
    color: "text-red-500"
  },
  {
    id: "yt-comment-1",
    platform: "YouTube",
    type: "comment",
    title: "YouTube Comment",
    description: "Comment on this video",
    price: 250,
    currency: "NGN",
    postUrl: "https://youtube.com/watch?v=example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have YouTube account", "Comment must be constructive"],
    icon: MessageCircle,
    platformIcon: Youtube,
    color: "text-red-500"
  },
  {
    id: "yt-vote-1",
    platform: "YouTube",
    type: "vote",
    title: "YouTube Poll Vote",
    description: "Vote in community poll",
    price: 200,
    currency: "NGN",
    postUrl: "https://youtube.com/channel/example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have YouTube account", "Must vote in poll"],
    icon: ThumbsUp,
    platformIcon: Youtube,
    color: "text-red-500"
  },
  {
    id: "yt-share-1",
    platform: "YouTube",
    type: "share",
    title: "YouTube Share",
    description: "Share this video",
    price: 200,
    currency: "NGN",
    postUrl: "https://youtube.com/watch?v=example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Must have YouTube account", "Must share to social media"],
    icon: Share2,
    platformIcon: Youtube,
    color: "text-red-500"
  },
  {
    id: "yt-view-1",
    platform: "YouTube",
    type: "view",
    title: "YouTube Video View",
    description: "Watch this video for 30 seconds minimum",
    price: 120,
    currency: "NGN",
    postUrl: "https://youtube.com/watch?v=example",
    imageUrl: "/api/placeholder/400/400",
    requirements: ["Watch for minimum 30 seconds", "Must be real engagement"],
    icon: Play,
    platformIcon: Youtube,
    color: "text-red-500"
  }
];

export default function SMMPanel() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("all");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const { user } = useAuth();

  const filteredActivities = smmActivities.filter(activity => {
    const matchesPlatform = selectedPlatform === "all" || activity.platform.toLowerCase() === selectedPlatform;
    const matchesType = selectedType === "all" || activity.type === selectedType;
    const matchesSearch = activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesPlatform && matchesType && matchesSearch;
  });

  const handleCompleteActivity = (activityId: string) => {
    // TODO: Implement activity completion
    console.log("Completing activity:", activityId);
  };

  const getPlatformColor = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "instagram": return "bg-pink-500";
      case "tiktok": return "bg-purple-500";
      case "youtube": return "bg-red-500";
      case "twitter": return "bg-blue-500";
      case "facebook": return "bg-blue-600";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center py-4 lg:py-6 gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 w-full lg:w-auto">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-gray-900 hover:text-blue-600 transition-colors duration-200"
              >
                <h1 className="text-xl sm:text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-gray-300 pl-6 hidden sm:block">
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">SMM Panel Activities</h2>
                <p className="mt-2 text-gray-600 text-sm sm:text-base">
                  Complete social media activities and earn money instantly
                </p>
              </div>
              <div className="sm:hidden">
                <h2 className="text-xl font-bold text-gray-900">SMM Panel Activities</h2>
                <p className="mt-2 text-gray-600 text-sm">
                  Complete social media activities and earn money instantly
                </p>
              </div>
            </div>
            <div className="text-left lg:text-right">
              <p className="text-sm text-gray-500">Available Balance</p>
              <p className="text-xl sm:text-2xl font-bold text-green-600">
                {formatCurrency(0, "NGN")}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm mb-6 p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={selectedPlatform === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPlatform("all")}
              >
                All Platforms
              </Button>
              <Button 
                variant={selectedPlatform === "instagram" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPlatform("instagram")}
              >
                <Instagram className="w-4 h-4 mr-2" />
                Instagram
              </Button>
              <Button 
                variant={selectedPlatform === "tiktok" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPlatform("tiktok")}
              >
                <Music className="w-4 h-4 mr-2" />
                TikTok
              </Button>
              <Button 
                variant={selectedPlatform === "youtube" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPlatform("youtube")}
              >
                <Youtube className="w-4 h-4 mr-2" />
                YouTube
              </Button>
              <Button 
                variant={selectedPlatform === "twitter" ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedPlatform("twitter")}
              >
                <Twitter className="w-4 h-4 mr-2" />
                Twitter
              </Button>
            </div>
          </div>
        </div>

        {/* Activities Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {filteredActivities.map((activity) => {
            const IconComponent = activity.icon;
            const PlatformIcon = activity.platformIcon;
            
            return (
              <Card key={activity.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`p-2 rounded-full ${getPlatformColor(activity.platform)} text-white`}>
                        <PlatformIcon className="w-4 h-4" />
                      </div>
                      <div>
                        <Badge variant="outline" className="text-xs">
                          {activity.platform}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-green-600">
                        {formatCurrency(activity.price, activity.currency)}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg mb-2">{activity.title}</h3>
                    <p className="text-gray-600 text-sm mb-3">{activity.description}</p>
                  </div>

                  <div className="flex items-center space-x-2 text-sm text-gray-500">
                    <IconComponent className={`w-4 h-4 ${activity.color}`} />
                    <span className="capitalize">{activity.type}</span>
                  </div>

                  <Separator />

                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-2">Requirements:</p>
                    <ul className="text-xs text-gray-600 space-y-1">
                      {activity.requirements.map((req, index) => (
                        <li key={index} className="flex items-start">
                          <span className="w-1 h-1 bg-gray-400 rounded-full mt-2 mr-2 flex-shrink-0" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4">
                    <Button 
                      className="w-full"
                      onClick={() => handleCompleteActivity(activity.id)}
                    >
                      Start Activity
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredActivities.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Search className="w-12 h-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No activities found</h3>
            <p className="text-gray-600">Try adjusting your filters or search terms.</p>
          </div>
        )}
      </div>
    </div>
  );
}