import { pgTable, text, serial, uuid, varchar, decimal, timestamp, boolean, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  password: text("password").notNull(),
  phone: varchar("phone", { length: 20 }),
  role: varchar("role", { length: 20 }).notNull().default("creator"),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  location: varchar("location", { length: 255 }),
  // Profile fields
  age: integer("age"),
  gender: varchar("gender", { length: 10 }),
  state: varchar("state", { length: 100 }),
  country: varchar("country", { length: 100 }).default("Nigeria"),
  school: varchar("school", { length: 200 }), // For students
  preferredCurrency: varchar("preferred_currency", { length: 10 }).default("USD"),
  // Social media handles
  instagramHandle: varchar("instagram_handle", { length: 100 }),
  twitterHandle: varchar("twitter_handle", { length: 100 }),
  youtubeHandle: varchar("youtube_handle", { length: 100 }),
  facebookHandle: varchar("facebook_handle", { length: 100 }),
  tiktokHandle: varchar("tiktok_handle", { length: 100 }),
  snapchatHandle: varchar("snapchat_handle", { length: 100 }),
  linkedinHandle: varchar("linkedin_handle", { length: 100 }),
  // Profile completion
  profileCompleted: boolean("profile_completed").default(false),
  verificationStatus: varchar("verification_status", { length: 20 }).notNull().default("pending"),
  emailVerified: boolean("email_verified").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const campaigns = pgTable("campaigns", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description").notNull(),
  budget: decimal("budget", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).notNull().default("USD"),
  type: varchar("type", { length: 20 }).notNull().default("regular"), // "smm" or "regular"
  status: varchar("status", { length: 20 }).notNull().default("draft"),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  targetAudience: json("target_audience"),
  requirements: text("requirements"),
  // Creator selection criteria
  targetCountries: json("target_countries").$type<string[]>(),
  minFollowers: integer("min_followers").default(0),
  maxCreators: integer("max_creators").default(50),
  preferredPlatforms: json("preferred_platforms").$type<string[]>(),
  autoApprove: boolean("auto_approve").default(false),
  // Sound links for social media platforms
  tiktokSoundUrl: text("tiktok_sound_url"),
  instagramSoundUrl: text("instagram_sound_url"),
  youtubeSoundUrl: text("youtube_sound_url"),
  snapchatSoundUrl: text("snapchat_sound_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: uuid("id").primaryKey().defaultRandom(),
  campaignId: uuid("campaign_id").notNull().references(() => campaigns.id),
  title: varchar("title", { length: 255 }).notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  platform: varchar("platform", { length: 50 }).notNull(),
  rewardAmount: decimal("reward_amount", { precision: 8, scale: 2 }).notNull(),
  instructions: text("instructions").notNull(),
  targetUrl: text("target_url"),
  maxCompletions: integer("max_completions").default(1),
  currentCompletions: integer("current_completions").default(0),
  status: varchar("status", { length: 20 }).notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const taskSubmissions = pgTable("task_submissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  taskId: uuid("task_id").notNull().references(() => tasks.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  proofUrl: text("proof_url").notNull(),
  screenshotUrl: text("screenshot_url"),
  notes: text("notes"),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  adminNotes: text("admin_notes"),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).defaultNow(),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
});

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id),
  campaignId: uuid("campaign_id").references(() => campaigns.id),
  taskId: uuid("task_id").references(() => tasks.id),
  reference: varchar("reference", { length: 255 }).unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).notNull().default("NGN"),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  paymentMethod: varchar("payment_method", { length: 50 }).notNull(),
  gatewayResponse: json("gateway_response"),
  metadata: json("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
});

// Campaign Applications - New table for creator applications
export const campaignApplications = pgTable("campaign_applications", {
  id: uuid("id").primaryKey().defaultRandom(),
  campaignId: uuid("campaign_id").notNull().references(() => campaigns.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, approved, rejected
  applicationMessage: text("application_message"),
  brandNotes: text("brand_notes"),
  appliedAt: timestamp("applied_at", { withTimezone: true }).defaultNow(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  read: boolean("read").default(false),
  data: json("data"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const wallets = pgTable("wallets", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().references(() => users.id),
  balance: decimal("balance", { precision: 10, scale: 2 }).notNull().default("0.00"),
  currency: varchar("currency", { length: 10 }).notNull().default("NGN"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const walletTransactions = pgTable("wallet_transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  walletId: uuid("wallet_id").notNull().references(() => wallets.id),
  type: varchar("type", { length: 20 }).notNull(), // "deposit", "withdrawal", "payment", "refund"
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  reference: varchar("reference", { length: 100 }).unique(), // Paystack reference
  status: varchar("status", { length: 20 }).notNull().default("pending"), // "pending", "completed", "failed"
  metadata: json("metadata"), // Store additional transaction details
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  profileCompleted: true,
  verificationStatus: true,
});

export const updateUserProfileSchema = createInsertSchema(users).omit({
  id: true,
  email: true,
  password: true,
  role: true,
  createdAt: true,
  updatedAt: true,
  verificationStatus: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).refine((data) => {
  // Budget validation based on campaign type and currency
  const budgetAmount = parseFloat(data.budget?.toString() || '0');
  const minimumBudgetNGN = data.type === "smm" ? 50000 : 100000;
  
  // Convert minimum budget to selected currency
  const conversionRates: { [key: string]: number } = {
    'USD': 0.0012, 'EUR': 0.0011, 'GBP': 0.0009, 'NGN': 1,
    'GHS': 0.0071, 'KES': 0.15, 'ZAR': 0.021, 'EGP': 0.037,
    'MAD': 0.012, 'ETB': 0.067, 'UGX': 4.4, 'TZS': 2.8,
  };
  
  const conversionRate = conversionRates[data.currency || 'USD'] || 0.0012;
  const minimumBudgetConverted = Math.ceil(minimumBudgetNGN * conversionRate);
  
  return budgetAmount >= minimumBudgetConverted;
}, {
  message: "Budget is below minimum required amount",
  path: ["budget"]
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTaskSubmissionSchema = createInsertSchema(taskSubmissions).omit({
  id: true,
  submittedAt: true,
  verifiedAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  verifiedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

// Types
export const insertCampaignApplicationSchema = createInsertSchema(campaignApplications).omit({
  id: true,
  appliedAt: true,
  reviewedAt: true,
}).extend({
  applicationMessage: z.string().optional(),
});

export const insertWalletSchema = createInsertSchema(wallets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertWalletTransactionSchema = createInsertSchema(walletTransactions).omit({
  id: true,
  createdAt: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type TaskSubmission = typeof taskSubmissions.$inferSelect;
export type InsertTaskSubmission = z.infer<typeof insertTaskSubmissionSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type CampaignApplication = typeof campaignApplications.$inferSelect;
export type InsertCampaignApplication = z.infer<typeof insertCampaignApplicationSchema>;
export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type WalletTransaction = typeof walletTransactions.$inferSelect;
export type InsertWalletTransaction = z.infer<typeof insertWalletTransactionSchema>;
