import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, Search, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
              <Search className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-white">404 - Page Not Found</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-400">
              The page you're looking for doesn't exist or has been moved.
            </p>
            
            <div className="space-y-2">
              <Button
                onClick={() => setLocation("/")}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                <Home className="w-4 h-4 mr-2" />
                Go to Home
              </Button>
              
              <Button
                onClick={() => window.history.back()}
                variant="outline"
                className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Go Back
              </Button>
            </div>

            <div className="text-sm text-gray-500 pt-4">
              <p>Need help? <a href="/help" className="text-blue-400 hover:text-blue-300">Contact Support</a></p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}