export interface StateData {
  [countryCode: string]: string[];
}

export const statesByCountry: StateData = {
  NG: [ // Nigeria
    "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno", 
    "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "Gombe", "Imo", 
    "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos", 
    "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", 
    "Sokoto", "Taraba", "Yobe", "Zamfara", "FCT"
  ],
  GH: [ // Ghana
    "Ashanti", "Brong-Ahafo", "Central", "Eastern", "Greater Accra", "Northern", 
    "Upper East", "Upper West", "Volta", "Western"
  ],
  KE: [ // Kenya
    "Baringo", "Bomet", "Bungoma", "Busia", "Elgeyo-Marakwet", "Embu", "Garissa", 
    "Homa Bay", "Isiolo", "Kajiado", "Kakamega", "Kericho", "Kiambu", "Kilifi", 
    "Kirinyaga", "Kisii", "Kisumu", "Kitui", "Kwale", "Laikipia", "Lamu", "Machakos", 
    "Makueni", "Mandera", "Marsabit", "Meru", "Migori", "Mombasa", "Murang'a", 
    "Nairobi", "Nakuru", "Nandi", "Narok", "Nyamira", "Nyandarua", "Nyeri", 
    "Samburu", "Siaya", "Taita-Taveta", "Tana River", "Tharaka-Nithi", "Trans Nzoia", 
    "Turkana", "Uasin Gishu", "Vihiga", "Wajir", "West Pokot"
  ],
  ZA: [ // South Africa
    "Eastern Cape", "Free State", "Gauteng", "KwaZulu-Natal", "Limpopo", 
    "Mpumalanga", "Northern Cape", "North West", "Western Cape"
  ],
  UG: [ // Uganda
    "Abim", "Adjumani", "Amolatar", "Amuria", "Amuru", "Apac", "Arua", "Budaka", 
    "Bududa", "Bugiri", "Buhweju", "Buikwe", "Bukedea", "Bukomansimbi", "Bukwo", 
    "Bulambuli", "Buliisa", "Bundibugyo", "Bushenyi", "Busia", "Butaleja", "Butambala", 
    "Buvuma", "Buyende", "Central", "Eastern", "Northern", "Western"
  ],
  EG: [ // Egypt
    "Alexandria", "Aswan", "Asyut", "Beheira", "Beni Suef", "Cairo", "Dakahlia", 
    "Damietta", "Faiyum", "Gharbia", "Giza", "Ismailia", "Kafr el-Sheikh", "Luxor", 
    "Matruh", "Minya", "Monufia", "New Valley", "North Sinai", "Port Said", 
    "Qalyubia", "Qena", "Red Sea", "Sharqia", "Sohag", "South Sinai", "Suez"
  ],
  MA: [ // Morocco
    "Beni Mellal-Khénifra", "Casablanca-Settat", "Drâa-Tafilalet", "Fès-Meknès", 
    "Guelmim-Oued Noun", "Laâyoune-Sakia El Hamra", "Marrakech-Safi", "Oriental", 
    "Rabat-Salé-Kénitra", "Souss-Massa", "Tanger-Tétouan-Al Hoceïma", "Dakhla-Oued Ed-Dahab"
  ],
  ET: [ // Ethiopia
    "Addis Ababa", "Afar", "Amhara", "Benishangul-Gumuz", "Dire Dawa", "Gambela", 
    "Harari", "Oromia", "Somali", "Southern Nations", "Tigray"
  ],
  TZ: [ // Tanzania
    "Arusha", "Dar es Salaam", "Dodoma", "Geita", "Iringa", "Kagera", "Katavi", 
    "Kigoma", "Kilimanjaro", "Lindi", "Manyara", "Mara", "Mbeya", "Morogoro", 
    "Mtwara", "Mwanza", "Njombe", "Pemba North", "Pemba South", "Pwani", "Rukwa", 
    "Ruvuma", "Shinyanga", "Simiyu", "Singida", "Songwe", "Tabora", "Tanga", 
    "Unguja North", "Unguja South"
  ],
  // Add more countries as needed
  US: [ // United States
    "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", 
    "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", 
    "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", 
    "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", 
    "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", 
    "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", 
    "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", 
    "Wisconsin", "Wyoming"
  ],
  GB: [ // United Kingdom
    "England", "Scotland", "Wales", "Northern Ireland"
  ],
  CA: [ // Canada
    "Alberta", "British Columbia", "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Northwest Territories", "Nova Scotia", "Nunavut", "Ontario", "Prince Edward Island", 
    "Quebec", "Saskatchewan", "Yukon"
  ]
};

export const getStatesByCountry = (countryCode: string): string[] => {
  return statesByCountry[countryCode] || [];
};

export const hasStates = (countryCode: string): boolean => {
  return countryCode in statesByCountry;
};