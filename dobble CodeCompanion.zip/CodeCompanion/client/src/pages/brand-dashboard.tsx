import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { currencies, formatBudget, getCurrencyByCode } from "@/lib/currencies";
import WalletCard from "@/components/wallet-card";
import { 
  Plus, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Eye, 
  MousePointer, 
  Target,
  Calendar,
  Settings,
  Edit,
  MoreHorizontal,
  Save,
  FileText,
  Search,
  Music,
  Trash2,
  Link,
  Zap,
  Home,
  HelpCircle,
  User
} from "lucide-react";

const campaignSchema = z.object({
  name: z.string().min(1, "Campaign name is required"),
  description: z.string().min(1, "Description is required"),
  budget: z.string().min(1, "Budget is required"),
  currency: z.string().min(1, "Currency is required"),
  type: z.enum(["smm", "regular"]).default("regular"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  targetAudience: z.string().optional(),
  requirements: z.string().optional(),
  tiktokSoundUrl: z.string().optional(),
  instagramSoundUrl: z.string().optional(),
  youtubeSoundUrl: z.string().optional(),
  snapchatSoundUrl: z.string().optional(),
  status: z.enum(["draft", "active", "paused", "completed"]).optional()
});

type CampaignForm = z.infer<typeof campaignSchema>;

export default function BrandDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<any>(null);
  const [currencySearch, setCurrencySearch] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch campaigns
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ["/api/campaigns"],
    retry: 1
  });

  // Fetch dashboard stats
  const { data: stats = { 
    activeCampaigns: 0, 
    totalSpent: 0, 
    totalReach: 0, 
    avgEngagement: 0 
  } } = useQuery({
    queryKey: ["/api/dashboard/brand-stats"],
    retry: 1
  });

  // Create campaign mutation
  const createCampaignMutation = useMutation({
    mutationFn: (data: CampaignForm) => apiRequest("/api/campaigns", {
      method: "POST",
      data: data
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/brand-stats"] });
      setIsCreateDialogOpen(false);
      toast({
        title: "Campaign created successfully",
        description: "Your campaign is now ready to launch."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating campaign",
        description: error.message || "Something went wrong"
      });
    }
  });

  // Update campaign mutation
  const updateCampaignMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<CampaignForm> }) => 
      apiRequest(`/api/campaigns/${id}`, {
        method: "PUT",
        data: data
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/brand-stats"] });
      setEditingCampaign(null);
      toast({
        title: "Campaign updated successfully",
        description: "Your changes have been saved."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating campaign",
        description: error.message || "Something went wrong"
      });
    }
  });

  const getMinimumBudgetDisplay = (type: string, currency: string) => {
    const minimumBudgetNGN = type === "smm" ? 50000 : 100000;
    const selectedCurrency = getCurrencyByCode(currency);
    
    if (!selectedCurrency) return "₦50,000";
    
    const conversionRates: { [key: string]: number } = {
      'USD': 0.0012, 'EUR': 0.0011, 'GBP': 0.0009, 'NGN': 1,
      'GHS': 0.0071, 'KES': 0.15, 'ZAR': 0.021, 'EGP': 0.037,
      'MAD': 0.012, 'ETB': 0.067, 'UGX': 4.4, 'TZS': 2.8,
    };
    
    const conversionRate = conversionRates[currency] || 0.0012;
    const minimumBudgetConverted = Math.ceil(minimumBudgetNGN * conversionRate);
    
    return `${selectedCurrency.symbol}${minimumBudgetConverted.toLocaleString()}`;
  };

  const form = useForm<CampaignForm>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      name: "",
      description: "",
      budget: "",
      currency: "USD",
      type: "regular",
      startDate: "",
      endDate: "",
      targetAudience: "",
      requirements: "",
      tiktokSoundUrl: "",
      instagramSoundUrl: "",
      youtubeSoundUrl: "",
      snapchatSoundUrl: "",
      status: "draft"
    }
  });

  const onSubmit = (data: CampaignForm) => {
    // Budget validation based on campaign type and currency
    const budgetAmount = parseFloat(data.budget.replace(/[^\d.]/g, ''));
    const selectedCurrency = getCurrencyByCode(data.currency);
    const minimumBudgetNGN = data.type === "smm" ? 50000 : 100000;
    
    if (!selectedCurrency) {
      toast({
        title: "Invalid currency",
        description: "Please select a valid currency.",
        variant: "destructive",
      });
      return;
    }
    
    // Convert minimum budget to selected currency (rough conversion based on typical rates)
    const conversionRates: { [key: string]: number } = {
      'USD': 0.0012, // 1 NGN = 0.0012 USD
      'EUR': 0.0011, // 1 NGN = 0.0011 EUR
      'GBP': 0.0009, // 1 NGN = 0.0009 GBP
      'NGN': 1,      // 1 NGN = 1 NGN
      'GHS': 0.0071, // 1 NGN = 0.0071 GHS
      'KES': 0.15,   // 1 NGN = 0.15 KES
      'ZAR': 0.021,  // 1 NGN = 0.021 ZAR
      'EGP': 0.037,  // 1 NGN = 0.037 EGP
      'MAD': 0.012,  // 1 NGN = 0.012 MAD
      'ETB': 0.067,  // 1 NGN = 0.067 ETB
      'UGX': 4.4,    // 1 NGN = 4.4 UGX
      'TZS': 2.8,    // 1 NGN = 2.8 TZS
    };
    
    const conversionRate = conversionRates[data.currency] || 0.0012;
    const minimumBudgetConverted = Math.ceil(minimumBudgetNGN * conversionRate);
    
    if (budgetAmount < minimumBudgetConverted) {
      toast({
        title: "Budget too low",
        description: `Minimum budget for ${data.type === "smm" ? "SMM panel activities" : "regular campaigns"} is ${selectedCurrency.symbol}${minimumBudgetConverted.toLocaleString()}`,
        variant: "destructive",
      });
      return;
    }
    
    if (editingCampaign) {
      updateCampaignMutation.mutate({ id: editingCampaign.id, data });
    } else {
      createCampaignMutation.mutate(data);
    }
  };

  const handleCreateCampaign = () => {
    form.reset();
    setEditingCampaign(null);
    setIsCreateDialogOpen(true);
  }

  const handleHelp = () => {
    window.location.href = "/help";
  };

  const handleViewProfile = () => {
    window.location.href = "/profile";
  };;

  const handleEditCampaign = (campaign: any) => {
    form.reset({
      name: campaign.name,
      description: campaign.description,
      budget: campaign.budget?.toString() || "",
      currency: campaign.currency || "USD",
      type: campaign.type || "regular",
      startDate: campaign.startDate ? new Date(campaign.startDate).toISOString().split('T')[0] : "",
      endDate: campaign.endDate ? new Date(campaign.endDate).toISOString().split('T')[0] : "",
      targetAudience: campaign.targetAudience || "",
      requirements: campaign.requirements || "",
      tiktokSoundUrl: campaign.tiktokSoundUrl || "",
      instagramSoundUrl: campaign.instagramSoundUrl || "",
      youtubeSoundUrl: campaign.youtubeSoundUrl || "",
      snapchatSoundUrl: campaign.snapchatSoundUrl || "",
      status: campaign.status
    });
    setEditingCampaign(campaign);
    setIsCreateDialogOpen(true);
  };

  const saveDraft = () => {
    const formData = form.getValues();
    const draftData = { ...formData, status: "draft" };
    
    if (editingCampaign) {
      updateCampaignMutation.mutate({ id: editingCampaign.id, data: draftData });
    } else {
      createCampaignMutation.mutate(draftData);
    }
  };

  const deleteCampaign = async (campaignId: string) => {
    try {
      await apiRequest(`/api/campaigns/${campaignId}`, {
        method: "DELETE"
      });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({
        title: "Campaign deleted",
        description: "The campaign has been successfully deleted."
      });
    } catch (error) {
      toast({
        title: "Error deleting campaign",
        description: "Failed to delete the campaign. Please try again.",
        variant: "destructive"
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (campaignsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-black shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center py-4 lg:py-6 gap-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 w-full lg:w-auto">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white hover:text-blue-400 transition-colors duration-200"
              >
                <h1 className="text-xl sm:text-2xl font-bold">Dobble Tap</h1>
              </button>
              <div className="border-l border-white/30 pl-6 hidden sm:block">
                <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">Brand Dashboard</h2>
                <p className="text-gray-300 mt-1 text-sm sm:text-base">Manage your campaigns and track performance</p>
              </div>
              <div className="sm:hidden">
                <h2 className="text-xl font-bold text-white tracking-tight">Brand Dashboard</h2>
                <p className="text-gray-300 mt-1 text-sm">Manage your campaigns and track performance</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <Button 
                onClick={handleHelp}
                className="bg-gray-600 text-white hover:bg-gray-700 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
              >
                <HelpCircle className="w-4 h-4 mr-2" />
                Help
              </Button>
              <Button 
                onClick={handleViewProfile}
                className="bg-gray-800 text-white hover:bg-gray-900 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
              >
                <User className="w-4 h-4 mr-2" />
                Profile
              </Button>
              <Button 
                onClick={handleCreateCampaign}
                className="bg-blue-600 text-white hover:bg-blue-700 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Campaign
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 bg-white shadow-xl border-2 border-gray-200 h-12 sm:h-14 rounded-2xl">
            <TabsTrigger value="overview" className="data-[state=active]:bg-black data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Overview</TabsTrigger>
            <TabsTrigger value="wallet" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Wallet</TabsTrigger>
            <TabsTrigger value="campaigns" className="data-[state=active]:bg-black data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Campaigns</TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-semibold rounded-xl transition-all duration-300 hover:scale-105">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-8">
            {/* Stats Cards */}
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8 mb-8">
              <div className="flex items-center mb-6">
                <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                <h2 className="text-2xl font-bold text-black">Dashboard Overview</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Active Campaigns</p>
                        <p className="text-3xl font-bold text-black">{stats.activeCampaigns}</p>
                      </div>
                      <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Target className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Total Spent</p>
                        <p className="text-3xl font-bold text-black">{formatCurrency(stats.totalSpent)}</p>
                      </div>
                      <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <DollarSign className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Total Reach</p>
                        <p className="text-3xl font-bold text-black">{(stats.totalReach / 1000000).toFixed(1)}M</p>
                      </div>
                      <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <Eye className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 border-gray-200 shadow-xl bg-white hover:shadow-2xl hover:scale-105 transition-all duration-300 group hover:border-blue-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 mb-2">Avg Engagement</p>
                        <p className="text-3xl font-bold text-black">{stats.avgEngagement}%</p>
                      </div>
                      <div className="w-14 h-14 bg-black rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                        <TrendingUp className="w-7 h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Recent Campaigns */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5" />
                  <span>Recent Campaigns</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {campaigns.slice(0, 3).map((campaign: any) => (
                    <div key={campaign.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="font-semibold text-gray-900">{campaign.name}</h3>
                          <Badge className={getStatusColor(campaign.status)}>
                            {campaign.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{campaign.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Budget: {formatCurrency(campaign.budget || 0)}</span>
                          <span>Created: {new Date(campaign.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setActiveTab("campaigns")}
                        >
                          View Details
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleEditCampaign(campaign)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {campaigns.length === 0 && (
                    <div className="text-center py-8">
                      <p className="text-gray-500">No campaigns created yet.</p>
                      <Button 
                        onClick={handleCreateCampaign}
                        className="mt-2 bg-blue-600 text-white hover:bg-blue-700 shadow-lg"
                      >
                        Create Your First Campaign
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wallet" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex items-center mb-6">
                <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                <h2 className="text-2xl font-bold text-black">Wallet Management</h2>
              </div>
              <WalletCard />
            </div>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center">
                  <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                  <h2 className="text-2xl font-bold text-black">All Campaigns</h2>
                </div>
                <Button 
                  onClick={handleCreateCampaign}
                  className="bg-blue-600 text-white hover:bg-blue-700 shadow-lg transform hover:scale-105 transition-all duration-200 font-semibold"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Campaign
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {campaigns.map((campaign: any) => (
                  <Card key={campaign.id} className="hover:shadow-2xl transition-all duration-300 border-2 border-gray-200 shadow-xl bg-white hover:scale-105 group hover:border-blue-300">
                    <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{campaign.name}</CardTitle>
                      <Badge className={getStatusColor(campaign.status)}>
                        {campaign.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{campaign.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span>Budget:</span>
                        <span className="font-semibold">{formatBudget(campaign.budget?.toString() || "0", campaign.currency || "NGN")}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Created:</span>
                        <span>{new Date(campaign.createdAt).toLocaleDateString()}</span>
                      </div>
                      {campaign.startDate && (
                        <div className="flex justify-between text-sm">
                          <span>Start Date:</span>
                          <span>{new Date(campaign.startDate).toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEditCampaign(campaign)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Manage
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
              </div>
            </div>

            {campaigns.length === 0 && (
              <div className="text-center py-12">
                <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No campaigns yet</h3>
                <p className="text-gray-600 mb-4">Create your first campaign to start reaching creators</p>
                <Button 
                  onClick={handleCreateCampaign}
                  className="bg-blue-600 text-white hover:bg-blue-700 shadow-lg"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Campaign
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="analytics" className="space-y-8">
            <div className="bg-white rounded-3xl shadow-2xl border-2 border-gray-200 p-8">
              <div className="flex items-center mb-6">
                <div className="w-3 h-8 bg-blue-600 rounded-full mr-4"></div>
                <h2 className="text-2xl font-bold text-black">Campaign Analytics</h2>
              </div>
              <Card className="border-2 border-gray-200 shadow-xl bg-white">
                <CardHeader>
                  <CardTitle className="text-xl text-black">Campaign Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                      <TrendingUp className="w-8 h-8 text-white" />
                    </div>
                    <p className="text-gray-600 text-lg">Analytics will appear here once you have active campaigns</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Create/Edit Campaign Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto" aria-describedby="campaign-dialog-description">
          <DialogHeader>
            <DialogTitle>
              {editingCampaign ? "Edit Campaign" : "Create New Campaign"}
            </DialogTitle>
            <div id="campaign-dialog-description" className="text-sm text-gray-600">
              {editingCampaign ? "Update your campaign details" : "Create a new campaign to connect with creators"}
            </div>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Campaign Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter campaign name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Campaign Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select campaign type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="regular">Regular Campaign</SelectItem>
                          <SelectItem value="smm">SMM Panel Activities</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <div className="flex items-center px-3 py-2 border-b">
                            <Search className="w-4 h-4 mr-2 text-gray-500" />
                            <Input
                              placeholder="Search currencies..."
                              value={currencySearch}
                              onChange={(e) => setCurrencySearch(e.target.value)}
                              className="border-0 p-0 h-6 focus:ring-0"
                            />
                          </div>
                          {currencies
                            .filter(currency => 
                              currency.name.toLowerCase().includes(currencySearch.toLowerCase()) ||
                              currency.code.toLowerCase().includes(currencySearch.toLowerCase()) ||
                              currency.country.toLowerCase().includes(currencySearch.toLowerCase())
                            )
                            .map(currency => (
                              <SelectItem key={currency.code} value={currency.code}>
                                {currency.symbol} {currency.code} - {currency.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>
                      Budget
                      {form.watch("currency") && (
                        <span className="text-sm text-gray-500 ml-2">
                          (Min: {getMinimumBudgetDisplay(form.watch("type"), form.watch("currency"))})
                        </span>
                      )}
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="Enter budget amount" 
                        {...field}
                        onChange={(e) => {
                          const value = e.target.value.replace(/[^\d.]/g, "");
                          field.onChange(value); // Store raw value for validation
                        }}
                        value={field.value ? parseFloat(field.value || 0).toLocaleString() : ""}
                        onFocus={(e) => {
                          // Show raw value when focused for easier editing
                          e.target.value = field.value || "";
                        }}
                        onBlur={(e) => {
                          // Format with commas when not focused
                          const numericValue = parseFloat(e.target.value || 0);
                          e.target.value = numericValue.toLocaleString();
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Describe your campaign..."
                        rows={3}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="targetAudience"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Audience</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Young adults 18-25 in Nigeria" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="requirements"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Requirements</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="List any specific requirements for creators..."
                        rows={2}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Sound Links Section */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Music className="w-5 h-5 text-blue-500" />
                  <h3 className="text-lg font-semibold">Sound Links</h3>
                  <span className="text-sm text-gray-500">(Optional)</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="tiktokSoundUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center space-x-2">
                          <span>TikTok Sound</span>
                          <Link className="w-4 h-4 text-gray-400" />
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://tiktok.com/sound/..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="instagramSoundUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center space-x-2">
                          <span>Instagram Sound</span>
                          <Link className="w-4 h-4 text-gray-400" />
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://instagram.com/reel/..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="youtubeSoundUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center space-x-2">
                          <span>YouTube Sound</span>
                          <Link className="w-4 h-4 text-gray-400" />
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://youtube.com/watch?v=..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="snapchatSoundUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center space-x-2">
                          <span>Snapchat Sound</span>
                          <Link className="w-4 h-4 text-gray-400" />
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://snapchat.com/..."
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={saveDraft}
                  disabled={createCampaignMutation.isPending || updateCampaignMutation.isPending}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Save as Draft
                </Button>
                <Button
                  type="submit"
                  disabled={createCampaignMutation.isPending || updateCampaignMutation.isPending}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {editingCampaign ? "Update Campaign" : "Create Campaign"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}