export interface PaystackConfig {
  publicKey: string;
  secretKey: string;
}

export interface PaymentData {
  amount: number;
  email: string;
  reference?: string;
  currency?: string;
  metadata?: any;
}

export interface PaymentResponse {
  status: boolean;
  message: string;
  data?: any;
}

export class PaystackService {
  private publicKey: string;
  private secretKey: string;

  constructor() {
    this.publicKey = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY || '';
    this.secretKey = import.meta.env.VITE_PAYSTACK_SECRET_KEY || '';
  }

  async initializePayment(data: PaymentData): Promise<PaymentResponse> {
    try {
      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.secretKey}`,
        },
        body: JSON.stringify({
          amount: data.amount * 100, // Convert to kobo
          email: data.email,
          reference: data.reference,
          currency: data.currency || 'NGN',
          metadata: data.metadata,
        }),
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Paystack initialization error:', error);
      throw error;
    }
  }

  async verifyPayment(reference: string): Promise<PaymentResponse> {
    try {
      const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.secretKey}`,
        },
      });

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Paystack verification error:', error);
      throw error;
    }
  }

  generateReference(): string {
    const timestamp = Date.now().toString();
    const random = Math.random().toString(36).substring(2, 8);
    return `dt_${timestamp}_${random}`;
  }

  openPaymentModal(data: PaymentData, onSuccess: (response: any) => void, onClose: () => void) {
    const script = document.createElement('script');
    script.src = 'https://js.paystack.co/v1/inline.js';
    script.onload = () => {
      // @ts-ignore
      const handler = PaystackPop.setup({
        key: this.publicKey,
        email: data.email,
        amount: data.amount * 100, // Convert to kobo
        ref: data.reference || this.generateReference(),
        currency: data.currency || 'NGN',
        metadata: data.metadata,
        callback: onSuccess,
        onClose: onClose,
      });
      handler.openIframe();
    };
    document.head.appendChild(script);
  }
}

export const paystackService = new PaystackService();
