import { Users, Building, ShieldCheck, CheckCircle } from "lucide-react";
import africanBrands from "@/assets/african-brands.svg";

export default function PlatformFeatures() {
  const features = [
    {
      icon: Users,
      title: "For Creators",
      description: "Complete engaging tasks, build your audience, and earn money doing what you love.",
      benefits: [
        "Browse available campaigns",
        "Complete tasks & submit proof",
        "Get paid instantly"
      ],
      bgColor: "bg-white",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600"
    },
    {
      icon: Building,
      title: "For Brands",
      description: "Launch targeted campaigns, reach authentic audiences, and measure real impact.",
      benefits: [
        "Create targeted campaigns",
        "Connect with verified creators",
        "Track performance analytics"
      ],
      bgColor: "bg-white",
      iconBg: "bg-gray-100",
      iconColor: "text-black"
    },
    {
      icon: ShieldCheck,
      title: "Secure & Trusted",
      description: "Built with security and trust at its core, ensuring safe transactions and authentic connections.",
      benefits: [
        "Verified creator profiles",
        "Secure payment processing",
        "24/7 support"
      ],
      bgColor: "bg-white",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600"
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-poppins font-bold text-3xl md:text-4xl text-black mb-4">
            How Dobble Tap Works
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            A seamless platform connecting creators and brands for authentic, impactful campaigns across Africa.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className={`${feature.bgColor} rounded-xl p-8 text-center border-2 border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 hover:border-blue-300`}>
              <div className={`w-16 h-16 ${feature.iconBg} rounded-full flex items-center justify-center mx-auto mb-6`}>
                <feature.icon className={`w-8 h-8 ${feature.iconColor}`} />
              </div>
              <h3 className="font-poppins font-semibold text-xl text-black mb-4">{feature.title}</h3>
              <p className="text-gray-700 mb-6">{feature.description}</p>
              <div className="space-y-3">
                {feature.benefits.map((benefit, benefitIndex) => (
                  <div key={benefitIndex} className="flex items-center justify-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                    <span className="text-sm text-gray-700">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
