import { QueryClient } from '@tanstack/react-query';

const BASE_URL = '';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

export async function apiRequest(
  url: string,
  method: string = 'GET',
  data?: any,
  requiresAuth: boolean = true
) {
  const token = requiresAuth ? localStorage.getItem('token') : null;
  
  const config: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` }),
    },
  };

  if (data && method !== 'GET') {
    config.body = JSON.stringify(data);
  }

  const response = await fetch(`${BASE_URL}${url}`, config);
  
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    
    // Handle unauthorized responses
    if (response.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
      return;
    }
    
    throw new Error(`${response.status}: ${errorData.message || response.statusText}`);
  }

  return await response.json();
}

// Set up the default query function
queryClient.setQueryDefaults(['*'], {
  queryFn: async ({ queryKey }) => {
    const [url] = queryKey as [string];
    return apiRequest(url, 'GET');
  },
});