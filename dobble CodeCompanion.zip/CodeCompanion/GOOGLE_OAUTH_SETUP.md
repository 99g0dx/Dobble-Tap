# Google OAuth Setup for Dobble Tap

## Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Click "Select a project" dropdown at the top
3. Click "New Project"
4. Enter project name: "Dobble Tap Production"
5. Click "Create"

## Step 2: Enable Google+ API

1. In the left sidebar, click "APIs & Services" → "Library"
2. In the search box, type "Google+ API"
3. Click on "Google+ API" from the results
4. Click "Enable" button

## Step 3: Create OAuth 2.0 Credentials

1. In the left sidebar, click "APIs & Services" → "Credentials"
2. Click "Create Credentials" → "OAuth 2.0 Client ID"
3. If prompted, configure OAuth consent screen:
   - Choose "External"
   - Fill in app name: "Dobble Tap"
   - User support email: your email
   - Developer contact: your email
   - Click "Save and Continue"
4. Back to credentials creation:
   - Application type: "Web application"
   - Name: "Dobble Tap Production"
   - Authorized JavaScript origins: 
     - `https://www.dobbletap.com`
   - Authorized redirect URIs:
     - `https://www.dobbletap.com/api/auth/google/callback`
5. Click "Create"

## Step 4: Copy Your Credentials

You'll see a popup with:
- Client ID: looks like `123456789-abcdefghijk.apps.googleusercontent.com`
- Client Secret: looks like `GOCSPX-abcdefghijklmnop`

## Step 5: Add to Environment Variables

In your hosting provider's environment variables section, add:
```
GOOGLE_CLIENT_ID=123456789-abcdefghijk.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-abcdefghijklmnop
```

Replace with your actual credentials from Step 4.

## Troubleshooting

If you get "OAuth consent screen not configured":
1. Go to "APIs & Services" → "OAuth consent screen"
2. Choose "External" user type
3. Fill in required fields:
   - App name: "Dobble Tap"
   - User support email: your email
   - Developer contact: your email
4. Save and continue through all steps
5. Go back to creating credentials