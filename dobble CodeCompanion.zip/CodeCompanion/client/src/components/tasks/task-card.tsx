import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Users, DollarSign, Instagram, Twitter, Youtube } from "lucide-react";
import { Task } from "@/types";
import { Link } from "wouter";

interface TaskCardProps {
  task: Task;
  showApplyButton?: boolean;
}

export function TaskCard({ task, showApplyButton = false }: TaskCardProps) {
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram': return <Instagram className="w-5 h-5 text-pink-500" />;
      case 'twitter': return <Twitter className="w-5 h-5 text-blue-500" />;
      case 'youtube': return <Youtube className="w-5 h-5 text-red-500" />;
      default: return <div className="w-5 h-5 bg-gray-500 rounded" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              {getPlatformIcon(task.platform)}
            </div>
            <div>
              <CardTitle className="text-lg">{task.title}</CardTitle>
              <p className="text-sm text-muted-foreground capitalize">{task.platform} • {task.type}</p>
            </div>
          </div>
          <Badge className={getStatusColor(task.status)}>
            {task.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
          {task.instructions}
        </p>
        
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
          <div className="flex items-center">
            <Users className="w-4 h-4 mr-1" />
            {task.currentCompletions}/{task.maxCompletions} spots filled
          </div>
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            Active
          </div>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <DollarSign className="w-4 h-4 mr-1" />
            <span className="text-lg font-bold text-primary">
              ₦{Number(task.rewardAmount).toLocaleString()}
            </span>
          </div>
          
          {showApplyButton && (
            <Link href={`/tasks/${task.id}/apply`}>
              <Button size="sm" className="btn-primary">
                Apply Now
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
