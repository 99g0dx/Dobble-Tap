export interface Country {
  code: string;
  name: string;
  continent: string;
}

export const countries: Country[] = [
  // Africa
  { code: "DZ", name: "Algeria", continent: "Africa" },
  { code: "AO", name: "Angola", continent: "Africa" },
  { code: "BJ", name: "Benin", continent: "Africa" },
  { code: "BW", name: "Botswana", continent: "Africa" },
  { code: "BF", name: "Burkina Faso", continent: "Africa" },
  { code: "BI", name: "Burundi", continent: "Africa" },
  { code: "CV", name: "Cape Verde", continent: "Africa" },
  { code: "CM", name: "Cameroon", continent: "Africa" },
  { code: "CF", name: "Central African Republic", continent: "Africa" },
  { code: "TD", name: "Chad", continent: "Africa" },
  { code: "KM", name: "Comoros", continent: "Africa" },
  { code: "CG", name: "Congo", continent: "Africa" },
  { code: "CD", name: "Democratic Republic of the Congo", continent: "Africa" },
  { code: "DJ", name: "Djibouti", continent: "Africa" },
  { code: "EG", name: "Egypt", continent: "Africa" },
  { code: "GQ", name: "Equatorial Guinea", continent: "Africa" },
  { code: "ER", name: "Eritrea", continent: "Africa" },
  { code: "SZ", name: "Eswatini", continent: "Africa" },
  { code: "ET", name: "Ethiopia", continent: "Africa" },
  { code: "GA", name: "Gabon", continent: "Africa" },
  { code: "GM", name: "Gambia", continent: "Africa" },
  { code: "GH", name: "Ghana", continent: "Africa" },
  { code: "GN", name: "Guinea", continent: "Africa" },
  { code: "GW", name: "Guinea-Bissau", continent: "Africa" },
  { code: "CI", name: "Ivory Coast", continent: "Africa" },
  { code: "KE", name: "Kenya", continent: "Africa" },
  { code: "LS", name: "Lesotho", continent: "Africa" },
  { code: "LR", name: "Liberia", continent: "Africa" },
  { code: "LY", name: "Libya", continent: "Africa" },
  { code: "MG", name: "Madagascar", continent: "Africa" },
  { code: "MW", name: "Malawi", continent: "Africa" },
  { code: "ML", name: "Mali", continent: "Africa" },
  { code: "MR", name: "Mauritania", continent: "Africa" },
  { code: "MU", name: "Mauritius", continent: "Africa" },
  { code: "MA", name: "Morocco", continent: "Africa" },
  { code: "MZ", name: "Mozambique", continent: "Africa" },
  { code: "NA", name: "Namibia", continent: "Africa" },
  { code: "NE", name: "Niger", continent: "Africa" },
  { code: "NG", name: "Nigeria", continent: "Africa" },
  { code: "RW", name: "Rwanda", continent: "Africa" },
  { code: "ST", name: "Sao Tome and Principe", continent: "Africa" },
  { code: "SN", name: "Senegal", continent: "Africa" },
  { code: "SC", name: "Seychelles", continent: "Africa" },
  { code: "SL", name: "Sierra Leone", continent: "Africa" },
  { code: "SO", name: "Somalia", continent: "Africa" },
  { code: "ZA", name: "South Africa", continent: "Africa" },
  { code: "SS", name: "South Sudan", continent: "Africa" },
  { code: "SD", name: "Sudan", continent: "Africa" },
  { code: "TZ", name: "Tanzania", continent: "Africa" },
  { code: "TG", name: "Togo", continent: "Africa" },
  { code: "TN", name: "Tunisia", continent: "Africa" },
  { code: "UG", name: "Uganda", continent: "Africa" },
  { code: "ZM", name: "Zambia", continent: "Africa" },
  { code: "ZW", name: "Zimbabwe", continent: "Africa" },
  
  // Other continents (popular countries)
  { code: "US", name: "United States", continent: "North America" },
  { code: "CA", name: "Canada", continent: "North America" },
  { code: "GB", name: "United Kingdom", continent: "Europe" },
  { code: "DE", name: "Germany", continent: "Europe" },
  { code: "FR", name: "France", continent: "Europe" },
  { code: "IT", name: "Italy", continent: "Europe" },
  { code: "ES", name: "Spain", continent: "Europe" },
  { code: "BR", name: "Brazil", continent: "South America" },
  { code: "AR", name: "Argentina", continent: "South America" },
  { code: "IN", name: "India", continent: "Asia" },
  { code: "CN", name: "China", continent: "Asia" },
  { code: "JP", name: "Japan", continent: "Asia" },
  { code: "AU", name: "Australia", continent: "Oceania" },
];

export const getCountryByCode = (code: string): Country | undefined => {
  return countries.find(country => country.code === code);
};

export const getCountryByName = (name: string): Country | undefined => {
  return countries.find(country => country.name.toLowerCase() === name.toLowerCase());
};

export const getAfricanCountries = (): Country[] => {
  return countries.filter(country => country.continent === "Africa");
};