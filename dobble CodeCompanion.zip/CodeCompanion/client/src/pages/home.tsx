import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import PlatformFeatures from "@/components/platform-features";
import CreatorDashboardPreview from "@/components/creator-dashboard-preview";
import BrandDashboardPreview from "@/components/brand-dashboard-preview";
import Testimonials from "@/components/testimonials";
import CTASection from "@/components/cta-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-light">
      <Navigation />
      <HeroSection />
      <PlatformFeatures />
      <CreatorDashboardPreview />
      <BrandDashboardPreview />
      <Testimonials />
      <CTASection />
      <Footer />
    </div>
  );
}
