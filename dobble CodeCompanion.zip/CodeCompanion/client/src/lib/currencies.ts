export interface Currency {
  code: string;
  name: string;
  symbol: string;
  country: string;
  minWithdrawal: number;
}

export const currencies: Currency[] = [
  // Major currencies
  { code: "USD", name: "US Dollar", symbol: "$", country: "United States", minWithdrawal: 10 },
  { code: "EUR", name: "Euro", symbol: "€", country: "European Union", minWithdrawal: 10 },
  { code: "GBP", name: "British Pound", symbol: "£", country: "United Kingdom", minWithdrawal: 8 },
  
  // African currencies
  { code: "NGN", name: "Nigerian Naira", symbol: "₦", country: "Nigeria", minWithdrawal: 4000 },
  { code: "GHS", name: "Ghanaian Cedi", symbol: "₵", country: "Ghana", minWithdrawal: 60 },
  { code: "KES", name: "Kenyan Shilling", symbol: "KSh", country: "Kenya", minWithdrawal: 1000 },
  { code: "ZAR", name: "South African Rand", symbol: "R", country: "South Africa", minWithdrawal: 150 },
  { code: "EGP", name: "Egyptian Pound", symbol: "£", country: "Egypt", minWithdrawal: 300 },
  { code: "MAD", name: "Moroccan Dirham", symbol: "د.م.", country: "Morocco", minWithdrawal: 100 },
  { code: "TND", name: "Tunisian Dinar", symbol: "د.ت", country: "Tunisia", minWithdrawal: 30 },
  { code: "ETB", name: "Ethiopian Birr", symbol: "Br", country: "Ethiopia", minWithdrawal: 500 },
  { code: "UGX", name: "Ugandan Shilling", symbol: "USh", country: "Uganda", minWithdrawal: 37000 },
  { code: "TZS", name: "Tanzanian Shilling", symbol: "TSh", country: "Tanzania", minWithdrawal: 23000 },
  { code: "RWF", name: "Rwandan Franc", symbol: "FRw", country: "Rwanda", minWithdrawal: 10000 },
  { code: "XOF", name: "West African CFA Franc", symbol: "CFA", country: "West Africa", minWithdrawal: 6000 },
  { code: "XAF", name: "Central African CFA Franc", symbol: "FCFA", country: "Central Africa", minWithdrawal: 6000 },
  { code: "MWK", name: "Malawian Kwacha", symbol: "MK", country: "Malawi", minWithdrawal: 8000 },
  { code: "ZMW", name: "Zambian Kwacha", symbol: "ZK", country: "Zambia", minWithdrawal: 200 },
  { code: "BWP", name: "Botswanan Pula", symbol: "P", country: "Botswana", minWithdrawal: 110 },
  { code: "SZL", name: "Swazi Lilangeni", symbol: "L", country: "Eswatini", minWithdrawal: 150 },
  { code: "LSL", name: "Lesotho Loti", symbol: "L", country: "Lesotho", minWithdrawal: 150 },
  { code: "MZN", name: "Mozambican Metical", symbol: "MT", country: "Mozambique", minWithdrawal: 630 },
  { code: "AOA", name: "Angolan Kwanza", symbol: "Kz", country: "Angola", minWithdrawal: 8300 },
  { code: "MGA", name: "Malagasy Ariary", symbol: "Ar", country: "Madagascar", minWithdrawal: 42000 },
  { code: "MUR", name: "Mauritian Rupee", symbol: "₨", country: "Mauritius", minWithdrawal: 450 },
  { code: "SCR", name: "Seychellois Rupee", symbol: "₨", country: "Seychelles", minWithdrawal: 140 },
  { code: "CDF", name: "Congolese Franc", symbol: "FC", country: "DR Congo", minWithdrawal: 25000 },
  { code: "BIF", name: "Burundian Franc", symbol: "FBu", country: "Burundi", minWithdrawal: 28000 },
  { code: "DJF", name: "Djiboutian Franc", symbol: "Fdj", country: "Djibouti", minWithdrawal: 1780 },
  { code: "ERN", name: "Eritrean Nakfa", symbol: "Nfk", country: "Eritrea", minWithdrawal: 150 },
  { code: "SOS", name: "Somali Shilling", symbol: "S", country: "Somalia", minWithdrawal: 5800 },
  { code: "SLL", name: "Sierra Leonean Leone", symbol: "Le", country: "Sierra Leone", minWithdrawal: 200000 },
  { code: "LRD", name: "Liberian Dollar", symbol: "L$", country: "Liberia", minWithdrawal: 1600 },
  { code: "GMD", name: "Gambian Dalasi", symbol: "D", country: "Gambia", minWithdrawal: 600 },
  { code: "GNF", name: "Guinean Franc", symbol: "FG", country: "Guinea", minWithdrawal: 86000 },
  { code: "CVE", name: "Cape Verdean Escudo", symbol: "$", country: "Cape Verde", minWithdrawal: 1000 },
  { code: "STN", name: "São Tomé and Príncipe Dobra", symbol: "Db", country: "São Tomé and Príncipe", minWithdrawal: 220 },
  { code: "KMF", name: "Comorian Franc", symbol: "CF", country: "Comoros", minWithdrawal: 4400 },
  { code: "SHP", name: "Saint Helena Pound", symbol: "£", country: "Saint Helena", minWithdrawal: 8 },
  { code: "NAD", name: "Namibian Dollar", symbol: "N$", country: "Namibia", minWithdrawal: 150 },
  { code: "SDP", name: "Sudanese Pound", symbol: "£", country: "Sudan", minWithdrawal: 6000 },
  { code: "SSP", name: "South Sudanese Pound", symbol: "£", country: "South Sudan", minWithdrawal: 1300 },
  { code: "LYD", name: "Libyan Dinar", symbol: "ل.د", country: "Libya", minWithdrawal: 48 },
  { code: "DZD", name: "Algerian Dinar", symbol: "د.ج", country: "Algeria", minWithdrawal: 1350 },
  
  // Other popular currencies
  { code: "CAD", name: "Canadian Dollar", symbol: "C$", country: "Canada", minWithdrawal: 13 },
  { code: "AUD", name: "Australian Dollar", symbol: "A$", country: "Australia", minWithdrawal: 15 },
  { code: "JPY", name: "Japanese Yen", symbol: "¥", country: "Japan", minWithdrawal: 1500 },
  { code: "CHF", name: "Swiss Franc", symbol: "Fr", country: "Switzerland", minWithdrawal: 9 },
  { code: "CNY", name: "Chinese Yuan", symbol: "¥", country: "China", minWithdrawal: 70 },
  { code: "INR", name: "Indian Rupee", symbol: "₹", country: "India", minWithdrawal: 830 },
  { code: "BRL", name: "Brazilian Real", symbol: "R$", country: "Brazil", minWithdrawal: 50 },
  { code: "MXN", name: "Mexican Peso", symbol: "$", country: "Mexico", minWithdrawal: 200 },
  { code: "ARS", name: "Argentine Peso", symbol: "$", country: "Argentina", minWithdrawal: 10000 },
  { code: "CLP", name: "Chilean Peso", symbol: "$", country: "Chile", minWithdrawal: 8000 },
  { code: "COP", name: "Colombian Peso", symbol: "$", country: "Colombia", minWithdrawal: 40000 },
  { code: "PEN", name: "Peruvian Sol", symbol: "S/", country: "Peru", minWithdrawal: 37 },
  { code: "UYU", name: "Uruguayan Peso", symbol: "$", country: "Uruguay", minWithdrawal: 430 },
  { code: "PYG", name: "Paraguayan Guarani", symbol: "₲", country: "Paraguay", minWithdrawal: 70000 },
  { code: "BOB", name: "Bolivian Boliviano", symbol: "Bs", country: "Bolivia", minWithdrawal: 70 },
  { code: "VES", name: "Venezuelan Bolívar", symbol: "Bs", country: "Venezuela", minWithdrawal: 370000 },
  { code: "GYD", name: "Guyanese Dollar", symbol: "G$", country: "Guyana", minWithdrawal: 2100 },
  { code: "SRD", name: "Surinamese Dollar", symbol: "$", country: "Suriname", minWithdrawal: 350 },
];

export const getCurrencyByCode = (code: string): Currency | undefined => {
  return currencies.find(currency => currency.code === code);
};

export const getCurrencyByCountry = (country: string): Currency | undefined => {
  return currencies.find(currency => currency.country.toLowerCase() === country.toLowerCase());
};

export const formatCurrency = (amount: number, currencyCode: string): string => {
  const currency = getCurrencyByCode(currencyCode);
  if (!currency) return `${amount}`;
  
  return `${currency.symbol}${amount.toLocaleString()}`;
};

export const formatBudget = (budget: string, currencyCode: string = "USD"): string => {
  const currency = getCurrencyByCode(currencyCode);
  if (!currency) return budget;
  
  const numericBudget = parseFloat(budget.replace(/[^\d.]/g, ""));
  if (isNaN(numericBudget)) return budget;
  
  return `${currency.symbol}${numericBudget.toLocaleString()}`;
};